# TripServicesWeb

## Application Notes
The application has two targets: PreProd and CI/CD
Doing so means that we need two Firebase Projects.  

### Firebase Notes
- User: `tvlpt.tripservices@gmail.com` Pwd: Contact ken.crismon@travelport.com
- [Firebase Console CI/CD](https://console.firebase.google.com/project/tripservices1-68980/overview)
- [Firebase Console PreProd](https://console.firebase.google.com/project/tripservicesp/overview)
- [Google Cloud Console](https://console.cloud.google.com/home/activity?project=tripservices1-68980)
- `firebase use` --add will allow you to add other projects.  
- `firebase list` shows a list of available projects that can be added as well as which one is currently being used.
- For firebase deploy instructions including the initialization steps, please see the `firebase-deploy.txt` file in the repo.  Look for the --- instructions and below each is the command to execute and the "expected" response from the firebase CLI.  *Note as the firebase CLI evolves, it is likely the outputs from the commands will change.  Look for trends not exact matches.*

- [Latest CI Code running live](https://tripservices1-68980.firebaseapp.com)

### Blackduck and Fortify notes:
- [BlackDuck documentation](https://synopsys.atlassian.net/wiki/spaces/INTDOCS/pages/622655/Running+Hub+Detect+with+TFS+or+Azure+DevOps)


### NGBootstrap
- [Angular Bootstrap components](https://ng-bootstrap.github.io)

### Google Maps interfaces:
- [Maps API Link](https://angular-maps.com/api-docs/agm-core/index.html)

### Google Analytics Details:
- [Google Analytics Login](https://analytics.google.com)
- CI/CD: UA-136206917-1
    - Use the tvlpt.tripservices@gmail.com account to log into Google Analytics



### VisualStudio DevOps
- [DevOps URL](https://dev.azure.com/TripServices/DemandAPI)
- Repo: https://TripServices@dev.azure.com/TripServices/DemandAPI/_git/DemandAPI
  - Credentials: tripservices PWD: See Ken Crismon at ken.crismon@travelport.com

## Git Notes
- Clone: `git clone -b <BranchName> <RepoURL> <TargetDirectory>`
    - `git clone -b dev https://TripServices@dev.azure.com/TripServices/DemandAPI/_git/DemandAPI dev`

## Tutorials/Links
- [Tutorial on Angular7 SASS, FontAwesome and Bootstrap](https://www.positronx.io/setup-angular-6-project-using-bootstrap-4-sass-font-awesome-ng-bootstrap/)
- [Tutorial on Angular7 and Firebase Authentication/Firestore](https://www.positronx.io/full-angular-7-firebase-authentication-system/)
- [GitBucket Images Link](https://gitbucket.tvlport.com/acs/ntac-ui/tree/master/public/images) 
- [Internal OAUTH2 TripServices Akana tutorial](http://10.7.226.129:30510/webhelp/TripServicesReview/#GeneralTopics/Oauth.htm%3FTocPath%3D_____4)
- [Various Angular 6/7 tutorials](https://www.techiediaries.com/angular/)
- [Tutorial on deploying Angular 7 app to firebase/firehost](https://www.youtube.com/watch?v=aICeVhu2mAE)
- [Java model to Typescript conversion](https://stackoverflow.com/questions/32451966/generate-typescript-interfaces-from-java-interfaces)
- [JSON to Typescript Interface converter](http://json2ts.com/)
- [JSON Object generator](http://www.objgen.com)


# Angular Notes

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 7.1.2.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

# VS Code tips

- [VSCode download link](https://code.visualstudio.com/)
## Extensions Used (These cover most of the tech stack we are using)
- Angular Files
- Angular Language Service
- Angular v7 snippets
- C#
- C# Extensions
- C# Snippets
- C# XML Documentation Comments
- Debugger for Chrome
- Debugger for Java
- Diff Tool
- Java Dependency Viewer
- Java Extension Pack
- Java Test Runner
- Language Support for Java(TM) by Red Hat
- Material Icon Theme
- Maven for Java
- Nuget Package Manager
- Path Intellisense
- Prettier - Code Formatter
- Rainbow Brackets
- TSLint
- Typescript Hero
- XML Tools
- Document This

# TripServices HCCD Notes
- [Simple Search URL](https://apigateway.pp.travelport.com/hotel/shop/v3/properties?checkinDate=20190309&checkoutDate=20190310&numberOfGuests=1&radius=5&lat=48.867646&lon=2.342938)

# TypeScript documentation generation
- [TYPEDOC DOC Generation Link](https://typedoc.org/)
- Execute from the base folder the following: `typedoc --out docs ./src`

# How to build the app and deploy to firebase
- To build the application in debug execute: `.\bd` which will execute `ng build` under the covers.
- To deploy the application to the google Firebase hosting execute: `.\dp` which will look into the /dist folder and deploy the current application residing there.  
- To build the docs from the sourcecode, execute `.\docs` which under the covers executes the typedoc node.js application.  See above for instructions on how to install the TypeDoc tools.

# Future Names for the DemoUI
- (Sunil): Demand API name --> TravelHarmony.com
- (Gajanan) Travelport Orchestration Service (TOS)
- (Gajanan) Universal Demo Site (UDS)
- (Gajanan) AtoZ  Trip API

# Firebase getToken function
- To deploy execute 'firebase deploy --only functions'
- TO authenticate the function: https://github.com/firebase/functions-samples/tree/master/authorized-https-endpoint
- https://github.com/firebase/functions-samples/tree/master/authenticated-json-api

