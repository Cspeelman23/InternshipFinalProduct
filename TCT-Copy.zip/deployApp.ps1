# Setup some common variables
$ngBuildCmd = "ng";
$ngBuildPrm1 = "build" 
$ngBuildPrm2 = "--outputHashing=all"

$firebaseDeployCmd = "firebase"
$firebaseDeployPrm = "deploy"

$versionFile = "./src/environments/version.ts"

$gitCmd = "git"
$gitPrm1 = "rev-parse" 
$gitPrm2 = "--short" 
$gitPrm3 = "HEAD"

$gitPrm4 = "checkout"

$gitPrm5 = "tag"
$gitPrm6 = "push"
$gitPrm7 = "--tags"

# When the first, second or third value changes in the version, this value will ALSO need to change.
$tag = "v1.0.0."

$siteAddress = "https://tripservices1-68980.firebaseapp.com"

Write-Output "Script runtime variables:"
Write-Output "-------------------------"
Write-Output ("ngBuildCmd: " + $ngBuildCmd)
Write-Output ("ngBuildPrm1: " + $ngBuildPrm1)
Write-Output ("ngBuildPrm2: " + $ngBuildPrm2)
Write-Output ("firebaseDeployCmd: " + $firebaseDeployCmd)
Write-Output ("firebaseDeployPrm: " + $firebaseDeployPrm)
Write-Output ("versionFile: " + $versionFile)
Write-Output ("gitCmd: " + $gitCmd)
Write-Output ("gitPrm1: " + $gitPrm1)
Write-Output ("gitPrm2: " + $gitPrm2)
Write-Output ("gitPrm3: " + $gitPrm3)
Write-Output ("gitPrm4: " + $gitPrm4)
Write-Output ("gitPrm5: " + $gitPrm5)
Write-Output ("gitPrm6: " + $gitPrm6)
Write-Output ("gitPrm7: " + $gitPrm7)
Write-Output ("Site Address: " + $siteAddress)
Write-Output "-------------------------"
# Retrieve the latest Commit id using the --short so we only get the first six characters.
$gitCommitId = & $gitCmd $gitPrm1 $gitPrm2 $gitPrm3
# Make certian the command succeeded.

if ($?) {
    Write-Output ("Deploying BuildID: " + $gitCommitId)
    $tag = $tag + $gitCommitId
    $versionString = ("VersionBuild:'" + $gitCommitId + "'")
    $versionStringOrig = ("VersionBuild:'%'")
    Write-Output ("Version Tag: " + $tag)
    
    Write-Output ("VersionString: " + $versionString)
    Write-Output "-------------------------"

    # Insert the build number into the version string.
    ((Get-Content -path $versionFile) -replace "VersionBuild:'%'", ("VersionBuild:'" + $gitCommitId + "'")) | Set-Content -Path ./src/environments/version.ts
     if ($?) {
        # Echo the contents of the version.ts
        Get-Content -Path $versionFile
        
        # Build the application.  Note the --outputHashing=all ensures browser cache busting.
        Write-Output "Starting the Angular build"
        Write-Output "--------------------------"
        & $ngBuildCmd $ngBuildPrm1 $ngBuildPrm2 $ngBuildPrm3
        if ($?) {
            # Deploy to Firebase.
            Write-Output "Starting the Firebase Deploy"
            Write-Output "----------------------------"
            & $firebaseDeployCmd $firebaseDeployPrm
            if ($?) {
                Write-Output ($appName + "is deployed")
                Write-Output "Uncomiiting the version.ts"
                & $gitCmd $gitPrm4 $versionFile
                Write-Output "Setting the tag"
                & $gitCmd $gitPrm5 $tag
                Write-Output "Pushing the tag"
                & $gitCmd $gitPrm6 $gitPrm7
                Write-Output "-------------------------"
                Start-Process $siteAddress
            }
            else {
                Write-Output "********************************************"
                Write-Output "ERROR: Firebase deploy failed: Putting the version.ts back to its initial state"
                # Rollback the version file.
                ((Get-Content -path $versionFile) -replace $versionString, $versionStringOrig) | Set-Content -Path $versionFile
                & $gitCmd $gitPrm4 $versionFile
                Get-Content -Path $versionFile  
            }
        }
        else {
            Write-Output "********************************************"
            Write-Output "ERROR: Angular build command failed: Putting the version.ts back to its initial state"
            # Rollback the version file.
            ((Get-Content -path $versionFile) -replace $versionString, $versionStringOrig) | Set-Content -Path $versionFile
            & $gitCmd $gitPrm4 $versionFile
            Get-Content -Path $versionFile  
        }    
    }
    else {
        Write-Output "********************************************"
        Write-Output "ERROR: Setting the version string failed"
    }
}
else {
    Write-Output "********************************************"
    Write-Output "ERROR Getting the HEAD commit from Git repo"
}



