import { NgModule } from '@angular/core';
import { MatButtonModule, MatCheckboxModule, MatToolbarModule, MatChipsModule, MatOptionModule,
  MatGridListModule, MatProgressBarModule, MatSliderModule, MatSlideToggleModule, MatMenuModule,
  MatDialogModule, MatSnackBarModule, MatSelectModule, MatInputModule, MatSidenavModule,
  MatCardModule, MatIconModule, MatRadioModule, MatProgressSpinnerModule, MatTabsModule,
  MatListModule, MatDatepickerModule, MatNativeDateModule, MatTableModule,
  MatExpansionModule, MatAutocompleteModule } from '@angular/material';
import {MatButtonToggleModule} from '@angular/material/button-toggle';

@NgModule({
  imports: [
    MatButtonModule, MatCheckboxModule, MatToolbarModule, MatChipsModule, MatOptionModule,
    MatGridListModule, MatProgressBarModule, MatSliderModule, MatSlideToggleModule, MatMenuModule,
    MatDialogModule, MatSnackBarModule, MatSelectModule, MatInputModule, MatSidenavModule,
    MatCardModule, MatIconModule, MatRadioModule, MatProgressSpinnerModule, MatTabsModule,
    MatListModule, MatDatepickerModule, MatNativeDateModule, MatTableModule, MatExpansionModule, MatAutocompleteModule,
    MatButtonToggleModule
  ],
  exports: [
    MatButtonModule, MatCheckboxModule, MatToolbarModule, MatChipsModule, MatOptionModule,
    MatGridListModule, MatProgressBarModule, MatSliderModule, MatSlideToggleModule, MatMenuModule,
    MatDialogModule, MatSnackBarModule, MatSelectModule, MatInputModule, MatSidenavModule,
    MatCardModule, MatIconModule, MatRadioModule, MatProgressSpinnerModule, MatTabsModule,
    MatListModule, MatDatepickerModule, MatNativeDateModule, MatTableModule, MatExpansionModule, MatAutocompleteModule,
    MatButtonToggleModule
  ],
})
export class AppMaterialModule { }
