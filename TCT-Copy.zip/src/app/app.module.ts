// Core application scafolding
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { AppRoutingModule } from './shared/routing/app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';  //  'ngx-bootstrap/datepicker';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatDividerModule} from '@angular/material/divider';
import {MatTableModule} from '@angular/material/table';
import {MatTooltipModule} from '@angular/material/tooltip';


import { NgxSpinnerModule } from 'ngx-spinner';

import { AppMaterialModule } from './app.material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NormalizeDurationPipe } from './shared/utilities/durationPipe';

// Firebase services + enviornment module
import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFirestoreModule, FirestoreSettingsToken } from '@angular/fire/firestore';

import { AgmCoreModule, GoogleMapsAPIWrapper } from '@agm/core';

import { environment } from '../environments/environment';

// Components
import { HeaderComponent } from './components/layouts/header/header.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SignInComponent } from './components/user-auth/sign-in/sign-in.component';
import { SignUpComponent } from './components/user-auth/sign-up/sign-up.component';
import { ForgotPasswordComponent } from './components/user-auth/forgot-password/forgot-password.component';
import { VerifyEmailComponent } from './components/user-auth/verify-email/verify-email.component';
import { TripServicesGDSComponent } from './components/dashboard-components/air-search/trip-services-gds/trip-services-gds.component';
import { TripServicesAirComponent } from './components/dashboard-components/air-sandbox/trip-services-air/trip-services-air.component';
// tslint:disable-next-line: max-line-length
import { TripServicesAirResultsComponent } from './components/dashboard-components/air-sandbox/trip-services-air-results/trip-services-air-results.component';
import { TripSearchGdsComponent } from './components/dashboard-components/air-search/trip-search-gds/trip-search-gds.component';
import { TripServicesHotelComponent } from './components/dashboard-components/hotel/trip-services-hotel/trip-services-hotel.component';
// tslint:disable-next-line: max-line-length
import { TripSearchHotelResultsComponent } from './components/dashboard-components/hotel/trip-search-hotel-results/trip-search-hotel-results.component';
import { HeartBeatComponent } from './components/dashboard-components/heart-beat/heart-beat.component';
// tslint:disable-next-line: max-line-length
import { TripServicesPriceConfirmationComponent } from './components/dashboard-components/air-search/trip-services-price-confirmation/trip-services-price-confirmation.component';
// tslint:disable-next-line: max-line-length
import { TripServicesAdvancedSearchComponent } from './components/dashboard-components/air-search/trip-services-advanced-search/trip-services-advanced-search.component';
import { AboutComponent } from './components/dashboard-components/about/about.component';

// Application services (shared)
import { AuthService } from './shared/services/auth/auth.service';
import { TripServicesGDSService } from './shared/services/air-search/trip-services-gds.service';
import { TripServicesAirService } from './shared/services/air-sandbox/trip-services-air.service';
import { TripServicesHCCDService } from './shared/services/hotel/trip-services-hccd.service';
import { RefDataService } from './shared/services/ref-data/ref-data.service';
import { FareFamilyShopService } from './shared/services/fare-family/fare-family-shop.service';
import { FareFamilySearchService } from './shared/services/fare-family/fare-family-search.service';

// Utilities
import { NgDateFormater } from './shared/utilities/ngDateFormater';
import { UuidHelper } from './shared/utilities/uuidHelper';
import { VersionHelper} from './shared/utilities/versionHelper';
import { CarrierPreferenceComponent } from './components/dashboard-components/air-search/carrier-preference/carrier-preference.component';
import { ChipsAutocompleteComponent } from './components/dashboard-components/air-search/chips-autocomplete/chips-autocomplete.component';
import { FareFamilyShopComponent } from './components/dashboard-components/fare-family/fare-family-shop/fare-family-shop.component';
import { FareFamilySearchComponent } from './components/dashboard-components/fare-family/fare-family-search/fare-family-search.component';
import { TripServicesCarComponent } from './components/dashboard-components/car/trip-services-car/trip-services-car.component';
// tslint:disable-next-line: max-line-length
import { CustomCalendarHeaderComponent } from './shared/utilities/custom-calendar-header/custom-calendar-header.component';
import { TripServicesBookComponent } from './components/dashboard-components/air-book/trip-services-book/trip-services-book.component';
import { BookTravelerComponent } from './components/dashboard-components/air-book/book-traveler/book-traveler.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    DashboardComponent,
    SignInComponent,
    SignUpComponent,
    ForgotPasswordComponent,
    VerifyEmailComponent,
    TripServicesGDSComponent,
    TripServicesAirComponent,
    TripServicesAirResultsComponent,
    TripSearchGdsComponent,
    TripServicesHotelComponent,
    TripSearchHotelResultsComponent,
    HeartBeatComponent,
    CarrierPreferenceComponent,
    ChipsAutocompleteComponent,
    FareFamilyShopComponent,
    FareFamilySearchComponent,
    TripServicesPriceConfirmationComponent,
    TripServicesCarComponent,
    TripServicesAdvancedSearchComponent,
    CustomCalendarHeaderComponent,
    TripServicesBookComponent,
    AboutComponent,
    BookTravelerComponent,
    NormalizeDurationPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireAuthModule,
    AngularFirestoreModule,
    HttpClientModule,
    AgmCoreModule.forRoot({ apiKey: environment.googleCloudPlatform.apiKey}),
    ReactiveFormsModule,
    FormsModule,
    NgbModule,
    DatepickerModule.forRoot(),
    BsDatepickerModule.forRoot(),
    MatDatepickerModule,
    AppMaterialModule,
    BrowserAnimationsModule,
    NgxSpinnerModule,
    MatDividerModule,
    MatTableModule,
    MatTooltipModule
  ],
  providers: [
    AuthService,
    TripServicesGDSService,
    TripServicesAirService,
    TripServicesHCCDService,
    GoogleMapsAPIWrapper,
    NgDateFormater,
    UuidHelper,
    VersionHelper,
    RefDataService,
    FareFamilyShopService,
    FareFamilySearchService,
    { provide: FirestoreSettingsToken, useValue: {} },
  ],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ],
  entryComponents: [TripServicesAdvancedSearchComponent, CustomCalendarHeaderComponent]
})
export class AppModule { }
