import { Component, OnInit } from '@angular/core';
import { VersionHelper } from '../../../shared/utilities/versionHelper';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  mastHead: string;
  acks: string;
  acks2: string;
  acks3: string;
  creditStatement: string;
  credits: string;
  AppVersion: any;
  repoURL: any;
  docURL: any;

  constructor(public versionHelper: VersionHelper) {
    // tslint:disable-next-line: max-line-length
    this.mastHead = 'Cady Speelman, Archana Thillai Villalan, Saranraj Mari, Vinoth Nagarajan, Muthukumaran Selvaraju, Sunil Sadhwani, Ken Crismon';
    // tslint:disable-next-line: max-line-length
    this.acks = 'TripServices Content Tour would not be possible without the continued support of Julio, Xavier and Jim, our sponsors.';
    this.acks2 = 'This continues to be an application delivered with the utmost collaborative vision of all on the MastHead.';
    // tslint:disable-next-line: max-line-length
    this.acks3 = 'Meenu Haseen, Beauty Mondal, Rupasree Kalpa, Subbiah Ramasamy, Badri Krishnan, Morris Seals, Gajanan Petkar, Bhardwaj Alamuru, Ravi Dasgupta,Debra Henley, Julio Palacios, Xavier Rubio, Jim Miller, Sean Dempkin, Chris Guida';
    this.creditStatement = 'Credit to the artists whose work is found within this application:';
    // tslint:disable-next-line: max-line-length
    this.credits = 'Children by Musmellow from the Noun Project, Human by Adrien Coquet from the Noun Project, Baby by Gan Khoon Lay from the Noun Project, Check by Susannanova from the Noun Project, cheap by Alice Design from the Noun Project';
    this.AppVersion = versionHelper.versionString();
    this.repoURL = environment.publicRepository;
    this.docURL = environment.tripServicesDocumentation;
   }

  ngOnInit() {
  }

}
