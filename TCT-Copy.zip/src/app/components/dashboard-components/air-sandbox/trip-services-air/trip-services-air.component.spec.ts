import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule} from '@angular/material/radio';
import { MatSelectModule } from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { HttpClient, HttpHeaders, HttpHandler } from '@angular/common/http';

import { RouterModule, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { TripServicesAirComponent } from './trip-services-air.component';

describe('TripServicesAirComponent', () => {
  let component: TripServicesAirComponent;
  let fixture: ComponentFixture<TripServicesAirComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TripServicesAirComponent ],
      imports: [MatCardModule,
                MatFormFieldModule,
                MatIconModule,
                MatInputModule,
                MatDialogModule,
                MatRadioModule,
                MatSelectModule,
                ReactiveFormsModule,
                FormsModule,
                RouterModule,
                RouterTestingModule,
                BrowserAnimationsModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [HttpClient, HttpHandler]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TripServicesAirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
