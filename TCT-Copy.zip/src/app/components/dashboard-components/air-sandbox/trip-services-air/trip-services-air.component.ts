import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormArray, FormGroup, Validators } from '@angular/forms';
import { TripServicesAirService } from '../../../../shared/services/air-sandbox/trip-services-air.service';
import { Router } from '@angular/router';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { NgxSpinnerService } from 'ngx-spinner';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-trip-services-air',
  templateUrl: './trip-services-air.component.html',
  styleUrls: ['./trip-services-air.component.css']
})
export class TripServicesAirComponent implements OnInit {

  // proxyServer = 'https://cors-anywhere.herokuapp.com/';

  constructor(private formBuilder: FormBuilder,
    public airService: TripServicesAirService,
    private router: Router,
    private spinner: NgxSpinnerService ) {
      this.datePickerConfig = Object.assign({}, { showWeekNumbers: false, dateInputFormat: 'YYYY-MM-DD'} );
  }

  datePickerConfig: Partial<BsDatepickerConfig>;
  searchForm: FormGroup;
  passengerType: string[] = ['ADT', 'CHD', 'INF'];
  trip = 'oneWay';

  ngOnInit() {
    // Reactive form creates the Search request 'CatalogOfferingsQueryRequest' JSON object to hit the endpoint URL
    this.searchForm = this.formBuilder.group({
      CatalogOfferingsQueryRequest: this.formBuilder.group({
        CatalogOfferingsRequest: this.formBuilder.array([this.catalogOfferingsRequest()])
      })
    });
  }

  catalogOfferingsRequest(): FormGroup {
    return this.formBuilder.group({
        '@type': 'CatalogOfferingsRequestAir',
        returnBrandedFaresInd: true,
        maxNumberOfOffersToReturn: 100,
        // contentSourceList: this.formBuilder.array([ 'NDC' ]),
        offersPerPage: 10,
        PassengerCriteria: this.passengerCriteria(),
        SearchCriteriaFlight: this.formBuilder.array([this.searchCriteriaFlight()])// ,
        // PseudoCityInfo: this.formBuilder.group({ value: ['OMW'] })
      } );
  }

  passengerCriteria(): FormArray {

    let i: number;
    const passenger = this.formBuilder.array([]);
    for (i = 0; i < this.passengerType.length; i++) {
      passenger.push(this.formBuilder.group({
        number: ['0'],
        value: [this.passengerType[i]]
      }));
    }
    return passenger;
  }

  searchCriteriaFlight(): FormGroup {
    return this.formBuilder.group({
      From: this.formBuilder.group({ value: ['MEL', Validators.required] }),
      To: this.formBuilder.group({ value: ['SIN', Validators.required] }),
      departureDate: ['2019-06-13', Validators.required]
    });
  }

  addPassenger(request) {
    const passenger = <FormArray>request.get('PassengerCriteria');
    passenger.push(this.passengerCriteria());
  }

  onSubmit() {
    console.log(JSON.stringify(this.searchForm.value));
    this.spinner.show();
    // Invoke Shop Domain
    this.airService.post(environment.tripservices.tripservicesAirProps.lowfareURI, this.searchForm.value)
        .subscribe(
          (data: any) => {
            this.spinner.hide();
            console.log(data);
            this.airService.response = data;
            this.router.navigate(['/dashboard/trip-services-air-results']);
          },
          (error: any) => {
            this.spinner.hide();
            console.log(error);
          }
        );
  }

  getPassengerCriteria(request) {
    return request.controls.PassengerCriteria.controls;
  }

  getSearchCriteriaFlight(request) {
    return request.controls.SearchCriteriaFlight.controls;
  }

  get CatalogOfferingsRequest() {
    return this.searchForm.get('CatalogOfferingsQueryRequest.CatalogOfferingsRequest') as FormArray;
  }

}
