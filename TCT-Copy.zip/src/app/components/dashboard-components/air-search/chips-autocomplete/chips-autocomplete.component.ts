import { Component, ElementRef, ViewChild, OnInit, Output, EventEmitter } from "@angular/core";
import { COMMA, ENTER } from "@angular/cdk/keycodes";
import { FormControl } from "@angular/forms";
import {
  MatAutocompleteSelectedEvent,
  MatChipInputEvent
} from "@angular/material";
import { Observable } from "rxjs";
import { startWith } from "rxjs/operators/startWith";
import { map } from "rxjs/operators/map";
import { RefDataService } from "../../../../shared/services/ref-data/ref-data.service";
import { AllCarriers } from "../../../../shared/models/gds/Carrierlist";

@Component({
  selector: "app-chips-autocomplete",
  templateUrl: "./chips-autocomplete.component.html",
  styleUrls: ["./chips-autocomplete.component.css"]
})
export class ChipsAutocompleteComponent implements OnInit {
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = false;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  stateCtrl = new FormControl();
  filteredCarriers: Observable<string[]>;
  carriers: any;
  autoChipData: any;
  allCarriers: AllCarriers[];

  @Output() childToParent = new EventEmitter<any>();
  @ViewChild("carrierInput") carrierInput: ElementRef;

  constructor(private carrierGroupService: RefDataService) {
    this.autoChipData = [];
    this.filteredCarriers = this.stateCtrl.valueChanges.pipe(
      startWith(""),
      map((carrier: string) =>
        carrier.length >= 1 ? this._filter(carrier) : []
      )
    );
  }

  ngOnInit() {
    this.getCarrierList();
    this.carrierGroupService.currentAirline.subscribe(
      message => (this.carriers = message)
    );
  }

  ngAfterContentChecked() {
    this.changeAirline(this.autoChipData);
  }

  changeAirline(val) {
    if (this.autoChipData.length > 0) {
      this.carriers = this.carriers.concat(val);
    }
    this.carrierGroupService.changeAirline(this.carriers);
  }

  getCarrierList(): void {
    this.carrierGroupService
      .getCarrierList()
      .subscribe(data => (this.allCarriers = data));
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    if ((value || "").trim()) {
      this.carriers.push(value.trim());
    }

    // Reset the input value
    if (input) {
      input.value = "";
    }
    this.stateCtrl.setValue("");
  }

  resetAutoChipData(): void{
    this.autoChipData = []
  }

  remove(carrier: string): void {
    const index = this.carriers.indexOf(carrier);
    this.childToParent.emit(carrier);
    if (index >= 0) {
      const autoChipIndex = this.autoChipData.indexOf(carrier);
      if (autoChipIndex >= 0) {
        this.autoChipData.splice(autoChipIndex, 1);
      }
      this.carriers.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    const { CarrierCode, CarrierName } = event.option.value;
    this.autoChipData.push(`${CarrierCode}: ${CarrierName}`);
    this.carrierInput.nativeElement.value = "";
    this.stateCtrl.setValue("");
    var uniqueAirline = function(unique) {
      return unique.filter(function(element, position, arr) {
        return arr.indexOf(element) == position;
      });
    };
    this.autoChipData = uniqueAirline(this.autoChipData);
  }

  private _filter(value: any): any[] {
    return this.allCarriers.filter(carrier => {
      var indexValue = carrier.CarrierCode.toLowerCase().indexOf(value.toLowerCase()) === 0;
      if(indexValue){
        return `$(carrier.carrierCode): $(carrier.CarrierName)`;
      } 
    });    
  }
}
