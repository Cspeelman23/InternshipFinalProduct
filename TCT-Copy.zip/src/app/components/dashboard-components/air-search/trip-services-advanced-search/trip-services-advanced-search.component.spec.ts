import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TripServicesAdvancedSearchComponent } from './trip-services-advanced-search.component';

describe('TripServicesAdvancedSearchComponent', () => {
  let component: TripServicesAdvancedSearchComponent;
  let fixture: ComponentFixture<TripServicesAdvancedSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TripServicesAdvancedSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TripServicesAdvancedSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
