import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TripServicesPriceConfirmationComponent } from './trip-services-price-confirmation.component';

describe('TripServicesPriceConfirmationComponent', () => {
  let component: TripServicesPriceConfirmationComponent;
  let fixture: ComponentFixture<TripServicesPriceConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TripServicesPriceConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TripServicesPriceConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
