import { async, ComponentFixture, TestBed } from '@angular/core/testing';
 
import { FareFamilySearchComponent } from './fare-family-search.component';
 
describe('FareFamilySearchComponent', () => {
  let component: FareFamilySearchComponent;
  let fixture: ComponentFixture<FareFamilySearchComponent>;
 
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FareFamilySearchComponent ]
    })
    .compileComponents();
  }));
 
  beforeEach(() => {
    fixture = TestBed.createComponent(FareFamilySearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
 
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});