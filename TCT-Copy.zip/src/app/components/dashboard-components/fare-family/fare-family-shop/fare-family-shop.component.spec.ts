import { async, ComponentFixture, TestBed } from '@angular/core/testing';
 
import { FareFamilyShopComponent } from './fare-family-shop.component';
 
describe('FareFamilyShopComponent', () => {
  let component: FareFamilyShopComponent;
  let fixture: ComponentFixture<FareFamilyShopComponent>;
 
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FareFamilyShopComponent ]
    })
    .compileComponents();
  }));
 
  beforeEach(() => {
    fixture = TestBed.createComponent(FareFamilyShopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
 
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});