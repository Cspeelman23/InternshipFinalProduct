import { Component, OnInit, HostListener, Inject  } from '@angular/core';
import { FormBuilder, FormArray, FormGroup, FormControl, Validators } from '@angular/forms';
import { FareFamilyShopService } from '../../../../shared/services/fare-family/fare-family-shop.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Observable } from 'rxjs/internal/Observable';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';
import { RefDataService } from '../../../../shared/services/ref-data/ref-data.service';
import { MatDialog } from '@angular/material/dialog';
import {CustomCalendarHeaderComponent} from '../../../../shared/utilities/custom-calendar-header/custom-calendar-header.component';
import { DOCUMENT } from '@angular/common';

export interface Ptc {
  number: number;
  value: string;
  view: string;
}

export interface Num {
  value: number;
  view: number;
}

@Component({
  selector: 'app-fare-family-shop',
  templateUrl: './fare-family-shop.component.html',
  styleUrls: ['./fare-family-shop.component.css']
})

export class FareFamilyShopComponent implements OnInit {

  customHeader = CustomCalendarHeaderComponent;

  submitType: any;
  defaultDepartureDate: Date;
  sccChannelID: string;
  searchForm: FormGroup;

  constructor(private formBuilder: FormBuilder,
    public ffsService: FareFamilyShopService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private refService: RefDataService,
    public advancedSearchDialog: MatDialog,
    @Inject(DOCUMENT) document) {

  }

  today = new Date(); // new defaults to current date
  minimumDate = new Date();
  maximumDate = new Date(this.today.setDate(this.today.getDate() + 90));

  Ptcs: Ptc[] = [
    { number: 1, value: 'ADT', view: 'Adult' }
  ];

  psng_num: Num[] = [
    { value: 0, view: 0 },
    { value: 1, view: 1 },
    { value: 2, view: 2 },
    { value: 3, view: 3 },
    { value: 4, view: 4 },
    { value: 5, view: 5 },
    { value: 6, view: 6 },
    { value: 7, view: 7 },
    { value: 8, view: 8 },
    { value: 9, view: 9 },
  ];

  multiCity = false;
  departure_date: Date;
  return_date: Date;
  filteredStates: Observable<any[]>;
  filteredStatesTo: Observable<any[]>;
  carriers: any;

  ngOnInit() {
    // Reactive form creates the Search request 'FareFamilyOfferingsQueryRequest' JSON object to hit the endpoint URL
    this.searchForm = this.formBuilder.group({
      FareFamilyOfferingsQueryRequest: this.formBuilder.group({
        FareFamilyOfferingsRequest: this.fareFamilyOfferingsRequest()
      })
    });
    this.filteredStates = this.searchForm
      .get('FareFamilyOfferingsQueryRequest.FareFamilyOfferingsRequest.SearchCriteriaFlight.From.value').valueChanges
      .pipe(
        startWith(''),
        map(state => state.length >= 1 ? this.refService.filterStates(state) : [])
      );
    this.filteredStatesTo = this.searchForm
      .get('FareFamilyOfferingsQueryRequest.FareFamilyOfferingsRequest.SearchCriteriaFlight.To.value').valueChanges
      .pipe(
        startWith(''),
        map(state => state.length >= 1 ? this.refService.filterStates(state) : [])
      );
  }

  fareFamilyOfferingsRequest(): FormGroup {
    return this.formBuilder.group({
      '@type': 'FareFamilyOfferingsRequestAir',
      PassengerCriteria: this.passengerCriteria(),
      SearchCriteriaFlight: this.searchCriteriaFlight(),
    });
  }

  passengerCriteria(): FormGroup {
    const passenger = this.formBuilder.group({
      number: this.Ptcs[0].number,
      value: this.Ptcs[0].value
    });
    return passenger;
  }

  searchCriteriaFlight(): FormGroup {
    return this.formBuilder.group({
      departureDate: [''],
      From: this.formBuilder.group({ value: ['', Validators.required] }),
      To: this.formBuilder.group({ value: ['', Validators.required] })
    });
  }

  onSubmit() {

    if (this.departure_date !== undefined && this.departure_date !== null) {
      this.searchForm.value.FareFamilyOfferingsQueryRequest.FareFamilyOfferingsRequest
        .SearchCriteriaFlight.departureDate = this.departure_date.toISOString().slice(0, 10);
      const searchCriteriaFlight = this.searchForm
        .get('FareFamilyOfferingsQueryRequest.FareFamilyOfferingsRequest.SearchCriteriaFlight') as FormGroup;
    }

    console.log(JSON.stringify(this.searchForm.value));
    this.spinner.show();
    this.ffsService.postSearch(this.searchForm.value, false) // Calling FFS service, T=mock F=realtime
      .subscribe(
        (data: any) => {
          this.spinner.hide();
          console.log('Response ==> ' + JSON.stringify(data));
          if (data['FareFamilyOfferingsResponse']['FareFamilyOfferings'] !== undefined) {
            this.ffsService.setResponseData(data);
            this.router.navigate(['/dashboard/trip-services-ffs/fare-family-search']);
          } else {
            alert(data['FareFamilyOfferingsResponse']['Result']['Error']['0']['Message']);
          }
        },
        (error: any) => {
          this.spinner.hide();
          console.log(error);
        }
      );
  }

  get FareFamilyOfferingsRequest() {
    return this.searchForm.get('FareFamilyOfferingsQueryRequest.FareFamilyOfferingsRequest') as FormGroup;
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll(e) {
     if (window.pageYOffset > 120 && window.innerWidth > 900) {
        const element = document.getElementById('inputForm');
        element.classList.add('sticky');
        const heightNum = element.offsetHeight;
        const content = document.getElementById('tripSearchFfs');
        const paddingNum = (heightNum + 10).toString() + 'px'; // height of horizontal bar plus margin
        content.style.paddingTop = paddingNum;
     } else {
      const element = document.getElementById('inputForm');
        element.classList.remove('sticky');
        const content = document.getElementById('tripSearchFfs');
        content.style.paddingTop = '0px';
     }
  }

  /*getPassengerCriteria(request) {
    return request.controls.PassengerCriteria.controls;
  }

  getSearchCriteriaFlight(request) {
    return request.controls.SearchCriteriaFlight.controls;
  }

  getCarrierPreference(request) {
    return request.controls.SearchModifiersAir.controls.CarrierPreference.controls;
  }

  getCabinPreference(request) {
    return request.controls.SearchModifiersAir.controls.CabinPreference.controls;
  }

  getPassengers(request) {
    return request.controls.PassengerCriteria.value;
  }*/
}
