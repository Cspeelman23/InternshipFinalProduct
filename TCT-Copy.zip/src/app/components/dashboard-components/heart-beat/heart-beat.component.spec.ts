import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient, HttpHeaders, HttpHandler } from '@angular/common/http';
import { HeartBeatComponent } from './heart-beat.component';
import { VersionHelper } from '../../shared/utilities/versionHelper';

describe('HeartBeatComponent', () => {
  let component: HeartBeatComponent;
  let fixture: ComponentFixture<HeartBeatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeartBeatComponent ],
      providers: [HttpClient, HttpHandler, VersionHelper]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeartBeatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
