import { Component, OnInit } from '@angular/core';
import { HeartBeatService } from 'src/app/shared/services/heart-beat/heartbeat.service';

@Component({
  selector: 'app-heart-beat',
  templateUrl: './heart-beat.component.html',
  styleUrls: ['./heart-beat.component.css']
})
export class HeartBeatComponent implements OnInit {

  constructor(public hb: HeartBeatService) {
  }

  ngOnInit() {
    this.hb.getHeartBeats('ci');
  }

}
