import { Component, OnInit } from '@angular/core';
import { FormControl, FormBuilder} from '@angular/forms';
import { AuthService } from '../../../shared/services/auth/auth.service';

import { EmailValidation, PasswordValidation, RepeatPasswordEStateMatcher, RepeatPasswordValidator } from '../../../shared/utilities/validator';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})

export class SignUpComponent implements OnInit {
  form: any;
  passwordsMatcher = new RepeatPasswordEStateMatcher;

  constructor(
    public authService: AuthService,
    private formBuilder: FormBuilder
  ) {
    this.form = this.formBuilder.group ( {
      email: new FormControl('', EmailValidation),
      password: new FormControl('', PasswordValidation),
      passwordAgain: new FormControl(''),
    }, { validator: RepeatPasswordValidator });
   }

  ngOnInit() { }

}
