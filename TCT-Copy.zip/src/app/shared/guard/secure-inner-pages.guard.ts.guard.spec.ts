import { TestBed, async, inject } from '@angular/core/testing';
import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFirestoreModule, FirestoreSettingsToken } from '@angular/fire/firestore';
import { environment } from '../../../environments/environment';
import { RouterModule, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SecureInnerPagesGuard } from './secure-inner-pages.guard.ts.guard';

describe('SecureInnerPages.Guard.TsGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({imports: [ AngularFireModule.initializeApp(environment.firebase),
      AngularFireAuthModule,
      AngularFirestoreModule,
      RouterModule,
      RouterTestingModule],
      providers: [SecureInnerPagesGuard, { provide: FirestoreSettingsToken, useValue: {} }]
    });
  });

  it('should ...', inject([SecureInnerPagesGuard], (guard: SecureInnerPagesGuard) => {
    expect(guard).toBeTruthy();
  }));
});
