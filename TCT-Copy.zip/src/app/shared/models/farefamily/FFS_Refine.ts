export class UpsellGroup {
    offerProductGroups: OfferProductGroup[];
}

export class OfferProductGroup {
    offerID: string;
    productID: string;
    flightIDs: string[];
    product: Product;
}

export class FareFamilyOffering {
    productSequence: number;
    offerID: string;
    departure: string;
    arrival: string;
    currency: string;
    productBrandPriceOption: ProductBrandPriceOption[];
}

export class ProductBrandPriceOption {
    productRef: string[];
    product: Product[];
    brandRef: string;
    brand: Brand;
    price: string;
    termsAndConditionsRef: string;
    termsAndConditions: TermsAndConditions;
}

export class Product {
    offerID: string;
    productID: string;
    flightIDs: string[];
    brandID: string;
    brand: Brand;
    tandcID: string;
    termsAndConditions: TermsAndConditions;
    price: Price;
    flightSegment: FlightSegment[];
    totalDuration: string;
    stops: number;
    passengerFlight: PassengerFlight[];
    carrier: string;
    intermidiate: string[];
}

export class Price {
    base: string;
    totalTaxes: string;
    totalFees: string;
    totalPrice: string;
}

export class FlightSegment {
    id: string;
    sequence: number;
    connectionDuration: string;
    boundFlightsInd: boolean;
    flightRef: string;
    flight: Flight;
}

export class Flight {
    carrier: string;
    distance: number;
    duration: string;
    equipment: string;
    flightID: string;
    number: string;
    operatingCarrier: string;
    operatingCarrierName: string;
    arrival: Arrival;
    departure: Departure;
}

export class Arrival {
    date: string;
    location: string;
    terminal: number;
    time: string;
}

export class Departure {
    date: string;
    location: string;
    terminal: number;
    time: string;
}

export class PassengerFlight {
    passengerQuantity: number;
    passengerTypeCode: string;
    FlightProduct: FlightProduct[];
}

export class FlightProduct {
    segmentSequence: number[];
    classOfService: string;
    cabin: string;
    fareBasisCode: string;
    privateFareInd: boolean; // it seems this has changed to FareTypeEnum in v4
    brandRef: string;
    brand: Brand;
}

export class Brand {
    brandAttribute: BrandAttribute[];
    brandID: string;
    name: string;
    tier: number;
    identifier: Identifier;
}

export class Identifier {
    authority: string;
    value: string;
}

export class BrandAttribute {
    classification: string;
    inclusion: string;
}

export class PriceDetail {
    currencyCode: string;
    id: string;
    Base: string;
    TotalTaxes: string;
    TotalFees: string;
    TotalPrice: string;
    PriceBreakdown: PriceBreakdownAir[];
}

export class PriceBreakdownAir {
    quantity: number;
    requestedPassengerType: string;
    amount: Amount;
}

export class Amount {
    Base: string;
    Taxes: Taxes;
    Fees: Fees;
    Total: string;
}

export class Fees {
    TotalFees: string;
}

export class Taxes {
    TotalTaxes: string;
    Tax: Tax[];
}

export class Tax {
    taxCode: string;
    value: string;
}

export class TermsAndConditions {
    tandcID: string;
    validatingCarrier: string;
    baggageAllowanceQuantity: string;
}
