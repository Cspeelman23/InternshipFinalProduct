
export class CatalogOffering {
    CatalogOfferingsIdentifier: string;
    identifier: Identifier;
    currency: string;
    offerID: string;
    productOptions: ProductOption[];
    price: string;
    termsAndConditions: TermsAndConditions;
}

export class TermsAndConditions {
    validatingCarrier: string;
    ExpiryDate: string;
    BaggageAllowance: string;
}

export class ProductOption {
    sequence: number;
    departure: string;
    arrival: string;
    departureCity: string;
    products: Product[];
}

export class Product {
    productID: string;
    totalDuration: string;
    flightSegment: FlightSegment[];
    stops: number;
    passengerFlight: PassengerFlight[];
    carrier: string;
    intermidiate: string[];
    price: number;
}

export class FlightSegment {
    id: string;
    sequence: number;
    connectionDuration: string;
    boundFlightsInd: boolean;
    flightRef: string;
    flight: Flight;
}
export class PassengerFlight {
    passengerQuantity: number;
    passengerTypeCode: string;
    FlightProduct: FlightProduct[];
}
export class FlightProduct {
    segmentSequence: number[];
    classOfService: string;
    cabin: string;
    fareBasisCode: string;
    brand: Brand;
}
export class Flight {
    carrier: string;
    distance: number;
    duration: string;
    equipment: string;
    id: string;
    number: string;
    operatingCarrier: string;
    operatingCarrierName: string;
    arrival: Arrival;
    departure: Departure;
}

export class Arrival {
    date: string;
    location: string;
    terminal: number;
    time: string;
}

export class Departure {
    date: string;
    location: string;
    terminal: number;
    time: string;
}

export class Brand {
    brandAttribute: BrandAttribute[];
    id: string;
    name: string;
    tier: number;
    identifier: Identifier;
}

export class Identifier {
    authority: string;
    value: string;
}

export class BrandAttribute {
    classification: string;
    inclusion: string;
}

export class PriceDetail {
    currencyCode: string;
    id: string;
    Base: string;
    TotalTaxes: string;
    TotalFees: string;
    TotalPrice: string;
    PriceBreakdown: PriceBreakdownAir[];
}

export class PriceBreakdownAir {
    quantity: number;
    requestedPassengerType: string;
    amount: Amount;
}

export class Amount {
    Base: string;
    Taxes: Taxes;
    Fees: Fees;
    Total: string;
}

export class Fees {
    TotalFees: string;
}

export class Taxes {
    TotalTaxes: string;
    Tax: Tax[];
}

export class Tax {
    taxCode: string;
    value: string;
}
