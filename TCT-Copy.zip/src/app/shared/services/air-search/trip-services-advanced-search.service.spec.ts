import { TestBed } from '@angular/core/testing';

import { TripServicesAdvancedSearchService } from './trip-services-advanced-search.service';

describe('TripServicesAdvancedSearchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TripServicesAdvancedSearchService = TestBed.get(TripServicesAdvancedSearchService);
    expect(service).toBeTruthy();
  });
});
