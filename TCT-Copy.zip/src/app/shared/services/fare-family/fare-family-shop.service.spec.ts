import { TestBed } from '@angular/core/testing';
 
import { FareFamilyShopService } from './fare-family-shop.service';
 
describe('FareFamilyShopService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));
 
  it('should be created', () => {
    const service: FareFamilyShopService = TestBed.get(FareFamilyShopService);
    expect(service).toBeTruthy();
  });
});