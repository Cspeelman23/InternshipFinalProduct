import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { Observable, forkJoin } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class HeartBeatService {

  // HTTP Status Codes
  HTTP_200 = 200;	// OK
  HTTP_404 = 404;	// Not Found
  HTTP_405 = 405;	// Method Not Allowed - Getting this for all REST resources deployed in Stackato
  HTTP_500 = 500;	// Internal Server Error - For most of SOAP API calls when payload is not passed

  // Dashboard screen rendering codes
  GREEN = 'G';
  RED = 'R';
  ORANGE = 'O';
  NOT_YET_EXECUTED = 'U';

  flx: string;
  interaction: string;
  ntacSearch: string; ndcSearch: string;
  ntacPrice: string; ndcPrice: string;
  ntacSell: string; ndcSell: string;
  ntacPayment: string;
  ntacBook: string; ndcBook: string;
  ntacRetrieve: string;
  ntacCancel: string;
  ntacTicket: string;

  workbench: string;
  tsSearch: string;
  tsPrice: string;
  tsSell: string;
  tsPayment: string;
  tsTraveler: string;
  tsBook: string;
  tsRetrieve: string;
  tsCancel: string;
  tsTicket: string;

  // NTAC microservice endpoints
  interactionURI: string;
  ntacSearchURI: string; ndcSearchURI: string;
  ntacPriceURI: string; ndcPriceURI: string;
  ntacSellURI: string; ndcSellURI: string;
  ntacPaymentURI: string;
  ntacRetrieveURI: string;
  ntacBookURI: string; ndcBookURI: string;
  ntacCancelURI: string;
  ntacTicketURI: string;

  // TS microservice endpoints
  workbenchURI: string;
  tsSearchURI: string;
  tsPriceURI: string;
  tsSellURI: string;
  tsTravelerURI: string;
  tsPaymentURI: string;
  tsBookURI: string;
  tsRetrieveURI: string;
  tsCancelURI: string;
  tsTicketURI: string;

  // Dashboard ping service contents
  epoch = new Date();

  // Dashboard REST/SOAP call contents
  interactionAPI: string;
  ntacSearchAPI: string; ndcSearchAPI: string; flxSearchAPI: string;
  ntacPriceAPI: string; ndcPriceAPI: string; flxPriceAPI: string;
  ntacTravelerAPI: string;
  ntacPaymentAPI: string;
  ntacRetrieveAPI: string; ndcRetrieveAPI: string; flxRetrieveAPI: string;
  ntacRetrievePNRAPI: string; ndcRetrievePNRAPI: string; flxRetrievePNRAPI: string;
  ntacETAPI: string; ndcETAPI: string; flxETAPI: string;
  ntacCancelPreTktAPI: string; ndcCancelPreTktAPI: string; flxCancelPreTktAPI: string;

  constructor(private http: HttpClient) { }

  initializeTSURIs() {
    const tsBaseURL = environment.tripservices.tsProps.baseURL;
    this.workbenchURI = tsBaseURL + environment.tripservices.tsProps.tsInitiateWFContext;
    this.tsSearchURI = environment.tripservices.tsProps.lowfareURI;
    this.tsPriceURI = tsBaseURL + environment.tripservices.tsProps.tsPriceContext;
    this.tsSellURI = tsBaseURL + environment.tripservices.tsProps.tsSellContext;
    this.tsTravelerURI = tsBaseURL + environment.tripservices.tsProps.tsTravelerContext;
    this.tsPaymentURI = tsBaseURL + environment.tripservices.tsProps.tsPaymentContext;
    this.tsBookURI = tsBaseURL + environment.tripservices.tsProps.tsBookContext;
    this.tsRetrieveURI = tsBaseURL + environment.tripservices.tsProps.tsRetrieveContext;
    this.tsCancelURI = tsBaseURL + environment.tripservices.tsProps.tsCancelContext;
    this.tsTicketURI = tsBaseURL + environment.tripservices.tsProps.tsTicketContext;
  }

  initializeNTACURIs(route: string) {
    const ntacBaseURL = environment.tripservices.ntacProps.baseURL + route;
    this.interactionURI = ntacBaseURL + environment.tripservices.ntacProps.ntacInitiateWFContext;
    this.ntacSearchURI = ntacBaseURL + environment.tripservices.ntacProps.ntacSearchContext;
    this.ntacPriceURI = ntacBaseURL + environment.tripservices.ntacProps.ntacPriceContext;
    this.ntacSellURI = ntacBaseURL + environment.tripservices.ntacProps.ntacSellContext;
    this.ntacPaymentURI = ntacBaseURL + environment.tripservices.ntacProps.ntacPaymentContext;
    this.ntacBookURI = ntacBaseURL + environment.tripservices.ntacProps.ntacBookContext;
    this.ntacRetrieveURI = ntacBaseURL + environment.tripservices.ntacProps.ntacRetrieveContext;
    this.ntacCancelURI = ntacBaseURL + environment.tripservices.ntacProps.ntacCancelContext;
    this.ntacTicketURI = ntacBaseURL + environment.tripservices.ntacProps.ntacTicketContext;
  }

  initializeDirectURIs(route: string) {

    this.interactionURI = environment.tripservices.dashboardDirectProps.interactionBase + route
                        + environment.tripservices.dashboardDirectProps.interactionContext;
    this.ntacSearchURI = environment.tripservices.dashboardDirectProps.ntacSearchBase + route
                        + environment.tripservices.dashboardDirectProps.ntacSearchContext;
    this.ndcSearchURI = environment.tripservices.dashboardDirectProps.ndcSearchBase + route
                        + environment.tripservices.dashboardDirectProps.ndcSearchContext;
    this.ntacPriceURI = environment.tripservices.dashboardDirectProps.ntacPriceBase + route
                        + environment.tripservices.dashboardDirectProps.ntacPriceContext;
    this.ndcPriceURI = environment.tripservices.dashboardDirectProps.ndcPriceBase + route
                        + environment.tripservices.dashboardDirectProps.ndcPriceContext;
    this.ntacSellURI = environment.tripservices.dashboardDirectProps.ntacSellBase + route
                        + environment.tripservices.dashboardDirectProps.ntacSellContext;
    this.ndcSellURI = environment.tripservices.dashboardDirectProps.ndcSellBase + route
                      + environment.tripservices.dashboardDirectProps.ndcSellContext;
    this.ntacBookURI = environment.tripservices.dashboardDirectProps.ntacBookBase + route
                    + environment.tripservices.dashboardDirectProps.ntacBookContext;
    this.ndcBookURI = environment.tripservices.dashboardDirectProps.ndcBookBase + route
                    + environment.tripservices.dashboardDirectProps.ndcBookContext;
  }

  public getHeartBeats(env: string): Observable<any[]> {

    const proxyServer = 'https://cors-anywhere.herokuapp.com/';
    console.log('entered pingRESTServer');

    // this.initializeDirectURIs('-' + env + '.adc-dv-gf.travelport.com:443');
    this.initializeNTACURIs('/' + env);
    this.initializeTSURIs();

    const ntac1 = this.http.head(proxyServer + this.interactionURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.interaction = this.evaluateHeartBeat(this.interactionURI, error.status)
                        );
    const ntac2 = this.http.head(proxyServer + this.ntacSearchURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.ntacSearch = this.evaluateHeartBeat(this.ntacSearchURI, error.status)
                        );
    const ntac3 = this.http.head(proxyServer + this.ntacPriceURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.ntacPrice = this.evaluateHeartBeat(this.ntacPriceURI, error.status)
                        );
    const ntac4 = this.http.head(proxyServer + this.ntacSellURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.ntacSell = this.evaluateHeartBeat(this.ntacSellURI, error.status)
                        );
    const ntac5 = this.http.head(proxyServer + this.ntacPaymentURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.ntacPayment = this.evaluateHeartBeat(this.ntacPaymentURI, error.status)
                        );
    const ntac6 = this.http.head(proxyServer + this.ntacBookURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.ntacBook = this.evaluateHeartBeat(this.ntacBookURI, error.status)
                        );
    const ntac7 = this.http.head(proxyServer + this.ntacRetrieveURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.ntacRetrieve = this.evaluateHeartBeat(this.ntacRetrieveURI, error.status)
                        );
    const ntac8 = this.http.head(proxyServer + this.ntacCancelURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.ntacCancel = this.evaluateHeartBeat(this.ntacCancelURI, error.status)
                        );
    const ntac9 = this.http.head(proxyServer + this.ntacTicketURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.ntacTicket = this.evaluateHeartBeat(this.ntacTicketURI, error.status)
                        );

    /*const headers = new  HttpHeaders().set("proxy", "http://dv-outbound-proxy.tvlport.com:30375");
    let six = this.http.head(environment.tripservices.dashboardProps.flxNonProdURL, { headers : headers })
                        .subscribe(
                          data => console.log(data),
                          error => this.flx = this.evaluateHeartBeat(environment.tripservices.dashboardProps.flxNonProdURL, error.status)
                        );*/

    const ts1 = this.http.head(proxyServer + this.workbenchURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.workbench = this.evaluateHeartBeat(this.workbenchURI, error.status)
                        );
    const ts2 = this.http.head(proxyServer + this.tsSearchURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.tsSearch = this.evaluateHeartBeat(this.tsSearchURI, error.status)
                        );
    const ts3 = this.http.head(proxyServer + this.tsPriceURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.tsPrice = this.evaluateHeartBeat(this.tsPriceURI, error.status)
                        );
    const ts4 = this.http.head(proxyServer + this.tsSellURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.tsSell = this.evaluateHeartBeat(this.tsSellURI, error.status)
                        );
    const ts5 = this.http.head(proxyServer + this.tsTravelerURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.tsTraveler = this.evaluateHeartBeat(this.tsTravelerURI, error.status)
                        );
    const ts6 = this.http.head(proxyServer + this.tsTravelerURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.tsTraveler = this.evaluateHeartBeat(this.tsTravelerURI, error.status)
                        );
    const ts7 = this.http.head(proxyServer + this.tsBookURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.tsBook = this.evaluateHeartBeat(this.tsBookURI, error.status)
                        );
    const ts8 = this.http.head(proxyServer + this.tsRetrieveURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.tsRetrieve = this.evaluateHeartBeat(this.tsRetrieveURI, error.status)
                        );
    const ts9 = this.http.head(proxyServer + this.tsCancelURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.tsCancel = this.evaluateHeartBeat(this.tsCancelURI, error.status)
                        );
    const ts10 = this.http.head(proxyServer + this.tsTicketURI)
                        .subscribe(
                          data => console.log(data),
                          error => this.tsTicket = this.evaluateHeartBeat(this.tsTicketURI, error.status)
                        );

    return forkJoin([ ntac1, ntac2, ntac3, ntac4, ntac5, ntac6, ntac7, ntac8, ntac9,
                    ts1, ts2, ts3, ts4, ts5, ts6, ts7, ts8, ts9, ts10 ]);
  }

  evaluateHeartBeat(url: string, statusCode: number) {
    let statusColor: string = this.NOT_YET_EXECUTED;
    console.log('evaluateHeartBeat, statusCode=>'+ statusCode);
    if (statusCode === this.HTTP_404) {
      statusColor = this.RED;
      console.log('##### PINGING:' + url + ' statusColor = RED; statusColor=' + statusColor);
    } else if (statusCode === this.HTTP_405 || statusCode === this.HTTP_200) {
      statusColor = this.GREEN;
      console.log('##### PINGING:' + url + ' statusColor = GREEN; statusColor=' + statusColor);
    } else {
      statusColor = this.ORANGE;
      console.log('##### PINGING:' + url + ' statusColor = ORANGE; statusColor=' + statusColor);
    }
    return statusColor;
  }
}
