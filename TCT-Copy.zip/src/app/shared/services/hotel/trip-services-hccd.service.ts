/*
1. Write a basicauth provider, possibly a pipe.  Use the pipe to inject the needed headers.

*/

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { getAllDebugNodes } from '@angular/core/src/debug/debug_node';
import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TripServicesHCCDService {
  constructor( private httpClient: HttpClient ) {

  }

  BuildHeaders() {
  }

  getAll(checkinDate: string,
         checkoutDate: string,
         numberOfGuests: string,
         radius: string,
         lat: string,
         long: string ): Observable<any> {

    let headers: HttpHeaders = new HttpHeaders();
    console.log('BuildHeaders');
    headers = headers.append('accept', 'application/json');
    // tslint:disable-next-line:max-line-length
    headers = headers.append('Authorization', 'Basic R1dTL1BDQ01PQkxFOk1vYmlsZTIwMTY=, Token tvlport_app_id=travelportAPI-AqDxslUiTZ028olU4KyTJf95');
    headers = headers.append('accessProfile', 'DynGalileoCopy_8ZF5');
    headers = headers.append('hotelContent', 'yes');
    headers = headers.append('imageSize', 'L');
    headers = headers.append('sort', 'rating');
    console.log('TripServicesHCCDService::headers ' + JSON.stringify(headers));
    const baseUrl = environment.tripservices.hotelProps.baseUrl;
    const resourcePath = environment.tripservices.hotelProps.hotelShopBase;
    let resourceFilter = 'properties?checkinDate=' + checkinDate + '&';
    resourceFilter += 'checkoutDate=' + checkoutDate + '&';
    resourceFilter += 'numberOfGuests=' + numberOfGuests + '&';
    resourceFilter += 'radius=' + radius + '&';
    resourceFilter += 'lat=' + lat + '&';
    resourceFilter += 'lon=' + long;
    const finalUrl = baseUrl + resourcePath + resourceFilter;
    console.log('HCCDService::getAll URL=' + finalUrl);
    return this.httpClient.get( finalUrl,
      {headers: headers});
  }


}
