import { TestBed } from '@angular/core/testing';

import { ReqRespHistoryService } from './req-resp-history.service';

describe('ReqRespHistoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReqRespHistoryService = TestBed.get(ReqRespHistoryService);
    expect(service).toBeTruthy();
  });
});
