import { Inject, Injectable } from '@angular/core';
import { LOCAL_STORAGE, StorageService } from 'ngx-webstorage-service';
import { HistoryItem } from '../../models/requestResponseHistory/reqresphistory';
import { environment } from '../../../../environments/environment';



@Injectable({
  providedIn: 'root'
})
export class ReqRespHistoryService {
  ReqRespHistoryList: HistoryItem[];
  STORAGE_KEY = 'local_reqRespHistory';

  constructor(@Inject(LOCAL_STORAGE) private storage: StorageService) { }

  storeHistoryItem( historyItem: HistoryItem) {
    // Get the historylist from localstorage.  Note that if it isnt there 
    // it returns an empty array.
    this.ReqRespHistoryList = this.storage.get(this.STORAGE_KEY) || [];
    // If the list has 99 entries, shift the first entry out so we can add the new one.
    if (this.ReqRespHistoryList.length >= environment.appDefaults.historyLength) {
      const firstHistoryItem = this.ReqRespHistoryList.shift();
    }
    this.ReqRespHistoryList.push(historyItem);
    this.storage.set(this.STORAGE_KEY, this.ReqRespHistoryList);
  }

  getHistoryItemList(): HistoryItem[] {
    this.ReqRespHistoryList = this.storage.get(this.STORAGE_KEY) || [];
    return this.ReqRespHistoryList;
  }
}
