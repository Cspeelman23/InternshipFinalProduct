import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class TripservicesOAuthService {

  constructor(private httpClient: HttpClient) { }

  getNewToken({ userID, pWord, clientId, clientSecret }:
    { userID: string; pWord: string; clientId: string; clientSecret: string; }): Observable<any> {
    let headers: HttpHeaders = new HttpHeaders();
    console.log('getNewToken::BuildHeaders');
    headers = headers.append('Access-Control-Allow-Origin', '*');
    headers = headers.append('grant_type', 'password');
    headers = headers.append('username', userID);
    headers = headers.append('password', pWord);
    headers = headers.append('scope', 'openid%20AkanaCorporate');
    headers = headers.append('client_id', clientId);
    headers = headers.append('client_secret', clientSecret);
    console.log('getNewToken::Headers: ' + JSON.stringify(headers));
    const finalUrl = environment.tripservices.authentication.authUrl;
    return this.httpClient.get( finalUrl,
      {headers: headers});
  }
}
