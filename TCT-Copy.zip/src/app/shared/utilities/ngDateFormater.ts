import {NgbDate, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';

export class NgDateFormater {
    format(date: NgbDate): string {
        // tslint:disable-next-line:prefer-const
        let sYear = date.year.toString();
        let sDay = date.day.toString();
        let sMonth = date.month.toString();
        if (sDay.length === 1) { sDay = '0' + sDay; }
        if (sMonth.length === 1) { sMonth = '0' + sMonth; }
        return sYear + sMonth + sDay;
      }
}
