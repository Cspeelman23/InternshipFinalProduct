import { appversion } from '../../../environments/version';

export class VersionHelper {
    constructor( ) {
    }
    versionString(): string {
        const lVersion  = 'v' + appversion.Version.VersionMajor + '.'
            + appversion.Version.VersionMinor + '.'
            + appversion.Version.VersionPatch + '.'
            + appversion.Version.VersionBuild;
        return lVersion;
    }
}