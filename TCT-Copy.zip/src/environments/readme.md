# Version strategy

- **Verison Major**: is the major version number.  It bumps at the begining of the year and is used to designate how many years this app has been in service.

- **Version Minor**: is the minor version number.  It is bumped each time we have added significant features to the demo app.  If we upgrade to a set of new services, new model etcetera.

- **Version Patch**: This depicts the patch level we are at for this current Major.Minor.  It is usually a zero unless the app is released and then a defect is detected and a patch is created.

- **VersionBuild**: For each build that we do in CI/CD we bump this value. We will use the first ten characters of the GIT Commit ID: **15b8f61f2d**b21df236c78bf410a9aa6d88b05076

- **VersionStringSample**: v1.0.0.15b8f61f2d
