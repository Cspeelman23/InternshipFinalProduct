# Application Branch Strategy

## Getting started Step 1 Setting up your LDAP

[Skip to getting started on a feature](#start-a-new-feature)

To get started you will need to clone the repo from your remote [OnPremise GitBucket](https://gitbucket.tvlport.com/DemandAPI/tripServices-content-tour). You will need a Unix LDAP credential to use GitBucket.  To get a Unix LDAP credential please see the following link:
[TOPS Linux LDAP Request](http://topsprojectportal.tvlport.com/LinuxAccesRequest.aspx)

- Roles required:
- Stackato_Cloud_Foundry_Developers
- Cloud_Foundry-Non_Prod-COEOrg
- REST Framework Support
- CI-Tools
- ODA_Developers

How to create a TOPS request

- Click the “Create A New Request” link
- Enter for the “Target User’s LAN ID” your Windows login
- For RequestType select “Modify Existing Group Membership”
- Press the Continue button
- Your current assigned roles are listed in the “Selected Roles” section
- Press the Update link
- Select all of the ODBC required roles in the Role Selection dialog by selecting the check box for each role
- Press the Continue button in the dialog when all roles are selected
- The selected roles will be listed in the “Groups To Be Added” section of the “Creating a new request” page
- Press the Submit Request button to submit the role request
- You will receive an email stating that the request has been received, and an email when the request has been completed
- Allow at least a week for role accesses to be granted

## Getting started Step 2 Pulling your repository

Pulling the project repository to your desktop.
Create a folder similar to the following, note use NO SPACES as spaces cause scripting problems: c:\dev\tripservices\tct
Execute the following git command

`git clone https://gitbucket.tvlport.com/git/DemandAPI/tripServices-content-tour.git`
  
Note that this pulls ALL branches of the repo to your desktop.

## Start A New Feature

Navigate to your project folder likely `c:\dev\tripservices\tct`
Quick note on feature naming conventions: Use something descriptive followed by the Jira feature number you are working on: `hotel-results-binding-TPSVCS-2211`

- First Execute: `git checkout -b YourFeatureBranchName` which creates the branch local to your desktop. ***Note: Branch names are case sensitive so if you are focused on Camel Case in your Branch names you might end up accidentally creating two branches.***
- Second execute: `git push` which pushes and creates a branch in the remote aka GitBucket.  This makes it possible for us to do code reviews.

Now you can start your work on that branch...
To avoid merge conflicts it is **Highly** encouraged to pull any changes from the master/dev branch into your feature branch making certain you are in synch with the origin of your branch.
That process looks like the following:

- `git checkout master` which switches to the origin.  This could be any origin but master is referenced here as the "prefered" way-
- `git pull` pulls down the latest changes to the origin
- `git checkout FeatureBranch` Puts us back on the feature branch so now the origin with new changes and the FeatureBranch with your ongoing changes are both in place.
- `git merge master` which merges the changes from the origin to your feature branch.  If there are any conflicts, you MUST deal with them as soon as they happen.  Fix them and get your feature branch in good working order.
- `git push` After dealing with ay merge conflicts, push your merged code to your remote and continue your work.

This is common housekeeping for a feature branch and should be done often.  I commonly write scripts to make this easier and set reminders.

All coding is done and now you are ready to create the pull request.
Commit to local all changes using the following process.

- `git add .` Adds all new changes/additions/deletes etcetera to your local stage
- `git commit -m "Your Commit message; make it meaningful"` Make the comments somewhat useful, not, adding stuff or something trivial.
- `git push` pushes the changes to your remote.

Time to do the pull request.  Now go to gitbucket web and create a pull request, add your team lead as the reviewer.  Also send the pull request link to Ken and Marc. Team Lead once all review comments have been addressed will do the merge and tag in master

## Adding a tag prior to deploy

- Bump the version number in environments/version.ts ***Note: Look at capturing the version in Package.json***
- To tag the master branch first do a `git checkout master` to put yourself onto the master branch
- Now do a `git tag <YourTagString>` which applies the tag to your local repo.
- Now do a `git push --tags` to push the tag up to your remote repo


