# Retrieve the latest Commit id using the --short so we only get the first six characters.
$gitCommitId = git rev-parse --short HEAD

# Insert the build number into the version string.
((Get-Content -path ./src/environments/version.ts) -replace "VersionBuild:'%'", ("VersionBuild:'" + $gitCommitId + "'")) | Set-Content -Path ./src/environments/version.ts

# Build the application.  Note the --outputHashing=all ensures browser cache busting.
ng build --outputHashing=all

# DEploy to Firebase.
firebase deploy

