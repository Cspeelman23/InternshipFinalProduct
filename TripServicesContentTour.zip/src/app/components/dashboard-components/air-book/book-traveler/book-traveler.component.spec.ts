import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookTravelerComponent } from './book-traveler.component';

describe('BookTravelerComponent', () => {
  let component: BookTravelerComponent;
  let fixture: ComponentFixture<BookTravelerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookTravelerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookTravelerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
