import { Component, OnInit } from '@angular/core';
import {
  FormGroup, FormBuilder, FormArray
} from '@angular/forms';
import { TripServicesAirBookService } from 'src/app/shared/services/air-book/trip-services-air-book.service';
import { TripServicesGDSService } from 'src/app/shared/services/air-search/trip-services-gds.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

export interface PasengerType {
  value: string;
  view: string;
}

export interface Title {
  value: string;
  viewValue: string;
}


@Component({
  selector: 'app-book-traveler',
  templateUrl: './book-traveler.component.html',
  styleUrls: ['./book-traveler.component.css']
})
export class BookTravelerComponent implements OnInit {
  searchForm: FormGroup;
  pasengerTypeMap = new Map<string, string>();

  prefix: Title[] = [
    { value: 'mr-0', viewValue: 'Mr' },
    { value: 'Mrs-1', viewValue: 'Mrs' },
    { value: 'Ms-2', viewValue: 'Ms' },
    { value: 'Miss-3', viewValue: 'Miss' }
  ];

  constructor(private bookService: TripServicesAirBookService, private gdsService: TripServicesGDSService,
    private router: Router, private fb: FormBuilder, private spinner: NgxSpinnerService) { }

  travelerRequest: FormGroup;
  pasengerCriteria: [];
  pasengersList: string[] = [];
  num = 0;

  ngOnInit() {
    this.pasengerTypeMap.set('ADT', 'ADULT');
    this.pasengerTypeMap.set('CHD', 'CHILD');
    this.pasengerTypeMap.set('INF', 'INFANT');
    this.pasengerCriteria = this.gdsService.getPassengerCriteria();
    // console.log(this.pasengerCriteria);
    this.pasengerCriteria.forEach(e => {
      this.num = e['number'];
      for (let i = 0; i < this.num; i++) {
        this.pasengersList.push(e['value']);
      }
    });
    // console.log(this.pasengersList);

    this.travelerRequest = this.fb.group({
      request: this.fb.array([])
    });
    this.createRequest(); // Creates reactive form

    // this.travelerRequest.valueChanges.subscribe(req => {
    //   this.bookService.travelerReq = req;
    // });
  }

  createRequest() {
    const requestList = <FormArray>this.travelerRequest.get('request');
    for (let i = 0; i < this.pasengersList.length; i++) {
      requestList.push(this.fb.group({
        Traveler: this.fb.group({
          passengerTypeCode: this.pasengersList[i],
          PersonName: this.createPersonName(this.pasengersList[i]),
          Telephone: this.fb.array([this.createTelephone()]),
          Address: this.fb.array([this.createAddress()]),
          Email: this.fb.array([this.createEmail()]),
          CustomerLoyalty: this.fb.array([this.createCustomerLoyalty()]),
          TravelDocument: this.fb.array([this.createTravelDocument()])
        })
      })
      );
    }
  }

  createPersonName(pasengerType: string): FormGroup {
    return this.fb.group({
      '@type': 'PersonNameDetail',
      Prefix: [''],
      Given: [''],
      Middle: [''],
      Surname: [''],
      Suffix: pasengerType
    });
  }

  createTelephone(): FormGroup {
    return this.fb.group({
      '@type': 'Telephone',
      countryAccessCode: [''],
      areaCityCode: [''],
      phoneNumber: [''],
      extension: [''],
      id: [''],
      cityCode: [''],
      role: ['']
    });
  }

  createAddress(): FormGroup {
    return this.fb.group({
      '@type': 'Address',
      role: [''],
      id: [''],
      BldgRoom: this.fb.group({
        value: [''],
        buldingInd: true
      }),
      Number: this.fb.group({
        value: [''],
      }),
      City: [''],
      Country: this.fb.group({
        value: [''],
      }),
      PostalCode: ['']
    });
  }

  createEmail(): FormGroup {
    return this.fb.group({
      comment: [''],
      value: ['']
    });
  }

  createCustomerLoyalty(): FormGroup {
    return this.fb.group({
      supplier: [''],
      value: ['']
    });
  }

  createTravelDocument(): FormGroup {
    return this.fb.group({
      '@type': 'TravelDocument',
      docNumber: [''],
      docType: [''],
      expireDate: [''],
      issueCountry: [''],
      birthDate: [''],
      birthCountry: [''],
      Gender: [''],
      PersonName: this.fb.group({
        '@type': 'PersonName',
        Given: [''],
        Middle: [''],
        Surname: ['']
      })
    });
  }

  addTelephone(request) {
    const telephone = <FormArray>request.get('Traveler.Telephone');
    telephone.push(this.createTelephone());
  }

  removeTelephone(index, request) {
    const telephone = <FormArray>request.get('Traveler.Telephone');
    telephone.removeAt(index);
  }

  addAddress(request) {
    const address = <FormArray>request.get('Traveler.Address');
    address.push(this.createAddress());
  }

  removeAddress(index, request) {
    const address = <FormArray>request.get('Traveler.Address');
    address.removeAt(index);
  }

  addEmail(request) {
    const email = <FormArray>request.get('Traveler.Email');
    email.push(this.createEmail());
  }

  removeEmail(index, request) {
    const email = <FormArray>request.get('Traveler.Email');
    email.removeAt(index);
  }

  addCustomerLoyalty(request) {
    const customerLoyalty = <FormArray>request.get('Traveler.CustomerLoyalty');
    customerLoyalty.push(this.createCustomerLoyalty());
  }

  removeCustomerLoyalty(index, request) {
    const customerLoyalty = <FormArray>request.get('Traveler.CustomerLoyalty');
    customerLoyalty.removeAt(index);
  }

  addTravelDocument(request) {
    const travelDocument = <FormArray>request.get('Traveler.TravelDocument');
    travelDocument.push(this.createTravelDocument());
  }

  removeTravelDocument(index, request) {
    const travelDocument = <FormArray>request.get('Traveler.TravelDocument');
    travelDocument.removeAt(index);
  }

  get request() {
    return this.travelerRequest.get('request') as FormArray;
  }

  getTelephone(req) {
    return req.controls.Traveler.controls.Telephone.controls;
  }

  getAddress(req) {
    return req.controls.Traveler.controls.Address.controls;
  }

  getEmail(req) {
    return req.controls.Traveler.controls.Email.controls;
  }

  getCustomerLoyalty(req) {
    return req.controls.Traveler.controls.CustomerLoyalty.controls;
  }

  getTravelDocument(req) {
    return req.controls.Traveler.controls.TravelDocument.controls;
  }

  setDefaultValues(request: FormGroup) {
    // console.log(request);
    // request.get('Traveler.PersonName.Prefix').setValue('Mr');
    request.get('Traveler.PersonName.Given').setValue('Muthukumaran');
    request.get('Traveler.PersonName.Surname').setValue('Selvaraju');
    request.get('Traveler.Telephone.0.countryAccessCode').setValue('1');
    request.get('Traveler.Telephone.0.areaCityCode').setValue('909');
    request.get('Traveler.Telephone.0.phoneNumber').setValue('212456121');
    request.get('Traveler.Telephone.0.extension').setValue('1234');
    request.get('Traveler.Telephone.0.id').setValue('4');
    request.get('Traveler.Telephone.0.cityCode').setValue('ORD');
    request.get('Traveler.Telephone.0.role').setValue('Office');
    request.get('Traveler.Address.0.role').setValue('Delivery');
    request.get('Traveler.Address.0.id').setValue('address_1');
    request.get('Traveler.Address.0.BldgRoom.value').setValue('Bldg H');
    request.get('Traveler.Address.0.BldgRoom.buldingInd').setValue(true);
    request.get('Traveler.Address.0.Number.value').setValue('563');
    request.get('Traveler.Address.0.City').setValue('Los Angeles');
    request.get('Traveler.Address.0.Country.value').setValue('US');
    request.get('Traveler.Address.0.PostalCode').setValue('91711-3323');
    request.get('Traveler.Email.0.comment').setValue('Primary Email Id');
    request.get('Traveler.Email.0.value').setValue('traveler@travelport.com');
    request.get('Traveler.CustomerLoyalty.0.supplier').setValue('DL');
    request.get('Traveler.CustomerLoyalty.0.value').setValue('DL2071983684');
    request.get('Traveler.TravelDocument.0.docNumber').setValue('H294F4');
    request.get('Traveler.TravelDocument.0.docType').setValue('Passport');
    request.get('Traveler.TravelDocument.0.expireDate').setValue('2027-02-22');
    request.get('Traveler.TravelDocument.0.issueCountry').setValue('IND');
    request.get('Traveler.TravelDocument.0.birthDate').setValue('1984-02-22');
    request.get('Traveler.TravelDocument.0.birthCountry').setValue('IND');
    request.get('Traveler.TravelDocument.0.Gender').setValue('Male');
    request.get('Traveler.TravelDocument.0.PersonName.Given').setValue('Muthu');
    request.get('Traveler.TravelDocument.0.PersonName.Middle').setValue('Kumaran');
    request.get('Traveler.TravelDocument.0.PersonName.Surname').setValue('Selvaraju');
  }

  onNext() {
    // let list = this.bookService.travelerReq;
    this.spinner.show();
    (<FormArray>this.travelerRequest.get('request')).controls.forEach(req => {
      // console.log(req.get('Traveler'));
      if (req.get('Traveler.Address').untouched) {
        req.get('Traveler.Address').disable();
      }
      if (req.get('Traveler.CustomerLoyalty').untouched) {
        req.get('Traveler.CustomerLoyalty').disable();
      }
      if (req.get('Traveler.TravelDocument').untouched) {
        req.get('Traveler.TravelDocument').disable();
      }
      console.log(req.value);
      this.bookService.addTravelerPost(req.value).subscribe(data => {
        console.log(data);
      });
    });
    // this.bookService.bookHoldCommitPost().subscribe(response => {
    //   console.log(response);
      this.spinner.hide();
      this.router.navigate(['/dashboard/trip-services-gds/app-trip-services-book']);
    // });
  }
}
