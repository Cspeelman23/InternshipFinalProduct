import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TripServicesBookComponent } from './trip-services-book.component';

describe('TripServicesBookComponent', () => {
  let component: TripServicesBookComponent;
  let fixture: ComponentFixture<TripServicesBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TripServicesBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TripServicesBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
