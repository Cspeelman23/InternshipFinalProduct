import { Component, OnInit } from '@angular/core';
import { TripServicesAirBookService } from 'src/app/shared/services/air-book/trip-services-air-book.service';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';

@Component({
  selector: 'app-trip-services-book',
  templateUrl: './trip-services-book.component.html',
  styleUrls: ['./trip-services-book.component.css']
})
export class TripServicesBookComponent implements OnInit {

  constructor(private bookService: TripServicesAirBookService,
    private fb: FormBuilder) { }

  step = 1;

  ngOnInit() {
    // this.bookService.responseData.subscribe(data => {
    //   return this.catalogOfferingList = data;
    // });
  }
  onTravelerNext() {
    // console.log(this.bookService.travelerReq);
    let list = this.bookService.travelerReq;
    console.log(list['request']);
    list['request'].forEach(element => {
      console.log(JSON.stringify(element));
      this.bookService.addTravelerPost(element).subscribe(data => {
        console.log(data);
      });
    });
    this.step++;
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }

  commit() {
    this.bookService.bookHoldCommitPost().subscribe(response => {
      console.log(response);
      // this.spinner.hide();
      // this.router.navigate(['/dashboard/trip-services-gds/app-trip-services-book']);
    });
  }
}
