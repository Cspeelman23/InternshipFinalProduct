import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TripServicesAirResultsComponent } from './trip-services-air-results.component';

/* describe('TripServicesAirResultsComponent', () => {
  let component: TripServicesAirResultsComponent;
  let fixture: ComponentFixture<TripServicesAirResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TripServicesAirResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TripServicesAirResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
}); */
