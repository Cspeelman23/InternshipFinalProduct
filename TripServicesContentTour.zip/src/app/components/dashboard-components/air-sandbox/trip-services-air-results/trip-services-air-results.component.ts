import { Component, OnInit } from '@angular/core';
import { TripServicesAirService } from 'src/app/shared/services/air-sandbox/trip-services-air.service';
import { CatalogOffering } from 'src/app/shared/models/gds/Models';
import { environment } from '../../../../../environments/environment';
import { MatDialog, MatDialogRef } from '@angular/material';
// import { TripSearchFlightsDetailsComponent } from '../../../trip-search-flights/trip-search-flights-details.component';

@Component({
  selector: 'app-trip-services-air-results',
  templateUrl: './trip-services-air-results.component.html',
  styleUrls: ['./trip-services-air-results.component.css']
})
export class TripServicesAirResultsComponent implements OnInit {

  carrierIconBaseUrl: any;

  catalogOfferingList: CatalogOffering[] = [];
  // dialogRef: MatDialogRef<TripSearchFlightsDetailsComponent>;
  catalogOfferingsRequest: any;
  departure: any;
  arrival: any;
  date: any;
  catalogOfferingsResponse: any;
  responseCatalogOfferingList: any[];
  identifier: any;
  currencyCode: any;

  constructor(public airService: TripServicesAirService, private dialog: MatDialog) {
    this.carrierIconBaseUrl = environment.commonCollateralUrl.airIconsVTNG;
  }

  ngOnInit() {
    this.catalogOfferingList = this.airService.getCatalogOfferings();
    // Getting request & response from GDS service to map the value in this component
    this.catalogOfferingsRequest = this.airService.catalogOfferingsQueryRequest['CatalogOfferingsQueryRequest']['CatalogOfferingsRequest'];
    this.departure = this.catalogOfferingsRequest[0]['SearchCriteriaFlight'][0]['From']['value'];
    this.arrival = this.catalogOfferingsRequest[0]['SearchCriteriaFlight'][0]['To']['value'];
    this.date = this.catalogOfferingsRequest[0]['SearchCriteriaFlight'][0]['departureDate'];
    this.catalogOfferingsResponse = this.airService.response['CatalogOfferingsResponse'];

    // Getting list of catalogOffering for processing
    this.responseCatalogOfferingList = this.catalogOfferingsResponse['CatalogOfferings']['CatalogOffering'];
    this.identifier = this.catalogOfferingsResponse['CatalogOfferings']['Identifier']['value'];
    this.currencyCode = this.catalogOfferingsResponse['CatalogOfferings']['DefaultCurrency']['code'];
  }

  showMatDialog(offerId) {
    /*this.dialogRef = this.dialog.open(TripSearchFlightsDetailsComponent, {
      data: {
        id: offerId
      },
      panelClass: 'dialog'
    });
    this.dialogRef.afterClosed().subscribe(
      result => {
        if (result !== undefined) {
          console.log(result);
        }
      }
    );*/
  }
}
