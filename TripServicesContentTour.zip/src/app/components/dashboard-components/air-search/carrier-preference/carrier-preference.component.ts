import { Component, OnInit, ViewChild } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { RefDataService } from '../../../../shared/services/ref-data/ref-data.service';
import {ChipsAutocompleteComponent} from '../chips-autocomplete/chips-autocomplete.component';

@Component({
  selector: 'app-carrier-preference',
  templateUrl: './carrier-preference.component.html',
  styleUrls: ['./carrier-preference.component.css']
})
export class CarrierPreferenceComponent implements OnInit {
  data: {
    isAllSelected: boolean;
    isAllCollapsed: boolean;
    indeterminate: boolean;
    ParentChildchecklist: any[];
  };
  selectedData: string[];
  parentChildElement: any;
  childElement: any;
  carriers: any;
  message: any;


  changingValue: Subject<any> = new Subject();

  constructor(private carrierGroupService: RefDataService) {
    this.data = {
      isAllSelected: false,
      isAllCollapsed: true,
      indeterminate: false,
      ParentChildchecklist: []
    };
    this.parentChildElement = {};
    this.childElement = {};
    this.selectedData = [];
    this.carriers = [];
  }

  ngOnInit() {
    this.getAirlinesData();
    this.carrierGroupService.currentAirline.subscribe(message => this.carriers = message);
  }

  ngAfterContentChecked() {
    this.changeAirline(this.carriers)
  }

  @ViewChild("chipsAutocompleteComponent") chipsAutocompleteComponent: ChipsAutocompleteComponent;

  receiveMessage($event) {
    let parentChildList = '';
    let childListValues = '';
    this.data.ParentChildchecklist.forEach((childListData) => {
      parentChildList = childListData;
      childListValues = childListData.childList;
      childListData.childList.forEach((selectedData) => {
        let airlineName = selectedData.value
        if (airlineName === $event) {
          selectedData.isSelected = false;
        }
      });
      this.childCheck(parentChildList, childListValues);
    });
  }

  resetCarrier() {
    let parentChildList = '';
    let childListValues = '';
    this.data.ParentChildchecklist.forEach((childListData) => {
      parentChildList = childListData;
      childListValues = childListData.childList;
      childListData.childList.forEach((selectedData) => {
        selectedData.isSelected = false;
      });
      this.childCheck(parentChildList, childListValues);
    });
    this.chipsAutocompleteComponent.resetAutoChipData();
    this.carrierGroupService.changeAirline([]);
  }

  changeAirline(element) {
    this.carrierGroupService.changeAirline(element);
  }

  getAirlinesData(): void {
    this.carrierGroupService.getAirlinesData().subscribe(data => {
      let ParentChildchecklist = [];
      let childElementArr = [];
      let i = 1;
      let j;
      let parentTree = data;
      for (let parentName in parentTree) {
        this.parentChildElement.id = i++;
        this.parentChildElement.value = parentName;
        this.parentChildElement.isSelected = false;
        this.parentChildElement.isClosed = true;
        j = 1;
        let parentobject = parentTree[parentName];
        for (let objectname in parentobject) {
          this.childElement.id = j++;
          this.childElement.parent_id = 1;
          this.childElement.value =
            objectname + ': ' + parentobject[objectname];
          this.childElement.isSelected = false;
          childElementArr.push(this.childElement);
          this.childElement = {};
        }
        this.parentChildElement.childList = childElementArr;
        ParentChildchecklist.push(this.parentChildElement);
        childElementArr = [];
        this.parentChildElement = {};
      }
      this.data.ParentChildchecklist = ParentChildchecklist;
    });
  }

  //Checkbox Action perform
  checkboxActions() {
    this.carriers = [];
    this.data.ParentChildchecklist.forEach((childListData) => {
      childListData.childList.forEach((selectedData) => {
        if (selectedData.isSelected) {
          this.carriers.push(selectedData.value);
        }
      });
    });
  }

  // Click event on parent checkbox
  parentCheck(parentObj) {
    parentObj.childList.forEach((childListData) => {
      childListData.isSelected = parentObj.isSelected;
    });
  }

  // Click event on child checkbox
  childCheck(parentObj, childObj) {
    parentObj.isSelected = childObj.every(function (itemChild: any) {
      return itemChild.isSelected == true;
    });
    let isItemChildSelected = childObj.some(function (itemChild: any) {
      return itemChild.isSelected == true;
    });
    parentObj.indeterminate = (parentObj.isSelected && isItemChildSelected) ? false : isItemChildSelected;
  }

  // Click event on master select
  selectUnselectAll(obj) {
    obj.isAllSelected = !obj.isAllSelected;
    obj.ParentChildchecklist.forEach((childListData) => {
      childListData.indeterminate = false;
      childListData.isSelected = obj.isAllSelected;
      childListData.childList.forEach((selectedData) => {
        selectedData.isSelected = obj.isAllSelected
      });
    });
    this.checkboxActions();
  }

  // Expand/Collapse event on each parent
  expandCollapse(obj) {
    obj.isClosed = !obj.isClosed;
  }

  // Master expand/ collapse event
  expandCollapseAll(obj) {
    obj.ParentChildchecklist.forEach((parentChildChecklist) => {
      parentChildChecklist.isClosed = !obj.isAllCollapsed;
    });
    obj.isAllCollapsed = !obj.isAllCollapsed;
  }

  // Show Selected Values
  get selectedvalues() {
    this.selectedData = [];
    this.data.ParentChildchecklist.forEach((childListData) => {
      childListData.childList.forEach((selectedData) => {
        if (selectedData.isSelected) {
          this.selectedData.push(
            selectedData.value
          );
        }
      });
    });

    let uniqueAirline = function (unique) {
      return unique.filter(function (element, position, arr) {
        return arr.indexOf(element) == position;
      });
    };
    let final = uniqueAirline(this.selectedData);
    return JSON.stringify(final);
  }
}
