import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { RouterModule, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { HttpClient, HttpHeaders, HttpHandler } from '@angular/common/http';

import { TripSearchGdsComponent } from './trip-search-gds.component';

describe('TripSearchGdsComponent', () => {
  let component: TripSearchGdsComponent;
  let fixture: ComponentFixture<TripSearchGdsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TripSearchGdsComponent ],
      imports: [RouterModule, RouterTestingModule],
      providers: [HttpClient, HttpHandler],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TripSearchGdsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
