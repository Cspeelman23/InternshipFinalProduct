import { Component, OnInit } from '@angular/core';
import { TripServicesGDSService } from 'src/app/shared/services/air-search/trip-services-gds.service';
import { RefDataService } from '../../../../shared/services/ref-data/ref-data.service';
import { CatalogOffering, ProductOption, Product, Flight } from 'src/app/shared/models/gds/Models';
import { environment } from '../../../../../environments/environment';
import { FormGroup } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { TripServicesAirBookService } from 'src/app/shared/services/air-book/trip-services-air-book.service';

@Component({
  selector: 'app-trip-search-gds',
  templateUrl: './trip-search-gds.component.html',
  styleUrls: ['./trip-search-gds.component.css']
})
export class TripSearchGdsComponent implements OnInit {
  carrierIconBaseUrl: any;
  catalogOfferingList: CatalogOffering[] = [];
  expandedOffering: CatalogOffering;
  productOption: ProductOption;
  productOptionList: ProductOption[];
  offerDetails: string[] = [];
  selectedProduct: string;
  requestForm: FormGroup;
  productsList = [];
  airportData: any[];
  cityDetails: Object[];
  // flag = true;

  constructor(public gdsService: TripServicesGDSService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private refData: RefDataService, private bookService: TripServicesAirBookService) {
    this.carrierIconBaseUrl = environment.commonCollateralUrl.airIconsVTNG;
    this.cityDetails = [];
  }
  priceRequest = {
    'OfferQueryBuildFromCatalogOfferings': {
      'fareRuleType': 'TextLong',
      'reCheckInventoryInd': '',
      'lowFareFinderInd': true,
      'returnBrandedFaresInd': true,
      'BuildFromCatalogOfferingsRequest': {
        '@type': 'BuildFromCatalogOfferingsRequestAir',
        'CatalogOfferingsIdentifier': {
          'Identifier': {
            'value': ''
          }
        },
        'CatalogOfferingIdentifier': {
          'Identifier': {
            'value': ''
          }
        },
        'ProductIdentifier': [],
        'PricingModifiersAir': {}
      },
      // 'FareRuleCategory': [ 'Stopovers' ],
    }
  };

  ngOnInit() {
    this.getAirPortJsonData();
    this.gdsService.responseData.subscribe(data => {
      return this.catalogOfferingList = data;
    });
  }

  getAirPortJsonData(): void {
    this.refData
      .getAirPortJsonData()
      .subscribe(data => (this.airportData = data));
  }

  setExpandedCatalogOffering(catalogOffering: CatalogOffering): void {
    this.expandedOffering = catalogOffering;
    this.offerDetails = [];
    this.selectedProduct = '';
    this.productOptionList = this.expandedOffering.productOptions;
    this.setProductOption(0);
  }

  setProductOption(sequence: number) {
    // const num = sequence !== undefined ? sequence : 0;
    this.productOption = this.expandedOffering.productOptions[sequence];
  }

  nextProduct(productID, productOptionSequence) {
    this.offerDetails.push(productID);
    this.setProductOption(productOptionSequence);
  }

  back() {
    this.offerDetails = [];
    this.setProductOption(0);
  }

  submit(productID) {

    this.offerDetails.push(productID);
    // console.log(this.offerDetails);
    this.resetPriceRequest();
    this.requestForm = this.gdsService.catalogOfferingsQueryRequest;

    const pricingModifierAir = this.requestForm.get('CatalogOfferingsQueryRequest.CatalogOfferingsRequest.0.PricingModifiersAir');
    if (pricingModifierAir !== null && pricingModifierAir !== undefined) {
      this.priceRequest.OfferQueryBuildFromCatalogOfferings.BuildFromCatalogOfferingsRequest
        .PricingModifiersAir = pricingModifierAir.value;
    }
    this.priceRequest.OfferQueryBuildFromCatalogOfferings
      .BuildFromCatalogOfferingsRequest.CatalogOfferingsIdentifier.Identifier.value = this.expandedOffering.CatalogOfferingsIdentifier;
    this.priceRequest.OfferQueryBuildFromCatalogOfferings
      .BuildFromCatalogOfferingsRequest.CatalogOfferingIdentifier.Identifier.value = this.expandedOffering.offerID;
    this.offerDetails.forEach(e => this.priceRequest.OfferQueryBuildFromCatalogOfferings
      .BuildFromCatalogOfferingsRequest.ProductIdentifier.push(this.setIdentifier(e)));

    const jsonRequest = JSON.stringify(this.priceRequest);
    console.log(jsonRequest);
    this.spinner.show();
    this.gdsService.getPriceSearch(jsonRequest)
      .subscribe(
        (data: any) => {
          console.log(data);
          this.offerDetails = [];
          this.spinner.hide();
          this.gdsService.createPriceResponse(data);
          // this.flag = false;
          this.router.navigate(['/dashboard/trip-services-gds/trip-services-price-confirmation']);
        },
        (error: any) => {
          this.spinner.hide();
          this.offerDetails = [];
          console.log(error);
        }
      );
  }

  resetPriceRequest(): void {
    this.priceRequest.OfferQueryBuildFromCatalogOfferings.BuildFromCatalogOfferingsRequest
      .PricingModifiersAir = '';
    this.priceRequest.OfferQueryBuildFromCatalogOfferings
      .BuildFromCatalogOfferingsRequest.CatalogOfferingsIdentifier.Identifier.value = '';
    this.priceRequest.OfferQueryBuildFromCatalogOfferings
      .BuildFromCatalogOfferingsRequest.CatalogOfferingIdentifier.Identifier.value = '';
    this.priceRequest.OfferQueryBuildFromCatalogOfferings
      .BuildFromCatalogOfferingsRequest.ProductIdentifier = [];
  }

  getFlights(product: Product) {
    const flightsList: Flight[] = [];
    product.flightSegment.forEach(e => flightsList.push(e.flight));
    return flightsList;
  }

  setIdentifier(id: string) {
    return {
      'Identifier': {
        'value': id
      }
    };
  }

  // callBook() {
  //   this.bookService.workBenchPost().subscribe(
  //     (data: any) => {
  //       console.log(data);
  //       this.bookService.setReservationIdentifier(data);
  //       this.router.navigate(['/dashboard/trip-services-gds/app-trip-services-book']);
  //     },
  //     (error: any) => {
  //       console.log(error);
  //     }
  //   );
  // }
}
