import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { TripServicesAdvancedSearchService } from '../../../../shared/services/air-search/trip-services-advanced-search.service';
// import { MatDialogRef } from '@angular/material/dialog';
import { RefDataService } from '../../../../shared/services/ref-data/ref-data.service';
import {CarrierPreferenceComponent} from '../carrier-preference/carrier-preference.component';

export interface FareType {
  value: string;
  view: string;
}

export interface Carrier {
  value: string;
  view: string;
}

export interface CabinClass {
  value: string;
  view: string;
}

export interface ConnectionType {
  value: string;
  view: string;
}

@Component({
  selector: 'app-trip-services-advanced-search',
  templateUrl: './trip-services-advanced-search.component.html',
  styleUrls: ['./trip-services-advanced-search.component.css']
})
export class TripServicesAdvancedSearchComponent implements OnInit {

  constructor(private adSearchService: TripServicesAdvancedSearchService,
    private carrierGroupService: RefDataService) {}
    // public dialogRef: MatDialogRef<TripServicesAdvancedSearchComponent>) { }

  @ViewChild('carrierPreferenceComponent') carrierPreferenceComponent: CarrierPreferenceComponent;
  @Output() hideAdvanceSearch = new EventEmitter<any>();

  fareType: string;
  accountCode: string;
  carriers: any;
  connectionType: string;
  cabins: string[];

  fareTypes: FareType[] = [
    { value: 'PrivateFares', view: 'Private' },
    { value: 'PublicFares', view: 'Public' },
    { value: 'PublicAndPrivateFares', view: 'Public and Private' }
  ];

  cabinClasses: CabinClass[] = [
    { value: 'Economy', view: 'Economy' },
    { value: 'PremiumEconomy', view: 'Premium Economy' },
    { value: 'Business', view: 'Business' },
    { value: 'First', view: 'First' },
    { value: 'PremiumFirst', view: 'Premium First' }
  ];

  connectionTypes: ConnectionType[] = [
    { value: 'NonStopDirect', view: 'NonStop Direct' },
    { value: 'StopDirect', view: 'Stop Direct' },
    { value: 'SingleConnection', view: 'Single Connection' },
    { value: 'DoubleConnection', view: 'Double Connection' },
    { value: 'TripleConnection', view: 'Triple Connection' }
  ];

  ngOnInit() {
    this.fareType = this.adSearchService.fareType;
    this.accountCode = this.adSearchService.accountCode;
    // this.carriers = this.adSearchService.carrierPeference;
    this.connectionType = this.adSearchService.connectionType;
    this.cabins = this.adSearchService.cabins;
    this.carrierGroupService.currentAirline.subscribe(message => {
      this.carriers = message.map((val) => val.slice(0, 2));
    });
  }

  updateAdvancedSearch() {
    this.adSearchService.update(this.fareType, this.accountCode, this.connectionType, this.cabins, this.carriers);
    this.hideAdvanceSearch.emit();
  }

  clearAdvancedSearch() {
    this.carrierPreferenceComponent.resetCarrier();
    this.fareType = null;
    this.accountCode = null;
    this.connectionType = null;
    this.cabins = [];
    this.carriers = [];
    this.adSearchService.update(this.fareType, this.accountCode, this.connectionType, this.cabins, this.carriers);
  }

  hideAdvancedSearch() {
    this.hideAdvanceSearch.emit();
  }
}
