import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule} from '@angular/material/radio';
import { MatSelectModule } from '@angular/material';
import { MatExpansionModule } from '@angular/material/expansion';
import { NgxSpinnerModule } from 'ngx-spinner';
import { BsDatepickerModule } from 'ngx-bootstrap';

import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { RouterModule, Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { HttpClient, HttpHeaders, HttpHandler } from '@angular/common/http';

import { TripServicesGDSComponent } from './trip-services-gds.component';

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

// describe('TripServicesGDSComponent', () => {
//   let component: TripServicesGDSComponent;
//   let fixture: ComponentFixture<TripServicesGDSComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ TripServicesGDSComponent ],
//       imports: [MatAutocompleteModule,
//         MatCardModule,
//         MatFormFieldModule,
//         MatIconModule,
//         MatInputModule,
//         MatDialogModule,
//         MatRadioModule,
//         MatSelectModule,
//         MatExpansionModule,
//         NgxSpinnerModule,
//         BsDatepickerModule,
//         ReactiveFormsModule,
//         FormsModule,
//         RouterModule,
//         RouterTestingModule],
//       schemas: [CUSTOM_ELEMENTS_SCHEMA],
//       providers: [HttpClient, HttpHandler]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(TripServicesGDSComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
