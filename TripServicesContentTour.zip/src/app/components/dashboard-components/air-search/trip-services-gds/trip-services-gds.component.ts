import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormArray, FormGroup, FormControl, Validators } from '@angular/forms';
import { TripServicesGDSService } from '../../../../shared/services/air-search/trip-services-gds.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Observable } from 'rxjs/internal/Observable';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';
import { RefDataService } from 'src/app/shared/services/ref-data/ref-data.service';
import { TripServicesAdvancedSearchService } from 'src/app/shared/services/air-search/trip-services-advanced-search.service';
import { MatDialog } from '@angular/material/dialog';
import { environment } from '../../../../../environments/environment';
import {MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import * as _moment from 'moment';
import { default as _rollupMoment } from 'moment';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'YYYY-MM-DD',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

export interface Ptc {
  number: number;
  value: string;
  view: string;
}

export interface Num {
  value: number;
  view: number;
}

export interface ContentSource {
  value: string[];
  view: string;
  checked: boolean;
}

@Component({
  selector: 'app-trip-services-gds',
  templateUrl: './trip-services-gds.component.html',
  styleUrls: ['./trip-services-gds.component.css'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})

export class TripServicesGDSComponent implements OnInit {
  submitType: any;
  sccChannelID: string;
  searchForm: FormGroup;
  departureDate = new FormControl(moment().add(3, 'day'));
  returnDate = new FormControl(moment().add(6, 'day'));
  currentDate = new Date();
  minCalenderDate = new Date();
  maxCalenderDate = new Date(this.currentDate.setDate(this.currentDate.getDate() + 21));

  constructor(private formBuilder: FormBuilder,
    public gdsService: TripServicesGDSService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private refService: RefDataService,
    public advancedSearchDialog: MatDialog,
    public adSearchService: TripServicesAdvancedSearchService) {}

  Ptcs: Ptc[] = [
    { number: 1, value: 'ADT', view: 'Adult' },
    { number: 0, value: 'CHD', view: 'Child' },
    { number: 0, value: 'INF', view: 'Infant' }
  ];

  contentSourceList: ContentSource[] = [
    { value: ['GDS', 'NDC'], view: 'Integrated', checked: true },
    { value: ['GDS'], view: 'GDS', checked: false },
    { value: ['NDC'], view: 'NDC', checked: false }
  ];

  psng_num: Num[] = [
    { value: 0, view: 0 },
    { value: 1, view: 1 },
    { value: 2, view: 2 },
    { value: 3, view: 3 },
    { value: 4, view: 4 },
    { value: 5, view: 5 },
    { value: 6, view: 6 },
    { value: 7, view: 7 },
    { value: 8, view: 8 },
    { value: 9, view: 9 },
  ];
  journeyType = 'oneWay';
  filteredStates: Observable<any[]>;
  filteredStatesTo: Observable<any[]>;
  carriers: any;

  ngOnInit() {
    // Reactive form creates the Search request 'CatalogOfferingsQueryRequest' JSON object to hit the endpoint URL
    this.searchForm = this.formBuilder.group({
      CatalogOfferingsQueryRequest: this.formBuilder.group({
        CatalogOfferingsRequest: this.formBuilder.array([this.catalogOfferingsRequest()])
      })
    });
    this.filteredStates = this.searchForm
      .get('CatalogOfferingsQueryRequest.CatalogOfferingsRequest.0.SearchCriteriaFlight.0.From.value').valueChanges
      .pipe(
        startWith(''),
        map(state => state.length >= 1 ? this.refService.filterStates(state) : [])
      );
    this.filteredStatesTo = this.searchForm
      .get('CatalogOfferingsQueryRequest.CatalogOfferingsRequest.0.SearchCriteriaFlight.0.To.value').valueChanges
      .pipe(
        startWith(''),
        map(state => state.length >= 1 ? this.refService.filterStates(state) : [])
      );
  }

  returnDateChange(dateEvent: any) {
    this.returnDate = new FormControl(dateEvent.value.add(3, 'day'));
  }

  catalogOfferingsRequest(): FormGroup {
    return this.formBuilder.group({
      '@type': 'CatalogOfferingsRequestAir',
      returnBrandedFaresInd: true,
      maxNumberOfOffersToReturn: 200,
      offersPerPage: 200,
      contentSourceList: [this.contentSourceList[0].value],
      PassengerCriteria: this.passengerCriteria(),
      SearchCriteriaFlight: this.formBuilder.array([this.searchCriteriaFlight()]),
      // PricingModifiersAir: this.pricingModifiersAir(),
      // SearchModifiersAir: this.searchModifiersAir()
      // PseudoCityInfo: this.formBuilder.group({ value: ['OMW'] })
    });
  }

  passengerCriteria(): FormArray {

    const passenger = this.formBuilder.array([]);
    this.Ptcs.forEach(e =>
      passenger.push(this.formBuilder.group({
        number: e.number,
        value: e.value
      })));
    return passenger;
  }

  searchCriteriaFlight(): FormGroup {
    return this.formBuilder.group({
      From: this.formBuilder.group({ value: ['', Validators.required] }),
      To: this.formBuilder.group({ value: ['', Validators.required] }),
      departureDate: ['']
    });
  }

  addPassenger(request) {
    const passenger = <FormArray>request.get('PassengerCriteria');
    passenger.push(this.passengerCriteria());
  }

  addNewSearchCriteriaFlight(request) {
    const searchCriteria = <FormArray>request.get('SearchCriteriaFlight');
    searchCriteria.push(this.searchCriteriaFlight());
  }

  deleteSearchCriteriaFlight(request, k: number) {
    const searchCriteria = <FormArray>request.get('SearchCriteriaFlight');
    if (searchCriteria.length > 1) {
      searchCriteria.removeAt(k);
    } else {
      console.log('Can not delete');
    }
  }

  showAdvancedSearch() {
    document.getElementById('advancedSearchForm').style.display = 'block';
  }

  hideAdvancedSearch() {
    document.getElementById('advancedSearchForm').style.display = 'none';
  }

  onSubmit() {
    if (this.journeyType === 'oneWay' || this.journeyType === 'roundTrip' && this.departureDate !== undefined
    && this.departureDate !== null) {
      this.searchForm.value.CatalogOfferingsQueryRequest.CatalogOfferingsRequest[0]
        .SearchCriteriaFlight[0].departureDate = this.departureDate.value.format().slice(0, 10);
      const searchCriteriaFlight = this.searchForm
        .get('CatalogOfferingsQueryRequest.CatalogOfferingsRequest.0.SearchCriteriaFlight') as FormArray;
      if (this.returnDate !== undefined && this.returnDate !== null  && this.journeyType === 'roundTrip') {
        searchCriteriaFlight.removeAt(1);
        searchCriteriaFlight.push(this.formBuilder.group({
          From: this.formBuilder.group({ value: searchCriteriaFlight.get('0.To.value').value }),
          To: this.formBuilder.group({ value: searchCriteriaFlight.get('0.From.value').value }),
          departureDate: [this.returnDate.value.format().slice(0, 10)]
        }));
      } else {
        searchCriteriaFlight.removeAt(1);
      }
    }

    if (this.journeyType === 'multiCity') {
      const searchCriteriaFlight = this.searchForm
        .get('CatalogOfferingsQueryRequest.CatalogOfferingsRequest.0.SearchCriteriaFlight') as FormArray;
      const multiCityDate = [];
      searchCriteriaFlight.controls.forEach(e => multiCityDate.push(e.get('departureDate').value));
      for (let i = 0; i < searchCriteriaFlight.length; i++) {
        this.searchForm.value.CatalogOfferingsQueryRequest
          .CatalogOfferingsRequest[0].SearchCriteriaFlight[i].departureDate = multiCityDate[i].format().slice(0, 10);
      }
    }

    // Adding search and pricing modifiers to the search request
    const modifiers = this.searchForm.get('CatalogOfferingsQueryRequest.CatalogOfferingsRequest.0') as FormGroup;

    modifiers.removeControl('SearchModifiersAir');
    modifiers.removeControl('PricingModifiersAir');

    if (this.adSearchService.searchModifiersAir) {
      modifiers.addControl('SearchModifiersAir', this.adSearchService.getSearchModifiersAir());
    } else {
      modifiers.removeControl('SearchModifiersAir');
    }

    if (this.adSearchService.pricingModifiersAir) {
      modifiers.addControl('PricingModifiersAir', this.adSearchService.getPricingModifiersAir());
    } else {
      modifiers.removeControl('PricingModifiersAir');
    }

    // Removing Passenger Criteria in which count is 0
    const requestPassengerCriteria =
      this.searchForm.get('CatalogOfferingsQueryRequest.CatalogOfferingsRequest.0.PassengerCriteria') as FormArray;
    const psngCrt = this.formBuilder.array([]);

    requestPassengerCriteria.controls.forEach(e => {
      if (e.get('number').value > 0) {
        psngCrt.push(e);
      }
      // console.log(JSON.stringify(psngCrt.value));
    });
    this.searchForm.value.CatalogOfferingsQueryRequest.CatalogOfferingsRequest[0].PassengerCriteria = psngCrt.value;

    // console.log(JSON.stringify(this.searchForm.value));
    this.spinner.show();
    this.gdsService.postSearch(this.searchForm, this.sccChannelID) // Calling GDS service
      .subscribe(
        (data: any) => {
          this.spinner.hide();
          console.log(data);
          if (data['CatalogOfferingsResponse']['CatalogOfferings'] !== undefined) {
            this.gdsService.setResponseData(data);
            this.router.navigate(['/dashboard/trip-services-gds/trip-search-gds']);
          } else {
            alert(data['CatalogOfferingsResponse']['Result']['Error']['0']['Message']);
          }
        },
        (error: any) => {
          this.spinner.hide();
          console.log(error);
        }
      );
  }

  get CatalogOfferingsRequest() {
    return this.searchForm.get('CatalogOfferingsQueryRequest.CatalogOfferingsRequest') as FormArray;
  }

  getPassengerCriteria(request) {
    return request.controls.PassengerCriteria.controls;
  }

  getSearchCriteriaFlight(request) {
    return request.controls.SearchCriteriaFlight.controls;
  }

  getCarrierPreference(request) {
    return request.controls.SearchModifiersAir.controls.CarrierPreference.controls;
  }

  getCabinPreference(request) {
    return request.controls.SearchModifiersAir.controls.CabinPreference.controls;
  }

  getPassengers(request) {
    return request.controls.PassengerCriteria.value;
  }
}
