import { Component, OnInit } from '@angular/core';
import { TripServicesGDSService } from 'src/app/shared/services/air-search/trip-services-gds.service';
import { OfferResponse } from 'src/app/shared/models/gds/Price';
import { Product, FlightSegment, PriceDetail } from 'src/app/shared/models/gds/Models';
import { environment } from 'src/environments/environment';
import { Airport } from 'src/app/shared/models/gds/Airport';
import { RefDataService } from 'src/app/shared/services/ref-data/ref-data.service';
import { Router } from '@angular/router';
import { TripServicesAirBookService } from 'src/app/shared/services/air-book/trip-services-air-book.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-trip-services-price-confirmation',
  templateUrl: './trip-services-price-confirmation.component.html',
  styleUrls: ['./trip-services-price-confirmation.component.css']
})
export class TripServicesPriceConfirmationComponent implements OnInit {

  constructor(public gdsService: TripServicesGDSService,
    private refService: RefDataService, private router: Router, private spinner: NgxSpinnerService,
    private bookService: TripServicesAirBookService) {
    this.carrierIconBaseUrl = environment.commonCollateralUrl.airIconsVTNG;
  }

  carrierIconBaseUrl: string;
  priceConfirmation: OfferResponse;
  step = 0;
  airport: Airport[] = [];

  ngOnInit() {
    this.priceConfirmation = this.gdsService.priceConfirmationResponse;
    // if (this.priceConfirmation === null || this.priceConfirmation === undefined) {
    //   this.requestSearch();
    // }
  }

  getLocation(product: Product) {
    let location = [];
    let city = [];
    city.push(this.refService.getAirPortDetails(product.flightSegment[0].flight.departure.location));
    city.push(this.refService.getAirPortDetails(product.flightSegment[product.flightSegment.length - 1].flight.arrival.location));
    const cityName = `${city[0].City} - ${city[1].City}`;
    const totalDuration = product.totalDuration;
    location.push({ cityName, totalDuration });
    return location;
  }

  getProduct(priceResponse: OfferResponse): Product[] {
    return priceResponse.offer.Product;
  }

  getFlightSegment(product: Product) {
    let flightSegment = [];
    product.passengerFlight.forEach(passengerFlightVal => {
      passengerFlightVal.FlightProduct.forEach(FlightProduct => {
        FlightProduct.segmentSequence.forEach(segmentSequence => {
          product.flightSegment.forEach((flightSegmentVal) => {
            const { id, sequence, connectionDuration, flight } = flightSegmentVal;
            if (segmentSequence === flightSegmentVal.sequence) {
              flightSegment.push({ id, sequence, connectionDuration, flight, FlightProduct });
            }
          });
        });
      });
    });
    return flightSegment;
  }

  getPriceDetails(priceResponse: OfferResponse) {
    return [priceResponse.offer.Price];
  }

  getAirportDetails(iataCode) {
    this.airport = [];
    this.airport.push(this.refService.getAirPortDetails(iataCode));
    return this.airport;
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }

  callBook() {
    this.spinner.show();
    this.bookService.workBenchPost().subscribe(
      (data: any) => {
        console.log(data);
        this.bookService.setReservationIdentifier(data);
        this.spinner.hide();
        this.router.navigate(['/dashboard/trip-services-gds/app-book-traveler']);
      },
      (error: any) => {
        this.spinner.hide();
        console.log(error);
      }
    );
  }

  requestSearch() {
    this.spinner.show();
    this.gdsService.postSearch(this.gdsService.catalogOfferingsQueryRequest, this.gdsService.sccChannelID)
      .subscribe(
        (data: any) => {
          this.spinner.hide();
          console.log(data);
          if (data['CatalogOfferingsResponse']['CatalogOfferings'] !== undefined) {
            this.gdsService.setResponseData(data);
            this.router.navigate(['/dashboard/trip-services-gds/trip-search-gds']);
          } else {
            alert(data['CatalogOfferingsResponse']['Result']['Error']['0']['Message']);
          }
        },
        (error: any) => {
          this.spinner.hide();
          console.log(error);
        }
      );
  }
}
