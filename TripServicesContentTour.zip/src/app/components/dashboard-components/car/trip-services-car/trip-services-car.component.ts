import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trip-services-car',
  templateUrl: './trip-services-car.component.html',
  styleUrls: ['./trip-services-car.component.css']
})
export class TripServicesCarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
