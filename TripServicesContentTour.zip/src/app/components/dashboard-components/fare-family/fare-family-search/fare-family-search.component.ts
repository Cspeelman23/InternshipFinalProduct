import { Component, OnInit } from '@angular/core';
import { UpsellGroup, BrandAttribute } from 'src/app/shared/models/farefamily/FFS_Refine';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { FareFamilyShopService } from '../../../../shared/services/fare-family/fare-family-shop.service';
import { environment } from '../../../../../environments/environment';
import { RefDataService } from '../../../../shared/services/ref-data/ref-data.service';

@Component({
  selector: 'app-fare-family-search',
  templateUrl: './fare-family-search.component.html',
  styleUrls: ['./fare-family-search.component.css']
})
export class FareFamilySearchComponent implements OnInit {
  displayedColumns: string[] = ['classification', 'inclusion'];
  carrierIconBaseUrl: any;
  fareFamilyOfferingList: UpsellGroup[] = [];
  disabled = true;

  constructor(private spinner: NgxSpinnerService,
    public ffsService: FareFamilyShopService,
    private router: Router,
    public refData: RefDataService) {
      this.carrierIconBaseUrl = environment.commonCollateralUrl.airIconsVTNG;
    }

  ngOnInit() {
    this.ffsService.responseData.subscribe(data => {
      return this.fareFamilyOfferingList = data;
    });
  }

}

