import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Location } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import {RouterTestingModule} from '@angular/router/testing';


import { TripSearchHotelResultsComponent } from './trip-search-hotel-results.component';

describe('TripSearchHotelResultsComponent', () => {
  let component: TripSearchHotelResultsComponent;
  let fixture: ComponentFixture<TripSearchHotelResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TripSearchHotelResultsComponent ],
      imports: [RouterModule, RouterTestingModule],
      providers: [Location]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TripSearchHotelResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
