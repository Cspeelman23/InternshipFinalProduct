// import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
// import { Location } from '@angular/common';
// import { environment } from '../../../environments/environment';
// import { HotelBindable } from '../../shared/models/hccd/HotelResults';
// import { MatPaginator, MatSort } from '@angular/material';
// import {merge, Observable, of as observableOf} from 'rxjs';
// import {catchError, map, startWith, switchMap} from 'rxjs/operators';


// @Component({
//   selector: 'app-trip-search-hotel-results',
//   templateUrl: './trip-search-hotel-results.component.html',
//   styleUrls: ['./trip-search-hotel-results.component.css']
// })


// export class TripSearchHotelResultsComponent implements AfterViewInit  {

//   PropertyInfo: object[];
//   data: HotelBindable[] = [];

//   displayedColumns: string[] = ['Hotel', 'Property Name', 'Rate'];

//   HotelBaseImageUrl: any;

//   constructor(private location: Location) {
//     this.HotelBaseImageUrl = environment.commonCollateralUrl.hotelIcons;
//   }

//   ngAfterViewInit() {
//     const results = JSON.parse(localStorage.getItem('hotelResults'));
//     if (results !== null ) {
//       this.PropertyInfo = results;
//     }
//     // If the user changes the sort order, reset back to the first page.
//     this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

//     merge(this.sort.sortChange, this.paginator.page)
//       .pipe(
//         startWith({}),
//         switchMap(() => {
//           this.isLoadingResults = true;
//           return this.exampleDatabase!.getRepoIssues(
//             this.sort.active, this.sort.direction, this.paginator.pageIndex);
//         }),
//         map(data => {
//           // Flip flag to show that loading has finished.
//           this.isLoadingResults = false;
//           this.isRateLimitReached = false;
//           this.resultsLength = data.total_count;

//           return data.items;
//         }),
//         catchError(() => {
//           this.isLoadingResults = false;
//           // Catch if the GitHub API has reached its rate limit. Return empty data.
//           this.isRateLimitReached = true;
//           return observableOf([]);
//         })
//       ).subscribe(data => this.data = data);
//   }
//   }

//   back() {
//     // this.dashboard.editor="gdsSearch";
//     this.location.back();
//   }
// }

import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-trip-search-hotel-results',
  templateUrl: './trip-search-hotel-results.component.html',
  styleUrls: ['./trip-search-hotel-results.component.css']
})

export class TripSearchHotelResultsComponent implements OnInit {

  PropertyInfo: object[];

  HotelBaseImageUrl: any;

  constructor(private location: Location) {
    this.HotelBaseImageUrl = environment.commonCollateralUrl.hotelIcons;
  }

  ngOnInit() {
    const results = JSON.parse(localStorage.getItem('hotelResults'));
    if (results !== null ) {
      this.PropertyInfo = results;
    }
  }

  back() {
    // this.dashboard.editor="gdsSearch";
    this.location.back();
  }
}
