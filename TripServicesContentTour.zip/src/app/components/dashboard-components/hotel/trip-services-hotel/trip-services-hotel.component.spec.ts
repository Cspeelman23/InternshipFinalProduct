import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgxSpinnerModule } from 'ngx-spinner';
import {NgbDateStruct, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { TripServicesHotelComponent } from './trip-services-hotel.component';

// describe('TripServicesHotelComponent', () => {
//   let component: TripServicesHotelComponent;
//   let fixture: ComponentFixture<TripServicesHotelComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ TripServicesHotelComponent ],
//       imports: [NgxSpinnerModule, NgbCalendar]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(TripServicesHotelComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
