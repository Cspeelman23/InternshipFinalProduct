import { Component, OnInit, NgZone } from '@angular/core';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {


  constructor(public ngZone: NgZone ) {
  }

  navLinks = [
    {'path': '/dashboard/heart-beat',           'label': 'Heart-Beat'},
    {'path': '/dashboard/trip-services-gds',    'label': 'AirSearch'},
    {'path': '/dashboard/trip-services-ffs',    'label': 'FFS'},
    {'path': '/dashboard/trip-services-hotel',  'label': 'Hotel'},
    {'path': '/dashboard/trip-services-car',    'label': 'Car'},
    {'path': '/dashboard/about',                'label': 'About'}
  ];

  ngOnInit() { }

}
