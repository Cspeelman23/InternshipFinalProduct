import { Component, OnInit } from '@angular/core';
import { FormControl, FormBuilder} from '@angular/forms';
import { AuthService } from '../../../shared/services/auth/auth.service';

import { EmailValidation } from '../../../shared/utilities/validator';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})

export class ForgotPasswordComponent implements OnInit {
  form: any;

  constructor(
    public authService: AuthService,
    private formBuilder: FormBuilder
  ) {
    this.form = this.formBuilder.group ( {
      email: new FormControl('', EmailValidation),
    });
   }

  ngOnInit() {
  }

}
