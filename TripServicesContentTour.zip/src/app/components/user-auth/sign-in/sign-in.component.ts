import { Component, OnInit } from '@angular/core';
import { FormControl, FormBuilder} from '@angular/forms';
import { AuthService } from '../../../shared/services/auth/auth.service';

import { EmailValidation, PasswordValidation } from '../../../shared/utilities/validator';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
  form: any;

  constructor( public authService: AuthService, private formBuilder: FormBuilder) {
    this.form = this.formBuilder.group ( {
      email: new FormControl('', EmailValidation),
      password: new FormControl('', PasswordValidation),
    });
   }

  ngOnInit() {
  }

}
