export class Airport {
    constructor(public AirportID: number,
      public Name: string, 
      public City: string,
       public Country: string,
       public IATA: string,
       public ICAO: string,
       public Latitude: number,
       public Longitude: number,
       public Altitude: number,
       public Timezone: string,
       public DST: string,
       public Tz: string,
       public Type: string,
       public Source: string) { }
  }