export class OfferQueryBuildFromProducts {
    returnBrandedFaresInd: boolean;
    BuildFromProductsRequest: BuildFromProductsRequestAir;
}

export class BuildFromProductsRequestAir{
    PricingModifiersAir: PricingModifiersAirDetail;
}

export class PricingModifiersAirDetail {
    currencyCode: string;
    FareSelection: FareSelectionDetail;
    Brand: BrandSummary;
}

export class FareSelectionDetail {
    fareType: string;
}

export class BrandSummary {
    name: string;
    tier: number;
}

export class SpecificFlightCriteria {
    flightNumber: string;
    carrier: string;
    departureDate: string;
    departureTime: string;
    arrivalDate: string;
    arrivalTime: string;
    from: string;
    to: string;
    classOfService: string;
    cabin: string;
    segmentSequence: number;
}
