export class AllCarriers {
  constructor(public CarrierCode: string,
    public CarrierName: string) { }
}