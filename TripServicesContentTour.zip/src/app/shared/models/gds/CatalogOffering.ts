
// interface CatalogOffering extends CatalogOfferingID {
//     termsAndConditions: TermsAndConditionsID;
//     productOptions: ProductOptionsID[];
//     price: Price;
// }

// interface Identifier extends URType {
//     authority: string;
//     value: string;
// }

// interface CatalogOfferingID extends URType {
//     identifier: Identifier;
//     catalogOfferingRef: CatalogOfferingID;
//     id: string;
// }

// interface TermsAndConditionsID extends URType {
//     identifier: Identifier;
//     id: string;
//     termsAndConditionsRef: TermsAndConditionsID;
// }

// interface ProductOptionsID extends URType {
//     identifier: Identifier;
//     productOptionsRef: ProductOptionsID;
//     id: string;
// }

// interface Price extends URType {
//     totalFees: number;
//     totalPrice: number;
//     totalTaxes: number;
//     id: string;
//     currencyCode: string;
//     base: number;
//     vendorCurrencyTotal: VendorCurrencyAmount;
//     exchangeInd: boolean;
// }

// // tslint:disable-next-line:no-empty-interface
// interface URType {
// }

// interface VendorCurrencyAmount extends URType {
//     amount: number;
//     currencyCode: string;
// }
