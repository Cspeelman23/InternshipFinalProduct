
// interface CatalogOfferings extends CatalogOfferingsID {
//     defaultCurrency: Currency;
//     catalogOffering: CatalogOfferingID[];
// }

// interface Identifier extends URType {
//     authority: string;
//     value: string;
// }

// interface Currency extends URType {
//     code: string;
//     value: number;
// }

// interface CatalogOfferingID extends URType {
//     identifier: Identifier;
//     catalogOfferingRef: CatalogOfferingID;
//     id: string;
// }

// interface CatalogOfferingsID extends URType {
//     identifier: Identifier;
//     id: string;
// }

// // tslint:disable-next-line:no-empty-interface
// interface URType {
// }
