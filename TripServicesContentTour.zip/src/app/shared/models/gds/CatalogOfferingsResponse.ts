
// interface CatalogOfferingsResponse extends URType {
//     identifier: Identifier;
//     referenceList: ReferenceList[];
//     result: Result;
//     nextSteps: NextSteps;
//     catalogOfferingsID: CatalogOfferingsID;
//     transactionId: string;
//     traceId: string;
// }

// interface Identifier extends URType {
//     authority: string;
//     value: string;
// }

// interface ReferenceList extends URType {
//     id: string;
// }

// interface Result extends URType {
//     error: Error[];
//     status: ResultStatusEnum;
//     warning: Warning[];
// }

// interface NextSteps extends URType {
//     baseURI: URL;
//     nextStep: NextStep[];
//     id: string;
// }

// interface CatalogOfferingsID extends URType {
//     identifier: Identifier;
//     id: string;
// }

// // tslint:disable-next-line:no-empty-interface
// interface URType {
// }

// // interface Error extends URType {
// //     message: string;
// //     nameValuePair: NameValuePair[];
// //     statusCode: number;
// // }

// interface Warning extends URType {
//     message: string;
//     nameValuePair: NameValuePair[];
//     statusCode: number;
// }

// // tslint:disable-next-line:no-empty-interface
// interface URL extends Serializable {
// }

// interface NextStep extends URType {
//     method: NextStepMethodEnum;
//     id: string;
//     action: string;
//     value: URL;
//     description: string;
// }

// interface NameValuePair extends URType {
//     name: string;
//     id: string;
//     value: string;
// }

// // tslint:disable-next-line:no-empty-interface
// interface Serializable {
// }

// type ResultStatusEnum = 'UNKNOWN' | 'NOT_PROCESSED' | 'COMPLETE' | 'INCOMPLETE';

// type NextStepMethodEnum = 'GET' | 'POST' | 'PUT' | 'DELETE';
