import { Product, Brand, PriceDetail } from './Models';

export class OfferResponse {
    offer: Offer;
    Result: string;
    Identifier: string;
    ReferenceList: ReferenceListBrand[];
}

export class Offer {
    id: string;
    Product: Product[];
    Price: PriceDetail;
    TermsAndConditionsFull: TermsAndConditionsFullAir[];
}

export class ReferenceListBrand {
    brand: Brand[];
}

export class TermsAndConditionsFullAir {
    validatingCarrier: string;
    ExpiryDate: string;
    BaggageAllowance: BaggageAllowanceDetail[];
    FareRuleInfo: FareRuleInfoText[];
}

export class BaggageAllowanceDetail {
    url: string;
    passengerTypeCodes: string[];
    baggageType: string;
    ProductRef: string[];
    BaggageItem: BaggageItemDetail[];
    SegmentSequenceList: number[];
    Text: string;
}

export class BaggageItemDetail {
    quantity: number;
    BaggageFee: BaggageFeeDetail;
    Text: string;
}

export class BaggageFeeDetail {
    code: string;
    approximateInd: boolean;
    value: string;
}

export class FareRuleInfoText {
    flightRefs: string[];
    ruleNumber: string;
    tariffNumber: string;
    FareRuleText: FareRuleText[];
}

export class FareRuleText {
    name: string;
    value: string;
}

export class Identifier {
    value: string;
}

export class OfferQueryBuildFromCatalogOfferings {
    fareRuleType: string;
    returnBrandedFaresInd: boolean;
    BuildFromCatalogOfferingsRequest: string;
    FareRuleCategory: [];
    CabinPreference: string;
}

class BuildFromCatalogOfferingsRequestAir {
    CatalogOfferingsIdentifier: Identifier;
    CatalogOfferingIdentifier: Identifier;
    ProductIdentifier: Identifier[];
    PricingModifiersAir: string;
}