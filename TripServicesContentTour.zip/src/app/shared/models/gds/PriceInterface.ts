// import { Product, Brand, PriceDetail } from './Models';

export interface OfferResponse {
    offer: Offer;
    Result: string;
    Identifier: string;
    ReferenceList: string[];
}

export interface Offer {
    id: string;
    Product: Product[];
    Price: PriceDetail;
    TermsAndConditionsFull: TermsAndConditionsFullAir[];
}

export interface Product {
    productID: string;
    totalDuration: string;
    flightSegment: FlightSegment[];
    stops: number;
    passengerFlight: PassengerFlight[];
    carrier: string;
    intermidiate: string[];
    price: number;
}

export interface FlightSegment {
    id: string;
    sequence: number;
    connectionDuration: string;
    boundFlightsInd: boolean;
    flightRef: string;
    flight: Flight;
}
export interface PassengerFlight {
    passengerQuantity: number;
    passengerTypeCode: string;
    FlightProduct: FlightProduct[];
}
export interface FlightProduct {
    segmentSequence: number[];
    classOfService: string;
    cabin: string;
    fareBasisCode: string;
    brand: Brand;
}

export interface Flight {
    carrier: string;
    distance: number;
    duration: string;
    equipment: string;
    id: string;
    number: string;
    operatingCarrier: string;
    operatingCarrierName: string;
    arrival: Arrival;
    departure: Departure;
}

export interface Arrival {
    date: string;
    location: string;
    terminal: number;
    time: string;
}

export interface Departure {
    date: string;
    location: string;
    terminal: number;
    time: string;
}

export interface Brand {
    brandAttribute: BrandAttribute[];
    id: string;
    name: string;
    tier: number;
    identifier: Identifier;
}

export interface Identifier {
    authority: string;
    value: string;
}

export interface BrandAttribute {
    classification: string;
    inclusion: string;
}

export interface PriceDetail {
    currencyCode: string;
    id: string;
    Base: string;
    TotalTaxes: string;
    TotalFees: string;
    TotalPrice: string;
    PriceBreakdown: PriceBreakdownAir[];
}

export interface PriceBreakdownAir {
    quantity: number;
    requestedPassengerType: string;
    amount: Amount;
}

export interface Amount {
    Base: string;
    Taxes: Taxes;
    Fees: Fees;
    Total: string;
}

export interface Fees {
    TotalFees: string;
}

export interface Taxes {
    TotalTaxes: string;
    Tax: Tax[];
}

export interface Tax {
    taxCode: string;
    value: string;
}

interface ReferenceListBrand {
    brand: Brand[];
}

export interface TermsAndConditionsFullAir {
    validatingCarrier: string;
    ExpiryDate: string;
    BaggageAllowance: BaggageAllowanceDetail[];
    FareRuleInfo: FareRuleInfoText[];
}

export interface BaggageAllowanceDetail {
    url: string;
    passengerTypeCodes: string[];
    baggageType: string;
    ProductRef: string[];
    BaggageItem: BaggageItemDetail[];
    SegmentSequenceList: number[];
    Text: string;
}

export interface BaggageItemDetail {
    quantity: number;
    BaggageFee: BaggageFeeDetail;
    Text: string;
}

export interface BaggageFeeDetail {
    code: string;
    approximateInd: boolean;
    value: string;
}

export interface FareRuleInfoText {
    flightRefs: string[];
    ruleNumber: string;
    tariffNumber: string;
    FareRuleText: FareRuleText[];
}

export interface FareRuleText {
    name: string;
    value: string;
}

export interface Identifier {
    value: string;
}

export interface OfferQueryBuildFromCatalogOfferings {
    fareRuleType: string;
    returnBrandedFaresInd: boolean;
    BuildFromCatalogOfferingsRequest: string;
    FareRuleCategory: [];
    CabinPreference: string;
}

interface BuildFromCatalogOfferingsRequestAir {
    CatalogOfferingsIdentifier: Identifier;
    CatalogOfferingIdentifier: Identifier;
    ProductIdentifier: Identifier[];
    PricingModifiersAir: string;
}