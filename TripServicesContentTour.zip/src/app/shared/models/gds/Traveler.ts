export interface PersonNameDetail {
    Prefix: string;
    Given: string;
    Middle: string;
    Surname: string;
    Suffix: string;
}

export interface Telephone {
    _type: string;
    countryAccessCode: string;
    areaCityCode: string;
    phoneNumber: string;
    extension: string;
    id: string;
    cityCode: string;
    role: string;
}

export interface Email {
    value: string;
    remark: string;
}

export interface CustomerLoyalty {
    supplier: string;
    status: string;
    value: string;
}

export interface Traveler {
    passengerTypeCode: string;
    PersonNameDetail: PersonNameDetail;
    Telephone: Telephone[];
    Email: Email[];
    CustomerLoyalty: CustomerLoyalty[];
}


