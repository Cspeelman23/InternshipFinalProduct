export class Equipment {
    constructor(public IATA: string,
      public ICAO: string, 
      public Wake: string) { }
}