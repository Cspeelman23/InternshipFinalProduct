    export interface PropertyKey {
        chainCode: string;
        propertyCode: string;
    }

    export interface Rating {
        provider: string;
        value: string;
    }

    export interface GeoLocation {
        latitude: string;
        longitude: string;
    }

    export interface PropertySummary {
        name: string;
        id: string;
        PropertyKey: PropertyKey;
        Rating: Rating[];
        GeoLocation: GeoLocation;
    }

    export interface RackRate {
        code: string;
        value: number;
    }

    export interface RelativePosition {
        distance: number;
    }

    // tslint:disable-next-line:no-empty-interface
    export interface PropertyInfo {
        '@type': string;
        status: string;
        id: string;
        PropertySummary: PropertySummary;
        RackRate: RackRate;
        RelativePosition: RelativePosition;
    }

    export interface NextStep {
        id: string;
    }

    export interface NextSteps {
        NextStep: NextStep[];
    }

    export interface Properties {
        PropertyInfo: PropertyInfo[];
        NextSteps: NextSteps;
    }

    export interface RootObject {
        Properties: Properties;
    }

    export class HotelBindable {
        PropertyCode: string;
        PropertyName: string;
        RackRate: string;
        PropertyID: string;
    }


