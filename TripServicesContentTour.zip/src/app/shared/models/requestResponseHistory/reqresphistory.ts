export class HistoryItem {
    endPoint: string;
    headers: string;
    request: string;
    response: string;
    source: string;
    timestamp: Date;
    verb: string;
}
