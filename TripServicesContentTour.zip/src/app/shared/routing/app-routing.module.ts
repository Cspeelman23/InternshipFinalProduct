import { NgModule } from '@angular/core';
import { Routes, RouterModule, Router, NavigationEnd } from '@angular/router';

// Required components for which route services to be activated
import { SignInComponent } from '../../components/user-auth/sign-in/sign-in.component';
import { SignUpComponent } from '../../components/user-auth/sign-up/sign-up.component';
import { DashboardComponent } from '../../components/dashboard/dashboard.component';
import { ForgotPasswordComponent } from '../../components/user-auth/forgot-password/forgot-password.component';
import { VerifyEmailComponent } from '../../components/user-auth/verify-email/verify-email.component';
import { TripServicesAirComponent } from '../../components/dashboard-components/air-sandbox/trip-services-air/trip-services-air.component';
// tslint:disable-next-line: max-line-length
import { TripServicesAirResultsComponent } from '../../components/dashboard-components/air-sandbox/trip-services-air-results/trip-services-air-results.component';
import { TripServicesGDSComponent } from '../../components/dashboard-components/air-search/trip-services-gds/trip-services-gds.component';
import { TripSearchGdsComponent } from '../../components/dashboard-components/air-search/trip-search-gds/trip-search-gds.component';
import { TripServicesHotelComponent } from '../../components/dashboard-components/hotel/trip-services-hotel/trip-services-hotel.component';
// tslint:disable-next-line: max-line-length
import { TripSearchHotelResultsComponent } from '../../components/dashboard-components/hotel/trip-search-hotel-results/trip-search-hotel-results.component';
import { HeartBeatComponent } from '../../components/dashboard-components/heart-beat/heart-beat.component';
// import { CarrierPreferenceComponent } from '../../components/carrier-preference/carrier-preference.component';
// import { ChipsAutocompleteComponent } from '../../components/chips-autocomplete/chips-autocomplete.component';
// tslint:disable-next-line: max-line-length
import { TripServicesPriceConfirmationComponent } from '../../components/dashboard-components/air-search/trip-services-price-confirmation/trip-services-price-confirmation.component';
import { TripServicesCarComponent } from '../../components/dashboard-components/car/trip-services-car/trip-services-car.component';
// Import canActivate guard services
import { AuthGuard } from '../../shared/guard/auth.guard';
import { SecureInnerPagesGuard } from '../guard/secure-inner-pages.guard.ts.guard';
import { FareFamilyShopComponent } from '../../components/dashboard-components/fare-family/fare-family-shop/fare-family-shop.component';
// tslint:disable-next-line: max-line-length
import { FareFamilySearchComponent } from '../../components/dashboard-components/fare-family/fare-family-search/fare-family-search.component';
// tslint:disable-next-line: max-line-length
import { TripServicesBookComponent } from 'src/app/components/dashboard-components/air-book/trip-services-book/trip-services-book.component';
import { AboutComponent } from 'src/app/components/dashboard-components/about/about.component';
import { BookTravelerComponent } from 'src/app/components/dashboard-components/air-book/book-traveler/book-traveler.component';

// Include route guard in routes array
const routes: Routes = [
  { path: '', redirectTo: '/sign-in', pathMatch: 'full' },
  { path: 'sign-in', component: SignInComponent, canActivate: [SecureInnerPagesGuard] },
  { path: 'register-user', component: SignUpComponent, canActivate: [SecureInnerPagesGuard] },
  { path: 'forgot-password', component: ForgotPasswordComponent, canActivate: [SecureInnerPagesGuard] },
  { path: 'verify-email-address', component: VerifyEmailComponent, canActivate: [SecureInnerPagesGuard] },
  { path: 'forgot-password', component: ForgotPasswordComponent, canActivate: [SecureInnerPagesGuard] },
  { path: 'verify-email-address', component: VerifyEmailComponent, canActivate: [SecureInnerPagesGuard] },
  { path: 'trip-services-hotel-results', component: TripSearchHotelResultsComponent, canActivate: [AuthGuard] },
  {
    path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'heart-beat', pathMatch: 'full' },
      {
        path: 'trip-services-gds', component: TripServicesGDSComponent, canActivate: [AuthGuard],
        children: [
          { path: 'trip-search-gds', component: TripSearchGdsComponent, canActivate: [AuthGuard] },
          { path: 'trip-services-price-confirmation', component: TripServicesPriceConfirmationComponent, canActivate: [AuthGuard] },
          { path: 'app-book-traveler', component: BookTravelerComponent, canActivate: [AuthGuard] },
          { path: 'app-trip-services-book', component: TripServicesBookComponent, canActivate: [AuthGuard] }
        ]
      },
      {
        path: 'trip-services-ffs', component: FareFamilyShopComponent, canActivate: [AuthGuard],
        children: [
          { path: 'fare-family-search', component: FareFamilySearchComponent, canActivate: [AuthGuard] },
          { path: 'trip-services-price-confirmation', component: TripServicesPriceConfirmationComponent, canActivate: [AuthGuard] }
        ]
      },
      // { path: 'trip-search-gds', component: TripSearchGdsComponent, canActivate: [AuthGuard] },
      { path: 'trip-services-hotel', component: TripServicesHotelComponent, canActivate: [AuthGuard] },
      // { path: 'fare-family-shop', component: FareFamilyShopComponent, canActivate: [AuthGuard] },
      // { path: 'fare-family-search', component: FareFamilySearchComponent, canActivate: [AuthGuard] },
      { path: 'heart-beat', component: HeartBeatComponent, canActivate: [AuthGuard]},
      { path: 'about', component: AboutComponent, canActivate: [AuthGuard]},
      // { path: 'trip-services-price-confirmation', component: TripServicesPriceConfirmationComponent, canActivate: [AuthGuard] },
      { path: 'trip-services-car', component: TripServicesCarComponent, canActivate: [AuthGuard] }
    ] },
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule {
  constructor(private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        (<any>window).ga('set', 'page', event.urlAfterRedirects);
        (<any>window).ga('send', 'pageview');
      }
    });
  }
}
