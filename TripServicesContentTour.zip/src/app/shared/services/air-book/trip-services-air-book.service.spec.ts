import { TestBed } from '@angular/core/testing';

import { TripServicesAirBookService } from './trip-services-air-book.service';

describe('TripServicesAirBookService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TripServicesAirBookService = TestBed.get(TripServicesAirBookService);
    expect(service).toBeTruthy();
  });
});
