import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { TripServicesGDSService } from '../air-search/trip-services-gds.service';
import { SpecificFlightCriteria } from '../../models/gds/Book';

@Injectable({
  providedIn: 'root'
})
export class TripServicesAirBookService {

  constructor(private httpClient: HttpClient,
    private gdsService: TripServicesGDSService) {
  }

  httpHeaders = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'E2ETrackingID': 'demo-app-123',
      'XAUTH_TRAVELPORT_ACCESSGROUP': '2A9A9814-3B18-4E65-9CDA-4F2CF7FFDBA4',
      'Authorization': this.getAuthorization(),
    }),
  };

  bookHttpHeaders = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'E2ETrackingID': 'demo-app-123',
      'XAUTH_TRAVELPORT_ACCESSGROUP': '2A9A9814-3B18-4E65-9CDA-4F2CF7FFDBA4',
      'Authorization': this.getAuthorization(),
    }),
  };
  reservationIdentifierValue: string;

  workBenchRequest = {
    'ReservationID': {}
  };

  addOfferRequest = {
    'OfferQueryBuildFromProducts': {
      'lowFareFinderInd': true,
      'returnBrandedFaresInd': true,
      'BuildFromProductsRequest': {
        '@type': 'BuildFromProductsRequestAir',
        'PricingModifiersAir': {
          '@type': 'PricingModifiersAirDetail',
          'currencyCode': 'EUR',
          // 'FareSelection': {
          //   '@type': 'FareSelectionDetail',
          //   'fareType': 'PublicAndPrivateFares'
          // },
          'Brand': {
            '@type': 'BrandSummary',
            'name': '',
            'tier': 0
          }
        },
        'PassengerCriteria': {},
        'ProductCriteriaAir': [{
          'SpecificFlightCriteria': []
        }]
      }
    }
  };


  travelerReq: any;

  getAuthorization() {
    return 'Basic VW5pdmVyc2FsIEFQSS91QVBJNDM1NDgyNTAwMC0yNDk1YTRlNjpwN0EzeVV6RA==';
  }

  workBenchPost(): Observable<any> {
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.initiate_workBench;
    console.log(endpointURL);
    return this.httpClient.post<any>(endpointURL, this.workBenchRequest, this.httpHeaders);
  }

  setReservationIdentifier(data: any) {
    this.reservationIdentifierValue = data['ReservationResponse']['Reservation']['Identifier']['value'];
    this.createAddOfferRequest();
  }

  createAddOfferRequest() {
    const productList = this.gdsService.priceConfirmationResponse.offer.Product;
    this.addOfferRequest.OfferQueryBuildFromProducts.BuildFromProductsRequest.PricingModifiersAir.currencyCode
      = this.gdsService.priceConfirmationResponse.offer.Price.currencyCode;
    if (this.gdsService.priceConfirmationResponse.ReferenceList.length > 0) {
      this.addOfferRequest.OfferQueryBuildFromProducts.BuildFromProductsRequest.PricingModifiersAir.Brand.name
        = this.gdsService.priceConfirmationResponse.ReferenceList[0].brand[0].name;
      this.addOfferRequest.OfferQueryBuildFromProducts.BuildFromProductsRequest.PricingModifiersAir.Brand.tier
        = this.gdsService.priceConfirmationResponse.ReferenceList[0].brand[0].tier;
    }
    const specificFlightCriteriaList: SpecificFlightCriteria[] = [];
    productList.forEach(product => {
      const classOfService = product.passengerFlight[0].FlightProduct[0].classOfService;
      const cabin = product.passengerFlight[0].FlightProduct[0].cabin;
      product.flightSegment.forEach(g => {
        const specificFlightCriteria = new SpecificFlightCriteria();
        specificFlightCriteria.flightNumber = g.flight.number;
        specificFlightCriteria.carrier = g.flight.carrier;
        specificFlightCriteria.departureDate = g.flight.departure.date;
        specificFlightCriteria.departureTime = g.flight.departure.time;
        specificFlightCriteria.arrivalDate = g.flight.arrival.date;
        specificFlightCriteria.arrivalTime = g.flight.arrival.time;
        specificFlightCriteria.from = g.flight.departure.location;
        specificFlightCriteria.to = g.flight.arrival.location;
        specificFlightCriteria.classOfService = classOfService;
        specificFlightCriteria.cabin = cabin;
        specificFlightCriteria.segmentSequence = g.sequence;
        specificFlightCriteriaList.push(specificFlightCriteria);
      });
    });
    this.addOfferRequest.OfferQueryBuildFromProducts.BuildFromProductsRequest
      .ProductCriteriaAir[0].SpecificFlightCriteria = specificFlightCriteriaList;

    const shopRequest = this.gdsService.catalogOfferingsQueryRequest.value;
    this.addOfferRequest.OfferQueryBuildFromProducts.BuildFromProductsRequest.PassengerCriteria
      = shopRequest['CatalogOfferingsQueryRequest']['CatalogOfferingsRequest'][0]['PassengerCriteria'];
    console.log(this.addOfferRequest);
    this.addOfferPost().subscribe(
      (data: any) => {
        console.log(data);
      }
    );
  }

  addOfferPost(): Observable<any> {
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.addOffer
      + this.reservationIdentifierValue + '/offers/buildfromproducts';
    console.log(endpointURL);
    const req = JSON.stringify(this.addOfferRequest);
    console.log(req);
    return this.httpClient.post<any>(endpointURL, req, this.httpHeaders);
  }

  addTravelerPost(request): Observable<any> {
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.addTraveler + this.reservationIdentifierValue + '/travelers';
    console.log(endpointURL);
    return this.httpClient.post<any>(endpointURL, request, this.httpHeaders);
  }

  backOfficePost(request): Observable<any> {
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.backOffice + this.reservationIdentifierValue + '/backoffices';
    return this.httpClient.post<any>(endpointURL, request, this.httpHeaders);
  }

  primaryContactPost(request): Observable<any> {
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.primaryContact
      + this.reservationIdentifierValue + '/primarycontacts';
    return this.httpClient.post<any>(endpointURL, request, this.httpHeaders);
  }

  generalRemarksPost(request): Observable<any> {
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.generalRemarks
      + this.reservationIdentifierValue + '/reservationcomments';
    return this.httpClient.post<any>(endpointURL, request, this.httpHeaders);
  }

  bookRetriveGet(): Observable<any> {
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.bookRetrive + this.reservationIdentifierValue;
    return this.httpClient.get(endpointURL, this.httpHeaders);
  }

  addFOPPost(reservationID: string): Observable<any> {
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.addFOP + reservationID + 'formofpayment';
    return this.httpClient.post<any>(endpointURL, this.workBenchRequest, this.httpHeaders);
  }

  bookHoldCommitPost(): Observable<any> {
    const req = {};
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.bookHoldCommit + this.reservationIdentifierValue;
    console.log(endpointURL);
    return this.httpClient.post<any>(endpointURL, req, this.bookHttpHeaders);
  }

  retrivePNRPost(pnr: string): Observable<any> {
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.retrivePNR + '/' + pnr;
    return this.httpClient.get<any>(endpointURL, this.httpHeaders);
  }

  ticketIsuencePost(reservationID: string): Observable<any> {
    const endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
      environment.tripservices.tripservicesGDSProps.issueTicket + '/' + reservationID;
    return this.httpClient.post<any>(endpointURL, this.workBenchRequest, this.httpHeaders);
  }

}
