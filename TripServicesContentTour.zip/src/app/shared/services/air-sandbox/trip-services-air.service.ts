import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CatalogOffering } from '../../models/gds/Models';
import { Observable } from 'rxjs';
import { TripSearchGdsService } from '../air-search/trip-search-gds.service';

@Injectable({
  providedIn: 'root'
})
export class TripServicesAirService {

  catalogOfferingsQueryRequest: any;
  response: any; // CatalogOfferingsResponse;
  catalogOfferingsMap = new Map<string, CatalogOffering>();

  constructor(private httpClient: HttpClient, private tripSearchGdsService: TripSearchGdsService) { }

  httpHeaders = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Basic VW5pdmVyc2FsIEFQSS9VQVBJNDUwMDE1MjYxNi03NDBEMzFENzozUWUhS3I/ODYk',
      'XAUTH_TRAVELPORT_ACCESSGROUP': 'E2DB332E-D197-4272-9281-A4C1414ABF8C'
    })
  };

  post(endpointURL: string, request: any): Observable<any> {
    this.catalogOfferingsQueryRequest = request;
    return this.httpClient.post<any>(endpointURL, request, this.httpHeaders);
  }

  getCatalogOfferings() {
    const catalogOfferingsList = this.tripSearchGdsService.catalogOfferingsList(this.catalogOfferingsQueryRequest, this.response);
    catalogOfferingsList.forEach(e => this.catalogOfferingsMap.set(e.offerID, e));
    return catalogOfferingsList;
  }

  getCatalogOffering(offerID: string): CatalogOffering {
    return this.catalogOfferingsMap.get(offerID);
  }
}
