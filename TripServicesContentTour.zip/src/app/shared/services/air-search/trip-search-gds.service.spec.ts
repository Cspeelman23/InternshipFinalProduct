import { TestBed } from '@angular/core/testing';

import { TripSearchGdsService } from './trip-search-gds.service';

describe('TripSearchGdsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TripSearchGdsService = TestBed.get(TripSearchGdsService);
    expect(service).toBeTruthy();
  });
});
