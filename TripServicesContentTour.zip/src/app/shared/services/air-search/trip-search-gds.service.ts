import { Injectable } from '@angular/core';
import {
  Product, CatalogOffering, TermsAndConditions, ProductOption, FlightSegment, Flight,
  PassengerFlight, FlightProduct, Arrival, Departure, Brand, BrandAttribute, Identifier
} from '../../models/gds/Models';

@Injectable({
  providedIn: 'root'
})
export class TripSearchGdsService {

  catalogOfferingList: CatalogOffering[];
  productlist: Product[]; // To store all the products from the response
  // Creating new Map for Flights and Brands for easy access
  flightMap = new Map<String, Flight>();
  brandMap = new Map<String, Brand>();
  constructor() { }

  catalogOfferingsList(request, response) {
    this.catalogOfferingList = [];
    this.productlist = [];
    //request
    let catalogOfferingsRequest = request['CatalogOfferingsQueryRequest']['CatalogOfferingsRequest'];

    //response
    let catalogOfferingsResponse = response['CatalogOfferingsResponse'];
    let responseCatalogOfferingList = catalogOfferingsResponse['CatalogOfferings']['CatalogOffering'];
    let catalogOfferingsIdentifier = catalogOfferingsResponse['CatalogOfferings']['Identifier']['value'];
    // Not working for NDC
    // if (catalogOfferingsResponse['CatalogOfferings']['DefaultCurrency']['code'] !== undefined) {
    //   let currencyCode = catalogOfferingsResponse['CatalogOfferings']['DefaultCurrency']['code'];
    // }
    this.referenceList(catalogOfferingsResponse);

    if (responseCatalogOfferingList !== undefined) {
      for (let responseCatalogOffering of responseCatalogOfferingList) {
        let catalogOffering = new CatalogOffering();
        catalogOffering.CatalogOfferingsIdentifier = catalogOfferingsIdentifier;
        if (responseCatalogOffering['Identifier'] !== undefined) {
          const identifier = new Identifier();
          identifier.authority = responseCatalogOffering['Identifier']['authority'];
          identifier.value = responseCatalogOffering['Identifier']['value'];
          catalogOffering.identifier = identifier;
        }
        if (catalogOfferingsResponse['CatalogOfferings']['DefaultCurrency'] !== undefined) {
          catalogOffering.currency = catalogOfferingsResponse['CatalogOfferings']['DefaultCurrency']['code'];
        }
        catalogOffering.offerID = responseCatalogOffering['id'];
        // Getting TermsAndConditions data from response catalog offering
        let terms = new TermsAndConditions();
        terms.validatingCarrier = responseCatalogOffering['TermsAndConditions']['validatingCarrier'];
        terms.ExpiryDate = responseCatalogOffering['TermsAndConditions']['ExpiryDate'];
        terms.BaggageAllowance = responseCatalogOffering['TermsAndConditions']['BaggageAllowance'];
        catalogOffering.termsAndConditions = terms;
        // Getting price data
        catalogOffering.price = responseCatalogOffering['Price'];
        // Getting ProductOption data
        catalogOffering.productOptions = [];
        for (let responseProductOptions of responseCatalogOffering['ProductOptions']) {
          let productOption = new ProductOption();
          productOption.sequence = responseProductOptions['sequence'];
          // Getting From and To values from request
          productOption.departure = catalogOfferingsRequest[0]['SearchCriteriaFlight'][productOption.sequence - 1]['From']['value'];
          productOption.arrival = catalogOfferingsRequest[0]['SearchCriteriaFlight'][productOption.sequence - 1]['To']['value'];
          productOption.products = [];
          for (let responseProduct of responseProductOptions['Product']) {
            let product = new Product();
            product.productID = responseProduct['id'];
            product.totalDuration = (responseProduct['totalDuration']).slice(2).replace('H', 'hrs ').replace('M', 'mins');
            product.flightSegment = [];
            product.intermidiate = [];
            for (let responseflightSegment of responseProduct['FlightSegment']) {
              let flightSegment = new FlightSegment();
              flightSegment.sequence = responseflightSegment['sequence'];
              flightSegment.connectionDuration = responseflightSegment['connectionDuration'];
              flightSegment.boundFlightsInd = responseflightSegment['boundFlightsInd'];
              flightSegment.flightRef = responseflightSegment['Flight']['FlightRef'];
              flightSegment.flight = this.flightMap.get(flightSegment.flightRef); // Getting flight from Flight Map with id

              if (product.intermidiate.indexOf(flightSegment.flight.departure.location) === -1) {
                product.intermidiate.push(flightSegment.flight.departure.location);
              }
              if (product.intermidiate.indexOf(flightSegment.flight.arrival.location) === -1) {
                product.intermidiate.push(flightSegment.flight.arrival.location);
              }
              product.flightSegment.push(flightSegment);
            }
            product.passengerFlight = [];
            for (let responsePassengerFlight of responseProduct['PassengerFlight']) {
              let passengerFlight = new PassengerFlight();
              passengerFlight.passengerQuantity = responsePassengerFlight['passengerQuantity'];
              passengerFlight.passengerTypeCode = responsePassengerFlight['passengerTypeCode'];

              passengerFlight.FlightProduct = [];
              for (let flightProduct of responsePassengerFlight['FlightProduct']) {
                let flightprod = new FlightProduct();
                flightprod.segmentSequence = flightProduct['segmentSequence'];
                flightprod.classOfService = flightProduct['classOfService'];
                flightprod.cabin = flightProduct['cabin'];
                flightprod.fareBasisCode = flightProduct['fareBasisCode'];
                if (flightProduct['Brand'] !== undefined) {
                  flightprod.brand = this.brandMap.get(flightProduct['Brand']['BrandRef']);
                }
                passengerFlight.FlightProduct.push(flightprod);
              }
              product.passengerFlight.push(passengerFlight);
            }
            if (product.flightSegment.length > 1) {
              product.stops = product.flightSegment.length - 1;
            }
            product.carrier = responseCatalogOffering['TermsAndConditions']['validatingCarrier'];
            product.price = responseCatalogOffering['Price']['TotalPrice'];
            this.productlist.push(product);
            productOption.products.push(product);
          }
          catalogOffering.productOptions.push(productOption);
        }
        this.catalogOfferingList.push(catalogOffering);
      }
    }
    return this.catalogOfferingList;
  }

  referenceList(catalogOfferingsResponse) {
    const refList: any[] = catalogOfferingsResponse['ReferenceList'];
    let flightList: any;
    let brandList: any;
    for (const ref of refList) {
      flightList = ref['Flight'];
      brandList = ref['Brand'];
      if (flightList !== undefined) { this.createFlightMap(flightList); }
      if (brandList !== undefined) { this.createBrandMap(brandList); }
    }
  }

  createFlightMap(flightList) {
    for (const flight of flightList) {
      const f = new Flight();
      const a = new Arrival();
      const d = new Departure();

      a.date = flight['Arrival']['date'];
      a.location = flight['Arrival']['location'];
      a.terminal = flight['Arrival']['terminal'];
      a.time = (flight['Arrival']['time']).substring(0, 5);
      f.arrival = a;

      d.date = flight['Departure']['date'];
      d.location = flight['Departure']['location'];
      d.terminal = flight['Departure']['terminal'];
      d.time = (flight['Departure']['time']).substring(0, 5);
      f.departure = d;

      f.carrier = flight['carrier'];
      f.distance = flight['distance'];
      f.duration = flight['duration'];
      f.equipment = flight['equipment'];
      f.id = flight['id'];
      f.number = flight['number'];
      this.flightMap.set(flight['id'], f);
    }
  }

  createBrandMap(brandList) {
    for (const brand of brandList) {
      const brandWithAttr = new Brand();
      brandWithAttr.name = brand['name'];
      brandWithAttr.tier = brand['tier'];
      brandWithAttr.id = brand['id'];
      if (brand['Identifier'] !== undefined) {
        const identifier = new Identifier();
        identifier.authority = brand['Identifier']['authority'];
        identifier.value = brand['Identifier']['value'];
        brandWithAttr.identifier = identifier;
      }
      brandWithAttr.brandAttribute = [];

      for (const attribute of brand['BrandAttribute']) {
        const brandAttr = new BrandAttribute();
        brandAttr.classification = attribute['classification'];
        brandAttr.inclusion = attribute['inclusion'];
        brandWithAttr.brandAttribute.push(brandAttr);
      }
      this.brandMap.set(brandWithAttr.id, brandWithAttr);
    }
  }

  getflight(): any {
    for (const product of this.productlist) {
      console.log(product);
    }
  }
}
