import { TestBed } from '@angular/core/testing';
import { HttpClient, HttpHeaders, HttpHandler } from '@angular/common/http';
import { TripSearchPriceGdsService } from './trip-search-price-gds.service';

describe('TripSearchPriceGdsService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [HttpClient, HttpHandler]
  }));

  it('should be created', () => {
    const service: TripSearchPriceGdsService = TestBed.get(TripSearchPriceGdsService);
    expect(service).toBeTruthy();
  });
});
