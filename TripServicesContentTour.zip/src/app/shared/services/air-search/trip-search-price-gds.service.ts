import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import {
  OfferResponse, Offer, TermsAndConditionsFullAir, BaggageAllowanceDetail, BaggageItemDetail,
  BaggageFeeDetail, FareRuleInfoText, FareRuleText, ReferenceListBrand
} from '../../models/gds/Price';
import {
  Product, FlightSegment, Flight, PassengerFlight, FlightProduct, Brand, BrandAttribute,
  Arrival, Departure, Identifier, PriceBreakdownAir, Amount, Fees, Taxes, Tax, PriceDetail
} from '../../models/gds/Models';


@Injectable({
  providedIn: 'root'
})
export class TripSearchPriceGdsService {

  constructor(private httpClient: HttpClient) { }

  httpHeaders = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'E2ETrackingID': 'demo-app-123',
      'XAUTH_TRAVELPORT_ACCESSGROUP': '2A9A9814-3B18-4E65-9CDA-4F2CF7FFDBA4',
      'Authorization': this.getAuthorization(),
    })
  };

  brandMap = new Map<String, Brand>();

  endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
    environment.tripservices.tripservicesGDSProps.priceCache;

  getAuthorization() {
    return 'Basic VW5pdmVyc2FsIEFQSS9VQVBJNDUwMDE1MjYxNi03NDBEMzFENzozUWUhS3I/ODYk';
  }

  setPriceRequest(request) {
    console.log(request);
  }

  post(request: JSON): Observable<any> {
    return this.httpClient.post<any>(this.endpointURL, request, this.httpHeaders);
  }

  priceConfirmation(response): OfferResponse {
    const offerResponse = new OfferResponse();
    // console.log(response['OfferResponse']['Offer']['id']);

    const resOffer = response['OfferResponse']['Offer'];
    if (resOffer !== undefined) {
      offerResponse.ReferenceList = this.referenceList(response['OfferResponse']);

      const offer = new Offer();
      offer.id = resOffer['id'];
      offer.Product = [];
      for (const resProduct of resOffer['Product']) {
        const product = new Product();
        product.productID = resProduct['id'];
        product.totalDuration = resProduct['totalDuration'];
        product.flightSegment = [];
        for (const responseflightSegment of resProduct['FlightSegment']) {
          const flightSegment = new FlightSegment();
          flightSegment.id = responseflightSegment['id'];
          flightSegment.sequence = responseflightSegment['sequence'];
          if (responseflightSegment['connectionDuration'] !== undefined) {
            flightSegment.connectionDuration =
              (responseflightSegment['connectionDuration']).slice(2).replace('H', 'hrs ').replace('M', 'mins');
          }
          flightSegment.flight = this.createFlight(responseflightSegment['Flight']);
          product.flightSegment.push(flightSegment);
        }
        product.passengerFlight = [];
        for (const responsePassengerFlight of resProduct['PassengerFlight']) {
          const passengerFlight = new PassengerFlight();
          passengerFlight.passengerQuantity = responsePassengerFlight['passengerQuantity'];
          passengerFlight.passengerTypeCode = responsePassengerFlight['passengerTypeCode'];
          passengerFlight.FlightProduct = [];
          for (const responseFlightProduct of responsePassengerFlight['FlightProduct']) {
            const flightProduct = new FlightProduct();
            flightProduct.segmentSequence = [];
            for (const sequence of responseFlightProduct['segmentSequence']) {
              flightProduct.segmentSequence.push(sequence);
            }
            flightProduct.classOfService = responseFlightProduct['classOfService'];
            flightProduct.cabin = responseFlightProduct['cabin'];
            flightProduct.fareBasisCode = responseFlightProduct['fareBasisCode'];
            if (responseFlightProduct['Brand'] !== undefined) {
              flightProduct.brand = this.brandMap.get(responseFlightProduct['Brand']['BrandRef']);
            }
            passengerFlight.FlightProduct.push(flightProduct);
          }
          product.passengerFlight.push(passengerFlight);
        }
        offer.Product.push(product);
      }
      // price
      const price = resOffer['Price'];
      const priceDetail = new PriceDetail();
      priceDetail.currencyCode = price['currencyCode'];
      priceDetail.id = price['id'];
      priceDetail.Base = price['Base'];
      priceDetail.TotalTaxes = price['TotalTaxes'];
      priceDetail.TotalFees = price['TotalFees'];
      priceDetail.TotalPrice = price['TotalPrice'];
      priceDetail.PriceBreakdown = [];
      if (price['PriceBreakdown'] !== undefined) {
        for (const priceBreak of price['PriceBreakdown']) {
          const priceBrkDown = new PriceBreakdownAir();
          priceBrkDown.quantity = priceBreak['quantity'];
          priceBrkDown.requestedPassengerType = priceBreak['requestedPassengerType'];
          const amt = new Amount();
          amt.Base = priceBreak['Amount']['Base'];
          amt.Total = priceBreak['Amount']['Total'];
          const fees = new Fees();
          fees.TotalFees = priceBreak['Amount']['Fees']['TotalFees'];
          amt.Fees = fees;
          const taxes = new Taxes();
          taxes.TotalTaxes = priceBreak['Amount']['Taxes']['TotalTaxes'];
          taxes.Tax = [];
          for (const tax of priceBreak['Amount']['Taxes']['Tax']) {
            const t = new Tax();
            t.taxCode = tax['taxCode'];
            t.value = tax['value'];
            taxes.Tax.push(t);
          }
          amt.Taxes = taxes;
          priceBrkDown.amount = amt;
          priceDetail.PriceBreakdown.push(priceBrkDown);
          offer.Price = priceDetail;
          // TermsAndConditionsFull
          offer.TermsAndConditionsFull = [];
          if (resOffer['TermsAndConditionsFull'] !== undefined) {
            for (const resTerms of resOffer['TermsAndConditionsFull']) {
              const termsAir = new TermsAndConditionsFullAir();
              termsAir.validatingCarrier = resTerms['validatingCarrier'];
              termsAir.ExpiryDate = resTerms['ExpiryDate'];
              termsAir.BaggageAllowance = [];
              if (resTerms['BaggageAllowance'] !== undefined) {
                for (const bagAllowance of resTerms['BaggageAllowance']) {
                  const bagDetail = new BaggageAllowanceDetail();
                  bagDetail.url = bagAllowance['url'];
                  bagDetail.passengerTypeCodes = [];
                  (bagAllowance['passengerTypeCodes']).forEach(e => {
                    bagDetail.passengerTypeCodes.push(e);
                  });
                  bagDetail.baggageType = bagAllowance['baggageType'];
                  bagDetail.ProductRef = [];
                  if (bagAllowance['ProductRef'] !== undefined) {
                    (bagAllowance['ProductRef']).forEach(e => {
                      bagDetail.ProductRef.push(e);
                    });
                  }
                  bagDetail.SegmentSequenceList = [];
                  if (bagAllowance['SegmentSequenceList'] !== undefined) {
                    (bagAllowance['SegmentSequenceList']).forEach(e => {
                      bagDetail.SegmentSequenceList.push(e);
                    });
                  }
                  bagDetail.BaggageItem = [];
                  if (bagAllowance['BaggageItem'] !== undefined) {
                    (bagAllowance['BaggageItem']).forEach(e => {
                      const bagItemDetail = new BaggageItemDetail();
                      bagItemDetail.quantity = e['quantity'];
                      bagItemDetail.Text = e['Text'];
                      if (e['BaggageFee'] !== undefined) {
                        const bagFeeDetail = new BaggageFeeDetail();
                        bagFeeDetail.code = e['BaggageFee']['code'];
                        bagFeeDetail.approximateInd = e['BaggageFee']['approximateInd'];
                        bagFeeDetail.value = e['BaggageFee']['value'];
                        bagItemDetail.BaggageFee = bagFeeDetail;
                        bagDetail.BaggageItem.push(bagItemDetail);
                      }
                    });
                  }
                  bagDetail.Text = bagAllowance['Text'];
                  termsAir.BaggageAllowance.push(bagDetail);
                }
              }
              termsAir.FareRuleInfo = [];
              if (resTerms['FareRuleInfo'] !== undefined) {
                for (const fareRuleInfo of resTerms['FareRuleInfo']) {
                  const fareRuleInfoText = new FareRuleInfoText();
                  fareRuleInfoText.flightRefs = [];
                  if (fareRuleInfo['flightRefs'] !== undefined) {
                    (fareRuleInfo['flightRefs']).forEach(e => {
                      fareRuleInfoText.flightRefs.push(e);
                    });
                  }
                  fareRuleInfoText.ruleNumber = fareRuleInfo['ruleNumber'];
                  fareRuleInfoText.tariffNumber = fareRuleInfo['tariffNumber'];
                  fareRuleInfoText.FareRuleText = [];
                  if (fareRuleInfo['FareRuleText'] !== undefined) {
                    (fareRuleInfo['FareRuleText']).forEach(e => {
                      const fareRuleText = new FareRuleText();
                      fareRuleText.name = e['name'];
                      fareRuleText.value = e['value'];
                      fareRuleInfoText.FareRuleText.push(fareRuleText);
                    });
                  }
                  termsAir.FareRuleInfo.push(fareRuleInfoText);
                }
              }
              offer.TermsAndConditionsFull.push(termsAir);
            }
          }
        }
      }
      offerResponse.offer = offer;
      offerResponse.Result = response['OfferResponse']['Result'];
      offerResponse.Identifier = response['OfferResponse']['Identifier']['value'];
      // offerResponse.ReferenceList = this.referenceList(response);
      console.log(offerResponse);
      return offerResponse;
    } else {
      alert(response['OfferResponse']['Result']['Error']['0']['Message']);
      // return null;
    }
  }

  referenceList(offerResponse: any): ReferenceListBrand[] {
    const referenceList: ReferenceListBrand[] = [];
    if (offerResponse['ReferenceList'] !== undefined) {
      for (const ref of offerResponse['ReferenceList']) {
        const refListBrand = new ReferenceListBrand();
        if (ref['Brand'] !== undefined) {
          refListBrand.brand = this.createBrandMap(ref['Brand']);
        }
        referenceList.push(refListBrand);
      }
    }
    // console.log(referenceList);
    return referenceList;
  }
  createBrandMap(resBrandList: any): Brand[] {
    const brandsList: Brand[] = [];
    for (const brand of resBrandList) {
      const brandWithAttr = new Brand();
      brandWithAttr.name = brand['name'];
      brandWithAttr.tier = brand['tier'];
      brandWithAttr.id = brand['id'];

      const identifier = new Identifier();
      identifier.authority = brand['Identifier']['authority'];
      identifier.value = brand['Identifier']['value'];
      brandWithAttr.identifier = identifier;
      brandWithAttr.brandAttribute = [];

      for (const attribute of brand['BrandAttribute']) {
        const brandAttr = new BrandAttribute();
        brandAttr.classification = attribute['classification'];
        brandAttr.inclusion = attribute['inclusion'];
        brandWithAttr.brandAttribute.push(brandAttr);
      }
      // console.log(brandWithAttr);
      this.brandMap.set(brandWithAttr.id, brandWithAttr);
      brandsList.push(brandWithAttr);
    }
    // console.log(brandsList);
    return brandsList;
  }

  createFlight(responseflight: any): Flight {
    const flight = new Flight();
    flight.distance = responseflight['distance'];
    flight.duration = (responseflight['duration']).slice(2).replace('H', 'hrs ').replace('M', 'mins');
    flight.carrier = responseflight['carrier'];
    flight.number = responseflight['number'];
    flight.operatingCarrier = responseflight['operatingCarrier'];
    flight.operatingCarrierName = responseflight['operatingCarrierName'];
    flight.equipment = responseflight['equipment'];
    flight.id = responseflight['id'];
    const a = new Arrival();
    const d = new Departure();
    a.date = responseflight['Arrival']['date'];
    a.location = responseflight['Arrival']['location'];
    a.terminal = responseflight['Arrival']['terminal'];
    a.time = responseflight['Arrival']['time'];
    flight.arrival = a;
    d.date = responseflight['Departure']['date'];
    d.location = responseflight['Departure']['location'];
    d.terminal = responseflight['Departure']['terminal'];
    d.time = responseflight['Departure']['time'];
    flight.departure = d;
    return flight;
  }
}
