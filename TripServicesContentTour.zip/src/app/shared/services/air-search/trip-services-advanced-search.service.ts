import { Injectable } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class TripServicesAdvancedSearchService {

  constructor(private formBuilder: FormBuilder) { }
  fareType: string = null;
  accountCode: string = null;
  carrierPeference: [];
  connectionType: string = null;
  cabins: string[] = [];
  searchModifiersAir = false;
  pricingModifiersAir = false;

  update(fareType: string, accountCode: string, connectionType: string, cabins: string[],
    carrierPeference: any) {
    this.pricingModifiersAir = false;
    this.searchModifiersAir = false;
    this.fareType = fareType;
    this.accountCode = accountCode;
    this.connectionType = connectionType;
    this.cabins = cabins;
    this.carrierPeference = carrierPeference;

    if (this.fareType !== undefined && this.fareType !== null) {
      this.pricingModifiersAir = true;
    }
    console.log('price - ' + this.pricingModifiersAir);

    if ((this.connectionType !== null && this.connectionType !== undefined) ||
      (this.cabins.length > 0 && this.cabins !== undefined) ||
      (this.carrierPeference.length > 0 && this.carrierPeference !== undefined)) {
      this.searchModifiersAir = true;
    }
    console.log('search - ' + this.searchModifiersAir);

    console.log(this.fareType);
    console.log(this.accountCode);
    console.log(this.connectionType);
    console.log(this.cabins);
    console.log(this.carrierPeference);
  }

  getSearchModifiersAir(): FormGroup {
    const searchModifiers = this.formBuilder.group({});

    if (this.connectionType !== null && this.connectionType !== undefined) {
      searchModifiers.addControl('FlightType',
        this.formBuilder.group({
          connectionType: [this.connectionType],
          excludeInterlineConnectionsInd: [true]
        }));
    }

    if (this.carrierPeference.length > 0) {
      searchModifiers.addControl('CarrierPreference',
        this.formBuilder.array([
          this.formBuilder.group({
            type: ['Preferred'],
            carriers: [this.carrierPeference]
          })
        ])
      );
    }

    if (this.cabins.length > 0 ) {
      searchModifiers.addControl('CabinPreference',
        this.formBuilder.array([
          this.formBuilder.group({
            type: ['Preferred'],
            cabins: [this.cabins],
            legSequence: this.formBuilder.array([])
          })
        ])
      );
    }
    return searchModifiers;
  }

  getPricingModifiersAir(): FormGroup {
    const pricingModifiers = this.formBuilder.group({
      '@type': 'PricingModifiersAir',
      currencyCode: 'USD',
      OrganizationIdentifier: this.formBuilder.array([
        this.formBuilder.group({
          type: 'Account',
          value: 'CLASSIC'
        })
      ])
    });

    if (this.fareType !== null && this.fareType !== undefined) {
      pricingModifiers.addControl('FareSelection',
        this.formBuilder.group({
          '@type': 'FareSelectionDetail',
          fareType: this.fareType
        })
      );
    }
    return pricingModifiers;
  }
}
