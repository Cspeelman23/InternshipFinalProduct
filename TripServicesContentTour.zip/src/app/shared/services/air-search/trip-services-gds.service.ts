import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { Observable } from 'rxjs';
import { CatalogOffering } from '../../models/gds/Models';
import { TripSearchGdsService } from './trip-search-gds.service';
import { BehaviorSubject } from 'rxjs';
import { TripSearchPriceGdsService } from './trip-search-price-gds.service';
import { FormGroup } from '@angular/forms';
import { OfferResponse } from '../../models/gds/Price';

@Injectable({
  providedIn: 'root'
})
export class TripServicesGDSService {
  // public router: Router,
  constructor(private httpClient: HttpClient,
    private tripSearchGdsService: TripSearchGdsService,
    private priceGdsService: TripSearchPriceGdsService) {
  }

  httpHeaders = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'E2ETrackingID': 'demo-app-123',
      'XAUTH_TRAVELPORT_ACCESSGROUP': '2A9A9814-3B18-4E65-9CDA-4F2CF7FFDBA4',
      'Authorization': this.getAuthorization(),
    }),
    search: new URLSearchParams()
  };

  // https://zu2-api-np.travelport.com:443/qa/4/LWS_DOMAIN/catalogofferings?view=detail
  // endpointURL: string = environment.tripservices.tripservicesGDSProps.baseURL +
  //   environment.tripservices.tripservicesGDSProps.lowfareBase;

  datasource = new BehaviorSubject<CatalogOffering[]>(null);
  responseData = this.datasource.asObservable();

  catalogOfferingsQueryRequest: FormGroup;
  sccChannelID: string;
  priceConfirmationResponse: OfferResponse;
  catalogOfferingsMap = new Map<string, CatalogOffering>();

  getAuthorization() {
    return 'Basic VW5pdmVyc2FsIEFQSS91QVBJNDM1NDgyNTAwMC0yNDk1YTRlNjpwN0EzeVV6RA==';
  }

  postSearch(request: FormGroup, sccChannelID?: string): Observable<any> {
    console.log(request.value);
    let endpointURL: string;
    // sccChannelID = 'NGSX';
    // this.httpHeaders.params.set('view', 'detail');
    // let search = new URLSearchParams();
    if (sccChannelID !== undefined && sccChannelID !== null) {
      endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
        environment.tripservices.tripservicesGDSProps.lowfareBase + '?view=detail&sccChannelID=' + sccChannelID;
    } else {
      endpointURL = environment.tripservices.tripservicesGDSProps.baseURL +
        environment.tripservices.tripservicesGDSProps.lowfareBase + '?view=detail';
    }
    console.log(endpointURL);
    // this.httpHeaders.search.set('view', 'detail');
    this.catalogOfferingsQueryRequest = request;
    this.sccChannelID = sccChannelID;
    return this.httpClient.post<any>(endpointURL, request.value, this.httpHeaders);
  }

  setResponseData(responseData) {
    // this.response = data;
    this.datasource.next(this.getCatalogOfferings(responseData));
  }

  getCatalogOfferings(responseData): CatalogOffering[] {
    const catalogOfferingsList = this.tripSearchGdsService.catalogOfferingsList(this.catalogOfferingsQueryRequest.value, responseData);
    catalogOfferingsList.forEach(e => this.catalogOfferingsMap.set(e.offerID, e));
    // console.log(catalogOfferingsList);
    return catalogOfferingsList;
  }

  getCatalogOffering(offerID: string): CatalogOffering {
    return this.catalogOfferingsMap.get(offerID);
  }

  getPriceSearch(priceRequest) {
    return this.priceGdsService.post(priceRequest);
  }

  createPriceResponse(responseData) {
    this.priceConfirmationResponse = this.priceGdsService.priceConfirmation(responseData);
  }

  getPassengerCriteria() {
    if (this.catalogOfferingsQueryRequest !== undefined) {
      return this.catalogOfferingsQueryRequest.get('CatalogOfferingsQueryRequest.CatalogOfferingsRequest.0.PassengerCriteria').value;
    } else {
      return [{ number: 1, value: 'ADT' }];
    }
  }

}
