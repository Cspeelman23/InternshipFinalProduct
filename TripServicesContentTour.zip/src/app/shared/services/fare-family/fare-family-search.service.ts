import { Injectable } from '@angular/core';
import {
  Product, FareFamilyOffering, TermsAndConditions, ProductBrandPriceOption, FlightSegment,
  Flight, PassengerFlight, FlightProduct, Arrival, Departure, Brand, BrandAttribute,
  Identifier, OfferProductGroup, Price, UpsellGroup
} from '../../models/farefamily/FFS_Refine';

@Injectable({
  providedIn: 'root'
})
export class FareFamilySearchService {

  upsellGroupList: UpsellGroup[];
  fareFamilyOfferingList: UpsellGroup[];
  offerProductGroupList: OfferProductGroup[];

  // Maps to derive data from FareFamilyOfferings & ReferenceList - spicified by sequence
  productOfferMap = new Map<string, string>();      // 1) Map<Product_ID, Offer_ID>
  productBrandMap = new Map<string, string>();      // 2) Map<Product_ID, Brand_ID>
  productTandCMap = new Map<string, string>();      // 3) Map<Product_ID, TandC_ID>
  productPriceMap = new Map<string, Price>();       // 4) Map<Product_ID, Price>
  flightMap = new Map<string, Flight>();            // 5) Map<Flight_ID, Flight>
  brandMap = new Map<string, Brand>();              // 6) Map<Brand_ID, Brand>
  tandcMap = new Map<string, TermsAndConditions>(); // 7) Map<TandC_ID, TandC>

  // After setting above maps, consolidate data in below map
  productMap = new Map<string, Product>();          // Map<Product_ID, Product>

  constructor() { }

  fareFamilyOfferingsList(request, response) {

    this.upsellGroupList = [];
    this.fareFamilyOfferingList = [];
    this.offerProductGroupList = [];

    // request
    // const fareFamilyOfferingsRequest = request['FareFamilyOfferingsQueryRequest']['FareFamilyOfferingsRequest'];

    // response
    const fareFamilyOfferingsResponse = response['FareFamilyOfferingsResponse'];
    const responseFareFamilyOfferingList = fareFamilyOfferingsResponse['FareFamilyOfferings']['FareFamilyOffering'];

    this.deriveData(responseFareFamilyOfferingList);
    this.referenceList(fareFamilyOfferingsResponse);
    this.productReferenceList(fareFamilyOfferingsResponse);

    return this.fareFamilyOfferingList;
  }

  deriveData(responseFareFamilyOfferingList) {
    if (responseFareFamilyOfferingList !== undefined) {
      for (const responseFareFamilyOffering of responseFareFamilyOfferingList) {
        const offerRef = responseFareFamilyOffering['id'];
        for (const responseProductBrandPriceOption of responseFareFamilyOffering['ProductBrandPriceOption']) {
          const brandRef = responseProductBrandPriceOption['BrandRef'];
          const tandcRef = responseProductBrandPriceOption['TermsAndConditionsRef'];
          const responsePrice = responseProductBrandPriceOption['Price'];
          let price: any;
          if (responsePrice !== undefined) {
            price = new Price();
            price.base = responsePrice['Base'];
            price.totalTaxes = responsePrice['TotalTaxes'];
            price.totalFees = responsePrice['TotalFees'];
            price.totalPrice = responsePrice['TotalPrice'];
          }
          for (const pdtRef of responseProductBrandPriceOption['ProductRef']) {
            this.productOfferMap.set(pdtRef, offerRef);
            this.productBrandMap.set(pdtRef, brandRef);
            this.productTandCMap.set(pdtRef, tandcRef);
            if (price != null) {
              this.productPriceMap.set(pdtRef, price);
            }
          }
        }
      }
    }

    // this.getProductOfferMap();
    // this.getProductBrandMap();
    // this.getProductTandCMap();
    // this.getProductPriceMap();
  }

  getProductOfferMap(): any {
    console.log('###### VALUES FROM productOfferMap = ');
    this.productOfferMap.forEach((value: string, key: string) => {
      console.log(key, value);
    });
  }

  getProductBrandMap(): any {
    console.log('###### VALUES FROM productBrandMap = ');
    this.productBrandMap.forEach((value: string, key: string) => {
      console.log(key, value);
    });
  }

  getProductTandCMap(): any {
    console.log('###### VALUES FROM productTandCMap = ');
    this.productTandCMap.forEach((value: string, key: string) => {
      console.log(key, value);
    });
  }

  getProductPriceMap(): any {
    console.log('###### VALUES FROM productPriceMap = ');
    this.productPriceMap.forEach((value: Price, key: string) => {
      console.log(key, value);
    });
  }

  referenceList(fareFamilyOfferingsResponse) {
    const refList: any[] = fareFamilyOfferingsResponse['ReferenceList'];
    let flightList: any;
    let brandList: any;
    let tandcList: any;
    for (const ref of refList) {
      flightList = ref['Flight'];
      brandList = ref['Brand'];
      tandcList = ref['TermsAndConditions'];
      if (flightList !== undefined) { this.createFlightMap(flightList); }
      if (brandList !== undefined) { this.createBrandMap(brandList); }
      if (tandcList !== undefined) { this.createTandCMap(tandcList); }
    }
  }

  productReferenceList(fareFamilyOfferingsResponse) {
    const refList: any[] = fareFamilyOfferingsResponse['ReferenceList'];
    let productList: any;
    for (const ref of refList) {
      productList = ref['Product'];
      if (productList !== undefined) { this.createProductMap(productList); }
    }
  }

  createProductMap(productList) {

    // this.getBrandMap();
    // this.getTandCMap();

    for (const responseProduct of productList) {
      const product = new Product();
      product.productID = responseProduct['id'];
      product.offerID = this.productOfferMap.get(product.productID);
      product.brandID = this.productBrandMap.get(product.productID);
      product.brand = this.brandMap.get(product.brandID);
      product.tandcID = this.productTandCMap.get(product.productID);
      product.termsAndConditions = this.tandcMap.get(product.tandcID);
      product.price = this.productPriceMap.get(product.productID);
      product.totalDuration = responseProduct['totalDuration'];
      product.flightSegment = [];
      product.flightIDs = [];
      for (const responseFlightSegment of responseProduct['FlightSegment']) {
        const flightSegment = new FlightSegment();
        flightSegment.sequence = responseFlightSegment['sequence'];
        flightSegment.connectionDuration = responseFlightSegment['connectionDuration'];
        flightSegment.boundFlightsInd = responseFlightSegment['boundFlightsInd'];
        flightSegment.flightRef = responseFlightSegment['Flight']['FlightRef'];
        flightSegment.flight = this.flightMap.get(flightSegment.flightRef); // Getting flight from Flight Map with id
        product.flightSegment.push(flightSegment);
        product.flightIDs.push(flightSegment.flightRef);
      }
      if (product.flightSegment.length > 1) {
        product.stops = product.flightSegment.length - 1;
      } else {
        product.stops = 0;
      }
      product.passengerFlight = [];
      for (const responsePassengerFlight of responseProduct['PassengerFlight']) {
        const passengerFlight = new PassengerFlight();
        passengerFlight.passengerQuantity = responsePassengerFlight['passengerQuantity'];
        passengerFlight.passengerTypeCode = responsePassengerFlight['passengerTypeCode'];
        passengerFlight.FlightProduct = [];
        for (const responseFlightProduct of responsePassengerFlight['FlightProduct']) {
          const flightProduct = new FlightProduct();
          flightProduct.segmentSequence = responseFlightProduct['segmentSequence'];
          flightProduct.classOfService = responseFlightProduct['classOfService'];
          flightProduct.cabin = responseFlightProduct['cabin'];
          flightProduct.fareBasisCode = responseFlightProduct['fareBasisCode'];
          passengerFlight.FlightProduct.push(flightProduct);
        }
        product.passengerFlight.push(passengerFlight);
      }

      const offerProductGroup = new OfferProductGroup();
      offerProductGroup.offerID = product.offerID;
      offerProductGroup.productID = product.productID;
      offerProductGroup.flightIDs = product.flightIDs;
      this.offerProductGroupList.push(offerProductGroup);

      this.productMap.set(responseProduct['id'], product);
    }

    // const sortAlphaNum = (a, b) => a.localeCompare(b, 'en', { numeric: true })
    // tslint:disable-next-line: max-line-length
    // this.offerProductGroupList.sort((a, b) => (a.offerID === b.offerID && a.flightIDs !== b.flightIDs) ? a.flightIDs < b.flightIDs ? -1 : 1 : 0);
    // tslint:disable-next-line: max-line-length
    this.offerProductGroupList.sort((a, b) => (a.offerID === b.offerID && a.flightIDs !== b.flightIDs) ? a.flightIDs[0].localeCompare(b.flightIDs[0], 'en', { numeric: true }) : 0);

    // Form Upsell Groups having same Flight references - flightIDs
    for (const offerProductGroup of this.offerProductGroupList) {
      const upsellGroup = new UpsellGroup();
      upsellGroup.offerProductGroups = [];
      const upsellGroupInternal = this.getUpsellGroupsByFlights(offerProductGroup.flightIDs);
      for (const offerProductGroupInternal of upsellGroupInternal) {
        offerProductGroupInternal.product = this.productMap.get(offerProductGroupInternal.productID);
        upsellGroup.offerProductGroups.push(offerProductGroupInternal);
      }
      this.upsellGroupList.push(upsellGroup);
    }

    // Remove Duplicate Upsell Groups
    this.fareFamilyOfferingList = this.upsellGroupList.filter((upsellGroup, index) => {
      return index === this.upsellGroupList.findIndex(obj => {
        return JSON.stringify(obj.offerProductGroups[0].flightIDs) === JSON.stringify(upsellGroup.offerProductGroups[0].flightIDs);
      });
    });

    this.getUniqueUpsellGroupList();
    // this.getUpsellGroupList();
    // this.getOfferProductGroupList();
    // this.getProductMap();
  }

  getUniqueUpsellGroupList(): any {
    console.log(this.fareFamilyOfferingList);
    console.log('###### VALUES FROM uniqueUpsellGroupList = ');
    for (const upsellGroup of this.fareFamilyOfferingList) {
      console.log(upsellGroup);
    }
  }

  getUpsellGroupList(): any {
    console.log('###### VALUES FROM upsellGroupList = ');
    for (const upsellGroup of this.upsellGroupList) {
      console.log(upsellGroup);
    }
  }

  getUpsellGroupsByFlights(flightIDs: string[]): OfferProductGroup[] {
    return this.offerProductGroupList.filter(o => o.flightIDs[0] === flightIDs[0]);
  }

  getUpsellGroupsByOffer(offerID: string): OfferProductGroup[] {
    return this.offerProductGroupList.filter(o => o.offerID === offerID);
  }

  getOfferProductGroupList(): any {
    console.log('###### VALUES FROM offerProductGroupList = ' + this.offerProductGroupList);
    for (const offerProductGroup of this.offerProductGroupList) {
      console.log(offerProductGroup);
    }
  }

  getProductMap(): any {
    console.log('###### VALUES FROM productMap = ' + this.productMap);
    this.productMap.forEach((value: Product, key: string) => {
      console.log(key, value);
    });
  }

  createFlightMap(flightList) {
    for (const flight of flightList) {
      const f = new Flight();
      const a = new Arrival();
      const d = new Departure();

      a.date = flight['Arrival']['date'];
      a.location = flight['Arrival']['location'];
      a.terminal = flight['Arrival']['terminal'];
      a.time = (flight['Arrival']['time']).substring(0, 5);
      f.arrival = a;

      d.date = flight['Departure']['date'];
      d.location = flight['Departure']['location'];
      d.terminal = flight['Departure']['terminal'];
      d.time = (flight['Departure']['time']).substring(0, 5);
      f.departure = d;

      f.carrier = flight['carrier'];
      f.distance = flight['distance'];
      f.duration = flight['duration'];
      f.equipment = flight['equipment'];
      f.flightID = flight['id'];
      f.number = flight['number'];
      if (flight['operatingCarrierName'] !== undefined) {
        f.operatingCarrierName = flight['operatingCarrierName'];
      } else {
        f.operatingCarrierName = '';
      }
      this.flightMap.set(flight['id'], f);
    }
    // console.log('###### VALUES FROM flightMap = ' + this.flightMap);
    // this.getFlightMap();
  }

  getFlightMap(): any {
    this.flightMap.forEach((value: Flight, key: string) => {
      console.log(key, value);
    });
  }

  createTandCMap(tandcList) {
    for (const tandcResponse of tandcList) {
      const tandc = new TermsAndConditions();
      tandc.validatingCarrier = tandcResponse['validatingCarrier'];
      tandc.tandcID = tandcResponse['id'];
      if (tandcResponse['BaggageAllowance'] !== undefined) {
        tandc.baggageAllowanceQuantity = tandcResponse['BaggageAllowance'][0]['BaggageItem'][0]['quantity'];
      }
      this.tandcMap.set(tandc.tandcID, tandc);
    }
  }

  getTandCMap(): any {
    console.log('###### VALUES FROM tandcMap = ' + this.tandcMap);
    this.tandcMap.forEach((value: TermsAndConditions, key: string) => {
      console.log(key, value);
    });
  }

  createBrandMap(brandList) {
    for (const brand of brandList) {
      const brandWithAttr = new Brand();
      brandWithAttr.name = brand['name'];
      brandWithAttr.tier = brand['tier'];
      brandWithAttr.brandID = brand['id'];
      if (brand['Identifier'] !== undefined) {
        const identifier = new Identifier();
        identifier.authority = brand['Identifier']['authority'];
        identifier.value = brand['Identifier']['value'];
        brandWithAttr.identifier = identifier;
      }
      brandWithAttr.brandAttribute = [];

      for (const attribute of brand['BrandAttribute']) {
        const brandAttr = new BrandAttribute();
        brandAttr.classification = attribute['classification'];
        brandAttr.inclusion = attribute['inclusion'];
        brandWithAttr.brandAttribute.push(brandAttr);
      }
      this.brandMap.set(brandWithAttr.brandID, brandWithAttr);
    }
  }

  getBrandMap(): any {
    console.log('###### VALUES FROM brandMap = ' + this.brandMap);
    this.brandMap.forEach((value: Brand, key: string) => {
      console.log(key, value);
    });
  }
}
