import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { FareFamilyOffering, UpsellGroup } from '../../models/farefamily/FFS_Refine';
import { environment } from '../../../../environments/environment';
import { FormGroup } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { FareFamilySearchService } from './fare-family-search.service';

@Injectable({
  providedIn: 'root'
})
export class FareFamilyShopService {

  constructor(private httpClient: HttpClient,
    private fareFamilySearchService: FareFamilySearchService) { }

  httpHeaders = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'E2ETrackingID': 'Demo-UI-Invocation',
      'XAUTH_TRAVELPORT_ACCESSGROUP': 'BEB57221-4CBF-4E07-B235-B110CF9FD993'
    })
  };

  datasource = new BehaviorSubject<UpsellGroup[]>(null);
  responseData = this.datasource.asObservable();

  fareFamilyOfferingsQueryRequest: FormGroup;
  fareFamilyOfferingsMap = new Map<string, FareFamilyOffering>();

  postSearch(request: any, isMock: boolean): Observable<any> {
    this.fareFamilyOfferingsQueryRequest = request;
    let endpointURL: string;
    endpointURL = environment.tripservices.tripservicesFFSProps.ffsURI2;
    if (isMock) {
      console.log('Mock Response - from FFS API');
      return this.httpClient.get('../assets/FFSResponse_Extended.json');
    } else {
      console.log('RealTime Call - FFS URI => ' + endpointURL);
      return this.httpClient.post<any>(endpointURL, request, this.httpHeaders);
    }
  }

  setResponseData(responseData) {
    this.datasource.next(this.getFareFamilyOfferings(responseData));
  }

  getFareFamilyOfferings(responseData): UpsellGroup[] {
    // tslint:disable-next-line: max-line-length
    const fareFamilyOfferingsList = this.fareFamilySearchService.fareFamilyOfferingsList(this.fareFamilyOfferingsQueryRequest.value, responseData);
    return fareFamilyOfferingsList;
  }

  getFareFamilyOffering(offerID: string): FareFamilyOffering {
    return this.fareFamilyOfferingsMap.get(offerID);
  }

}
