import { TestBed } from '@angular/core/testing';

import { HttpClient, HttpHeaders, HttpHandler } from '@angular/common/http';
import { TripServicesHCCDService } from './trip-services-hccd.service';

describe('TripServicesHCCDService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [HttpClient, HttpHandler]
  }));

  it('should be created', () => {
    const service: TripServicesHCCDService = TestBed.get(TripServicesHCCDService);
    expect(service).toBeTruthy();
  });
});
