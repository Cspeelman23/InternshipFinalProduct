import { Equipment } from '../../models/gds/Equipment';
// Data harvested from the following site: http://www.airlinecodes.co.uk/arctypes.asp
export const EQUIPMENTDATA: Equipment[] = [
    {
      "IATA": "100",
      "ICAO": "F100",
      "Wake": "Fokker 100"
    },
    {
      "IATA": "141",
      "ICAO": "B461",
      "Wake": "BAe 146-100 Pax"
    },
    {
      "IATA": "142",
      "ICAO": "B462",
      "Wake": "BAe 146-200 Pax"
    },
    {
      "IATA": "143",
      "ICAO": "B463",
      "Wake": "BAe 146-300 Pax"
    },
    {
      "IATA": "14X",
      "ICAO": "B461",
      "Wake": "BAe 146 Freighter (-100QT & QC)"
    },
    {
      "IATA": "14Y",
      "ICAO": "B462",
      "Wake": "BAe 146 Freighter (-200QT & QC)"
    },
    {
      "IATA": "14Z",
      "ICAO": "B463",
      "Wake": "BAe 146 Freighter (-200QT & QC)"
    },
    {
      "IATA": "310",
      "ICAO": "A310",
      "Wake": "Airbus A310 all pax models"
    },
    {
      "IATA": "312",
      "ICAO": "A310",
      "Wake": "Airbus A310-200 pax"
    },
    {
      "IATA": "313",
      "ICAO": "A310",
      "Wake": "Airbus A310-300 pax"
    },
    {
      "IATA": "318",
      "ICAO": "A318",
      "Wake": "Airbus A318"
    },
    {
      "IATA": "319",
      "ICAO": "A319",
      "Wake": "Airbus A319"
    },
    {
      "IATA": "31F",
      "ICAO": "A310",
      "Wake": "Airbus A310 Freighter"
    },
    {
      "IATA": "31X",
      "ICAO": "A310",
      "Wake": "Airbus A310-200 Freighter"
    },
    {
      "IATA": "31Y",
      "ICAO": "A310",
      "Wake": "Airbus A310-300 Freighter"
    },
    {
      "IATA": "320",
      "ICAO": "A320",
      "Wake": "Airbus A320-100/200"
    },
    {
      "IATA": "321",
      "ICAO": "A321",
      "Wake": "Airbus A321-100/200"
    },
    {
      "IATA": "32S",
      "ICAO": "n/a",
      "Wake": "Airbus A318/319/320/321"
    },
    {
      "IATA": "330",
      "ICAO": "A330",
      "Wake": "Airbus A330 all models"
    },
    {
      "IATA": "332",
      "ICAO": "A332",
      "Wake": "Airbus A330-200"
    },
    {
      "IATA": "333",
      "ICAO": "A333",
      "Wake": "Airbus A330-300"
    },
    {
      "IATA": "340",
      "ICAO": "A340",
      "Wake": "Airbus A340 all models"
    },
    {
      "IATA": "342",
      "ICAO": "A342",
      "Wake": "Airbus A340-200"
    },
    {
      "IATA": "343",
      "ICAO": "A343",
      "Wake": "Airbus A340-300"
    },
    {
      "IATA": "345",
      "ICAO": "A345",
      "Wake": "Airbus A340-500"
    },
    {
      "IATA": "346",
      "ICAO": "A346",
      "Wake": "Airbus A340-600"
    },
    {
      "IATA": "380",
      "ICAO": "n/a",
      "Wake": "Airbus A380 pax"
    },
    {
      "IATA": "38F",
      "ICAO": "n/a",
      "Wake": "Airbus A380 Freighter"
    },
    {
      "IATA": "703",
      "ICAO": "B703",
      "Wake": "Boeing 707-300 pax"
    },
    {
      "IATA": "707",
      "ICAO": "n/a",
      "Wake": "Boeing 707/720 all pax models"
    },
    {
      "IATA": "70F",
      "ICAO": "B703",
      "Wake": "Boeing 707 Freighter"
    },
    {
      "IATA": "70M",
      "ICAO": "B703",
      "Wake": "Boeing 707 Combi"
    },
    {
      "IATA": "717",
      "ICAO": "B712",
      "Wake": "Boeing 717"
    },
    {
      "IATA": "721",
      "ICAO": "B721",
      "Wake": "Boeing 727-100 pax"
    },
    {
      "IATA": "722",
      "ICAO": "B722",
      "Wake": "Boeing 727-200 pax"
    },
    {
      "IATA": "727",
      "ICAO": "n/a",
      "Wake": "Boeing 727 all pax models"
    },
    {
      "IATA": "72B",
      "ICAO": "B721",
      "Wake": "Boeing 727-100 Mixed Configuration"
    },
    {
      "IATA": "72C",
      "ICAO": "B722",
      "Wake": "Boeing 727-200 Mixed Configuration"
    },
    {
      "IATA": "72F",
      "ICAO": "n/a",
      "Wake": "Boeing 727 Freighter (-100/200)"
    },
    {
      "IATA": "72M",
      "ICAO": "n/a",
      "Wake": "Boeing 727 Combi"
    },
    {
      "IATA": "72S",
      "ICAO": "B722",
      "Wake": "Boeing 727-200 Advanced pax"
    },
    {
      "IATA": "72X",
      "ICAO": "B721",
      "Wake": "Boeing 727-100 Freighter"
    },
    {
      "IATA": "72Y",
      "ICAO": "B722",
      "Wake": "Boeing 727-200 Freighter"
    },
    {
      "IATA": "731",
      "ICAO": "B731",
      "Wake": "Boeing 737-100 pax"
    },
    {
      "IATA": "732",
      "ICAO": "B732",
      "Wake": "Boeing 737-200 pax"
    },
    {
      "IATA": "733",
      "ICAO": "B733",
      "Wake": "Boeing 737-300 pax"
    },
    {
      "IATA": "734",
      "ICAO": "B734",
      "Wake": "Boeing 737-400 pax"
    },
    {
      "IATA": "735",
      "ICAO": "B735",
      "Wake": "Boeing 737-500 pax"
    },
    {
      "IATA": "736",
      "ICAO": "B736",
      "Wake": "Boeing 737-600 pax"
    },
    {
      "IATA": "737",
      "ICAO": "n/a",
      "Wake": "Boeing 737 all pax models"
    },
    {
      "IATA": "738",
      "ICAO": "B738",
      "Wake": "Boeing 737-800 pax"
    },
    {
      "IATA": "739",
      "ICAO": "B739",
      "Wake": "Boeing 737-900 pax"
    },
    {
      "IATA": "73F",
      "ICAO": "n/a",
      "Wake": "Boeing 737 all Freighter models"
    },
    {
      "IATA": "73G",
      "ICAO": "B737",
      "Wake": "Boeing 737-700 pax"
    },
    {
      "IATA": "73H",
      "ICAO": "B738",
      "Wake": "Boeing 737-800 (winglets) pax"
    },
    {
      "IATA": "73M",
      "ICAO": "B732",
      "Wake": "Boeing 737-200 Combi"
    },
    {
      "IATA": "73W",
      "ICAO": "B737",
      "Wake": "Boeing 737-700 (winglets) pax"
    },
    {
      "IATA": "73X",
      "ICAO": "B732",
      "Wake": "Boeing 737-200 Freighter"
    },
    {
      "IATA": "73Y",
      "ICAO": "B733",
      "Wake": "Boeing 737-300 Freighter"
    },
    {
      "IATA": "741",
      "ICAO": "B741",
      "Wake": "Boeing 747-100 pax"
    },
    {
      "IATA": "742",
      "ICAO": "B742",
      "Wake": "Boeing 747-200 pax"
    },
    {
      "IATA": "743",
      "ICAO": "B743",
      "Wake": "Boeing 747-300 pax"
    },
    {
      "IATA": "744",
      "ICAO": "B744",
      "Wake": "Boeing 747-400 pax"
    },
    {
      "IATA": "747",
      "ICAO": "n/a",
      "Wake": "Boeing 747 all pax models"
    },
    {
      "IATA": "74C",
      "ICAO": "B742",
      "Wake": "Boeing 747-200 Combi"
    },
    {
      "IATA": "74D",
      "ICAO": "B743",
      "Wake": "Boeing 747-300 Combi"
    },
    {
      "IATA": "74E",
      "ICAO": "B744",
      "Wake": "Boeing 747-400 Combi"
    },
    {
      "IATA": "74F",
      "ICAO": "n/a",
      "Wake": "Boeing 747 all Freighter models"
    },
    {
      "IATA": "74J",
      "ICAO": "B744",
      "Wake": "Boeing 747-400 (Domestic) pax"
    },
    {
      "IATA": "74L",
      "ICAO": "N74S",
      "Wake": "Boeing 747SP"
    },
    {
      "IATA": "74M",
      "ICAO": "n/a",
      "Wake": "Boeing 747 all Combi models"
    },
    {
      "IATA": "74R",
      "ICAO": "B74R",
      "Wake": "Boeing 747SR pax"
    },
    {
      "IATA": "74T",
      "ICAO": "B741",
      "Wake": "Boeing 747-100 Freighter"
    },
    {
      "IATA": "74U",
      "ICAO": "B743",
      "Wake": "Boeing 747-300 / 747-200 SUD Freighter"
    },
    {
      "IATA": "74V",
      "ICAO": "B74R",
      "Wake": "Boeing 747SR Freighter"
    },
    {
      "IATA": "74X",
      "ICAO": "B742",
      "Wake": "Boeing 747-200 Freighter"
    },
    {
      "IATA": "74Y",
      "ICAO": "B744",
      "Wake": "Boeing 747-400 Freighter"
    },
    {
      "IATA": "752",
      "ICAO": "B752",
      "Wake": "Boeing 757-200 pax"
    },
    {
      "IATA": "753",
      "ICAO": "B753",
      "Wake": "Boeing 757-300 pax"
    },
    {
      "IATA": "757",
      "ICAO": "n/a",
      "Wake": "Boeing 757 all pax models"
    },
    {
      "IATA": "75F",
      "ICAO": "B752",
      "Wake": "Boeing 757 Freighter"
    },
    {
      "IATA": "75M",
      "ICAO": "B752",
      "Wake": "Boeing 757 Mixed Configuration"
    },
    {
      "IATA": "762",
      "ICAO": "B762",
      "Wake": "Boeing 767-200 pax"
    },
    {
      "IATA": "763",
      "ICAO": "B763",
      "Wake": "Boeing 767-300 pax"
    },
    {
      "IATA": "764",
      "ICAO": "B764",
      "Wake": "Boeing 767-400 pax"
    },
    {
      "IATA": "767",
      "ICAO": "n/a",
      "Wake": "Boeing 767 all pax models"
    },
    {
      "IATA": "76F",
      "ICAO": "n/a",
      "Wake": "Boeing 767 all Freighter models"
    },
    {
      "IATA": "76X",
      "ICAO": "B762",
      "Wake": "Boeing 767-200 Freighter"
    },
    {
      "IATA": "76Y",
      "ICAO": "B763",
      "Wake": "Boeing 767-300 Freighter"
    },
    {
      "IATA": "772",
      "ICAO": "B772",
      "Wake": "Boeing 777-200 pax"
    },
    {
      "IATA": "773",
      "ICAO": "B773",
      "Wake": "Boeing 777-300 pax"
    },
    {
      "IATA": "777",
      "ICAO": "n/a",
      "Wake": "Boeing 777 all pax models"
    },
    {
      "IATA": "A26",
      "ICAO": "AN26",
      "Wake": "Antonov AN-26"
    },
    {
      "IATA": "A28",
      "ICAO": "AN28",
      "Wake": "Antonov AN-28 / PZL Miele M-28 Skytruck"
    },
    {
      "IATA": "A30",
      "ICAO": "AN30",
      "Wake": "Antonov AN-30"
    },
    {
      "IATA": "A32",
      "ICAO": "AN32",
      "Wake": "Antonov AN-32"
    },
    {
      "IATA": "A40",
      "ICAO": "A140",
      "Wake": "Antonov AN-140"
    },
    {
      "IATA": "A4F",
      "ICAO": "A124",
      "Wake": "Antonov AN-124 Ruslan"
    },
    {
      "IATA": "AB3",
      "ICAO": "A30B",
      "Wake": "Airbus Industrie A300 pax"
    },
    {
      "IATA": "AB4",
      "ICAO": "A30B",
      "Wake": "Airbus Industrie A300B2/B4/C4 pax"
    },
    {
      "IATA": "AB6",
      "ICAO": "A306",
      "Wake": "Airbus Industrie A300-600 pax"
    },
    {
      "IATA": "ABB",
      "ICAO": "A3ST",
      "Wake": "Airbus Industrie A300-600ST Beluga Freighter"
    },
    {
      "IATA": "ABF",
      "ICAO": "A30B",
      "Wake": "Airbus Industrie A300 Freighter"
    },
    {
      "IATA": "ABX",
      "ICAO": "A30B",
      "Wake": "Airbus Industrie A300C4/F4 Freighter"
    },
    {
      "IATA": "ABY",
      "ICAO": "A306",
      "Wake": "Airbus Industrie A600-600 Freighter"
    },
    {
      "IATA": "ACD",
      "ICAO": "n/a",
      "Wake": "Gulfstream/Rockwell (Aero) Commander/Turbo Commander"
    },
    {
      "IATA": "ACP",
      "ICAO": "AC68",
      "Wake": "Gulfstream/Rockwell (Aero) Commander"
    },
    {
      "IATA": "ACT",
      "ICAO": "AC90",
      "Wake": "Gulfstream/Rockwell (Aero) Turbo Commander"
    },
    {
      "IATA": "ALM",
      "ICAO": "LOAD",
      "Wake": "Ayres LM-200 Loadmaster"
    },
    {
      "IATA": "AN4",
      "ICAO": "AN24",
      "Wake": "Antonov AN-24"
    },
    {
      "IATA": "AN6",
      "ICAO": "n/a",
      "Wake": "Antonov AN-26 / AN-30 /AN-32"
    },
    {
      "IATA": "AN7",
      "ICAO": "AN72",
      "Wake": "Antonov AN-72 / AN-74"
    },
    {
      "IATA": "ANF",
      "ICAO": "AN12",
      "Wake": "Antonov AN-12"
    },
    {
      "IATA": "APH",
      "ICAO": "n/a",
      "Wake": "Eurocopter (Aerospatiale) SA330 Puma / AS332 Super Puma"
    },
    {
      "IATA": "AR1",
      "ICAO": "RJ1H",
      "Wake": "Avro RJ100 Avroliner"
    },
    {
      "IATA": "AR7",
      "ICAO": "RJ70",
      "Wake": "Avro RJ70 Avroliner"
    },
    {
      "IATA": "AR8",
      "ICAO": "RJ85",
      "Wake": "Avro RJ85 Avroliner"
    },
    {
      "IATA": "ARJ",
      "ICAO": "n/a",
      "Wake": "Avro RJ70 / RJ85 / RJ100 Avroliner"
    },
    {
      "IATA": "ARX",
      "ICAO": "n/a",
      "Wake": "Avro RJX85 / RJX100"
    },
    {
      "IATA": "AT4",
      "ICAO": "AT43",
      "Wake": "Aerospatiale/Alenia ATR 42-300 / 320"
    },
    {
      "IATA": "AT5",
      "ICAO": "AT45",
      "Wake": "Aerospatiale/Alenia ATR 42-500"
    },
    {
      "IATA": "AT7",
      "ICAO": "AT72",
      "Wake": "Aerospatiale/Alenia ATR 72"
    },
    {
      "IATA": "ATP",
      "ICAO": "ATP",
      "Wake": "British Aerospace ATP"
    },
    {
      "IATA": "ATR",
      "ICAO": "n/a",
      "Wake": "Aerospatiale/Alenia ATR 42/ ATR 72"
    },
    {
      "IATA": "AX1",
      "ICAO": "RX1H",
      "Wake": "Avro RJX100"
    },
    {
      "IATA": "AX8",
      "ICAO": "RX85",
      "Wake": "Avro RJX85"
    },
    {
      "IATA": "B11",
      "ICAO": "BA11",
      "Wake": "British Aerospace (BAC) One Eleven / RomBAC One Eleven"
    },
    {
      "IATA": "B12",
      "ICAO": "BA11",
      "Wake": "British Aerospace (BAC) One Eleven 200"
    },
    {
      "IATA": "B13",
      "ICAO": "BA11",
      "Wake": "British Aerospace (BAC) One Eleven 300"
    },
    {
      "IATA": "B14",
      "ICAO": "BA11",
      "Wake": "British Aerospace (BAC) One Eleven 400/475"
    },
    {
      "IATA": "B15",
      "ICAO": "BA11",
      "Wake": "British Aerospace (BAC) One Eleven 500 / RomBAC One Eleven"
    },
    {
      "IATA": "B72",
      "ICAO": "B720",
      "Wake": "Boeing 720B pax"
    },
    {
      "IATA": "BE1",
      "ICAO": "B190",
      "Wake": "Beechcraft 1900/1900C/1900D"
    },
    {
      "IATA": "BE2",
      "ICAO": "n/a",
      "Wake": "Beechcraft twin piston engines"
    },
    {
      "IATA": "BEC",
      "ICAO": "n/a",
      "Wake": "Beechcraft light aircraft"
    },
    {
      "IATA": "BEH",
      "ICAO": "B190",
      "Wake": "Beechcraft 1900D"
    },
    {
      "IATA": "BEP",
      "ICAO": "n/a",
      "Wake": "Beechcraft light aircraft - single engine"
    },
    {
      "IATA": "BES",
      "ICAO": "B190",
      "Wake": "Beechcfrat 1900/1900C"
    },
    {
      "IATA": "BET",
      "ICAO": "n/a",
      "Wake": "Beechcraft light aircraft - twin turboprop engine"
    },
    {
      "IATA": "BH2",
      "ICAO": "n/a",
      "Wake": "Bell Helicopters"
    },
    {
      "IATA": "BNI",
      "ICAO": "BN2P",
      "Wake": "Pilatus Britten-Norman BN-2A/B Islander"
    },
    {
      "IATA": "BNT",
      "ICAO": "TRIS",
      "Wake": "Pilatus Britten-Norman BN-2A Mk III Trislander"
    },
    {
      "IATA": "BUS",
      "ICAO": "n/a",
      "Wake": "Bus"
    },
    {
      "IATA": "CCJ",
      "ICAO": "CL60",
      "Wake": "Canadair Challenger"
    },
    {
      "IATA": "CCX",
      "ICAO": "GLEX",
      "Wake": "Canadair Global Express"
    },
    {
      "IATA": "CD2",
      "ICAO": "NOMA",
      "Wake": "Government Aircraft Factories N22B / N24A Nomad"
    },
    {
      "IATA": "CL4",
      "ICAO": "CL44",
      "Wake": "Canadair CL-44"
    },
    {
      "IATA": "CN1",
      "ICAO": "n/a",
      "Wake": "Cessna light aircraft - single piston engine"
    },
    {
      "IATA": "CN2",
      "ICAO": "n/a",
      "Wake": "Cessna light aircraft - twin piston engines"
    },
    {
      "IATA": "CNA",
      "ICAO": "n/a",
      "Wake": "Cessna light aircraft"
    },
    {
      "IATA": "CNC",
      "ICAO": "n/a",
      "Wake": "Cessna light aircraft - single turboprop engine"
    },
    {
      "IATA": "CNJ",
      "ICAO": "n/a",
      "Wake": "Cessna Citation"
    },
    {
      "IATA": "CNT",
      "ICAO": "n/a",
      "Wake": "Cessna light aircraft - twin turboprop engines"
    },
    {
      "IATA": "CR1",
      "ICAO": "CRJ1",
      "Wake": "Canadair Regional Jet 100"
    },
    {
      "IATA": "CR2",
      "ICAO": "CRJ2",
      "Wake": "Canadair Regional Jet 200"
    },
    {
      "IATA": "CR7",
      "ICAO": "CRJ7",
      "Wake": "Canadair Regional Jet 700"
    },
    {
      "IATA": "CR9",
      "ICAO": "CRJ9",
      "Wake": "Canadair Regional Jet 900"
    },
    {
      "IATA": "CRJ",
      "ICAO": "n/a",
      "Wake": "Canadair Regional Jet"
    },
    {
      "IATA": "CRV",
      "ICAO": "S210",
      "Wake": "Aerospatiale (Sud Aviation) Se.210 Caravelle"
    },
    {
      "IATA": "CS2",
      "ICAO": "C212",
      "Wake": "CASA / IPTN 212 Aviocar"
    },
    {
      "IATA": "CS5",
      "ICAO": "CN35",
      "Wake": "CASA / IPTN CN-235"
    },
    {
      "IATA": "CV4",
      "ICAO": "CVLP",
      "Wake": "Convair CV-440 Metropolitan pax"
    },
    {
      "IATA": "CV5",
      "ICAO": "CVLT",
      "Wake": "Convair CV-580 pax"
    },
    {
      "IATA": "CVF",
      "ICAO": "n/a",
      "Wake": "Convair CV-240 / 440 / 580 / 600 / 640 Freighter"
    },
    {
      "IATA": "CVR",
      "ICAO": "n/a",
      "Wake": "Convair CV-240 / 440 / 580 / 600 / 640 pax"
    },
    {
      "IATA": "CVV",
      "ICAO": "CVLP",
      "Wake": "Convair CV-240 Freighter"
    },
    {
      "IATA": "CVX",
      "ICAO": "CVLP",
      "Wake": "Convair CV-440 Freighter"
    },
    {
      "IATA": "CVY",
      "ICAO": "CVLT",
      "Wake": "Convair CV-580 / 600 / 640 Freighter"
    },
    {
      "IATA": "CWC",
      "ICAO": "C46",
      "Wake": "Curtiss C-46 Commando"
    },
    {
      "IATA": "D10",
      "ICAO": "DC10",
      "Wake": "Douglas DC-10 pax"
    },
    {
      "IATA": "D11",
      "ICAO": "DC10",
      "Wake": "Douglas DC-10-10/15 pax"
    },
    {
      "IATA": "D1C",
      "ICAO": "DC10",
      "Wake": "Douglas DC-10-30/40 pax"
    },
    {
      "IATA": "D1F",
      "ICAO": "DC10",
      "Wake": "Douglas DC-10 all Freighters"
    },
    {
      "IATA": "D1M",
      "ICAO": "DC10",
      "Wake": "Douglas DC-10 all Combi models"
    },
    {
      "IATA": "D1X",
      "ICAO": "DC10",
      "Wake": "Douglas DC-10-10 Freighter"
    },
    {
      "IATA": "D1Y",
      "ICAO": "DC10",
      "Wake": "Douglas DC-10-30 / 40 Freighters"
    },
    {
      "IATA": "D28",
      "ICAO": "D228",
      "Wake": "Fairchild Dornier Do.228"
    },
    {
      "IATA": "D38",
      "ICAO": "D328",
      "Wake": "Fairchild Dornier Do.328"
    },
    {
      "IATA": "D3F",
      "ICAO": "DC3",
      "Wake": "Douglas DC-3 Freighter"
    },
    {
      "IATA": "D6F",
      "ICAO": "DC6",
      "Wake": "Douglas DC-6A/B/C Freighter"
    },
    {
      "IATA": "D8F",
      "ICAO": "n/a",
      "Wake": "Douglas DC-8 all Freighters"
    },
    {
      "IATA": "D8L",
      "ICAO": "DC86",
      "Wake": "Douglas DC-8-62 pax"
    },
    {
      "IATA": "D8M",
      "ICAO": "n/a",
      "Wake": "Douglas DC-8 all Combi models"
    },
    {
      "IATA": "D8Q",
      "ICAO": "DC87",
      "Wake": "Douglas DC-8-72 pax"
    },
    {
      "IATA": "D8T",
      "ICAO": "DC85",
      "Wake": "Douglas DC-8-50 Freighter"
    },
    {
      "IATA": "D8X",
      "ICAO": "n/a",
      "Wake": "Douglas DC-8-61 / 62 / 63 Freighters"
    },
    {
      "IATA": "D8Y",
      "ICAO": "DC87",
      "Wake": "Douglas DC-8-71 / 72 / 73 Freighters"
    },
    {
      "IATA": "D91",
      "ICAO": "DC91",
      "Wake": "Douglas DC-9-10 pax"
    },
    {
      "IATA": "D92",
      "ICAO": "DC92",
      "Wake": "Douglas DC-9-20 pax"
    },
    {
      "IATA": "D93",
      "ICAO": "DC93",
      "Wake": "Douglas DC-9-30 pax"
    },
    {
      "IATA": "D94",
      "ICAO": "DC94",
      "Wake": "Douglas DC-9-40 pax"
    },
    {
      "IATA": "D95",
      "ICAO": "DC95",
      "Wake": "Douglas DC-9-50 pax"
    },
    {
      "IATA": "D9C",
      "ICAO": "DC93",
      "Wake": "Douglas DC-9-30 Freighter"
    },
    {
      "IATA": "D9F",
      "ICAO": "DC94",
      "Wake": "Douglas DC-9-40 Freighter"
    },
    {
      "IATA": "D9F",
      "ICAO": "n/a",
      "Wake": "Douglas DC-9 all Freighters"
    },
    {
      "IATA": "D9X",
      "ICAO": "DC91",
      "Wake": "Douglas DC-9-10 Freighter"
    },
    {
      "IATA": "DC3",
      "ICAO": "DC3",
      "Wake": "Douglas DC-3 pax"
    },
    {
      "IATA": "DC6",
      "ICAO": "DC6",
      "Wake": "Douglas DC6A/B pax"
    },
    {
      "IATA": "DC8",
      "ICAO": "n/a",
      "Wake": "Douglas DC-8 all pax models"
    },
    {
      "IATA": "DC9",
      "ICAO": "DC9",
      "Wake": "Douglas DC-9 all pax models"
    },
    {
      "IATA": "DF2",
      "ICAO": "n/a",
      "Wake": "Dassault (Breguet Mystere) Falcon 10 / 100 / 20 / 200 / 2000"
    },
    {
      "IATA": "DF3",
      "ICAO": "n/a",
      "Wake": "Dassault (Breguet Mystere) Falcon 50 / 900"
    },
    {
      "IATA": "DFL",
      "ICAO": "n/a",
      "Wake": "Dassault (Breguet Mystere) Falcon"
    },
    {
      "IATA": "DH1",
      "ICAO": "DH8A",
      "Wake": "De Havilland Canada DHC-8-100 Dash 8 / 8Q"
    },
    {
      "IATA": "DH2",
      "ICAO": "DH8B",
      "Wake": "De Havilland Canada DHC-8-200 Dash 8 / 8Q"
    },
    {
      "IATA": "DH3",
      "ICAO": "DH8C",
      "Wake": "De Havilland Canada DHC-8-300 Dash 8 / 8Q"
    },
    {
      "IATA": "DH4",
      "ICAO": "DH8D",
      "Wake": "De Havilland Canada DHC-8-400 Dash 8Q"
    },
    {
      "IATA": "DH7",
      "ICAO": "DHC7",
      "Wake": "De Havilland Canada DHC-7 Dash 7"
    },
    {
      "IATA": "DH8",
      "ICAO": "n/a",
      "Wake": "De Havilland Canada DHC-8 Dash 8 all models"
    },
    {
      "IATA": "DHB",
      "ICAO": "n/a",
      "Wake": "De Havilland Canada DHC-2 Beaver / Turbo Beaver"
    },
    {
      "IATA": "DHC",
      "ICAO": "DHC4",
      "Wake": "De Havilland Canada DHC-4 Caribou"
    },
    {
      "IATA": "DHD",
      "ICAO": "DOVE",
      "Wake": "De Havilland DH.104 Dove"
    },
    {
      "IATA": "DHH",
      "ICAO": "HERN",
      "Wake": "De Havilland DH.114 Heron"
    },
    {
      "IATA": "DHL",
      "ICAO": "DHC3",
      "Wake": "De Havilland Canada DHC-3 Turbo Otter"
    },
    {
      "IATA": "DHO",
      "ICAO": "DHC3",
      "Wake": "De Havilland Canada DHC-3 Otter / Turbo Otter"
    },
    {
      "IATA": "DHP",
      "ICAO": "DHC2",
      "Wake": "De Havilland Canada DHC-2 Beaver"
    },
    {
      "IATA": "DHR",
      "ICAO": "DH2T",
      "Wake": "De Havilland Canada DHC-2 Turbo-Beaver"
    },
    {
      "IATA": "DHS",
      "ICAO": "DHC3",
      "Wake": "De Havilland Canada DHC-3 Otter\tL"
    },
    {
      "IATA": "DHT",
      "ICAO": "DHC6",
      "Wake": "De Havilland Canada DHC-6 Twin Otter"
    },
    {
      "IATA": "E70",
      "ICAO": "E170",
      "Wake": "Embraer 170"
    },
    {
      "IATA": "E90",
      "ICAO": "E190",
      "Wake": "Embraer 190"
    },
    {
      "IATA": "EM2",
      "ICAO": "E120",
      "Wake": "Embraer EMB.120 Brasilia"
    },
    {
      "IATA": "EMB",
      "ICAO": "E110",
      "Wake": "Embraer EMB.110 Bandeirnate"
    },
    {
      "IATA": "EMJ",
      "ICAO": "n/a",
      "Wake": "Embraer 170/190"
    },
    {
      "IATA": "ER3",
      "ICAO": "E135",
      "Wake": "Embraer RJ135"
    },
    {
      "IATA": "ER4",
      "ICAO": "E145",
      "Wake": "Embraer RJ145 Amazon"
    },
    {
      "IATA": "ERD",
      "ICAO": "n/a",
      "Wake": "Embraer RJ140"
    },
    {
      "IATA": "ERJ",
      "ICAO": "n/a",
      "Wake": "Embraer RJ135 / RJ140 / RJ145"
    },
    {
      "IATA": "F21",
      "ICAO": "F28",
      "Wake": "Fokker F.28 Fellowship 1000"
    },
    {
      "IATA": "F22",
      "ICAO": "F28",
      "Wake": "Fokker F.28 Fellowship 2000"
    },
    {
      "IATA": "F23",
      "ICAO": "F28",
      "Wake": "Fokker F.28 Fellowship 3000"
    },
    {
      "IATA": "F24",
      "ICAO": "F28",
      "Wake": "Fokker F.28 Fellowship 4000"
    },
    {
      "IATA": "F27",
      "ICAO": "F27",
      "Wake": "Fokker F.27 Friendship / Fairchild F.27"
    },
    {
      "IATA": "F28",
      "ICAO": "F28",
      "Wake": "Fokker F.28 Fellowship"
    },
    {
      "IATA": "F50",
      "ICAO": "F50",
      "Wake": "Fokker 50"
    },
    {
      "IATA": "F70",
      "ICAO": "F70",
      "Wake": "Fokker 70"
    },
    {
      "IATA": "FA7",
      "ICAO": "n/a",
      "Wake": "Fairchild Dornier 728JET"
    },
    {
      "IATA": "FK7",
      "ICAO": "F27",
      "Wake": "Fairchild FH.227"
    },
    {
      "IATA": "FRJ",
      "ICAO": "J328",
      "Wake": "Fairchild Dornier 328JET"
    },
    {
      "IATA": "GRG",
      "ICAO": "G21",
      "Wake": "Grumman G.21 Goose"
    },
    {
      "IATA": "GRJ",
      "ICAO": "n/a",
      "Wake": "Gulfstream Aerospace G-1159 Gulfstream II / III / IV / V"
    },
    {
      "IATA": "GRM",
      "ICAO": "G73T",
      "Wake": "Grumman G.73 Turbo Mallard"
    },
    {
      "IATA": "GRS",
      "ICAO": "G159",
      "Wake": "Gulfstream Aerospace G-159 Gulfstream I"
    },
    {
      "IATA": "H25",
      "ICAO": "n/a",
      "Wake": "British Aerospace (Hawker Siddeley) HS.125"
    },
    {
      "IATA": "HEC",
      "ICAO": "COUC",
      "Wake": "Helio H-250 Courier / H-295 / 385 Super Courier"
    },
    {
      "IATA": "HOV",
      "ICAO": "n/a",
      "Wake": "Hovercraft"
    },
    {
      "IATA": "HS7",
      "ICAO": "A748",
      "Wake": "Hawker Siddeley HS.748"
    },
    {
      "IATA": "I14",
      "ICAO": "I114",
      "Wake": "Ilyushin IL114"
    },
    {
      "IATA": "I93",
      "ICAO": "IL96",
      "Wake": "Ilyushin IL96-300 pax"
    },
    {
      "IATA": "I9F",
      "ICAO": "IL96",
      "Wake": "Ilyushin IL96 Freighters"
    },
    {
      "IATA": "I9M",
      "ICAO": "IL96",
      "Wake": "Ilyushin IL96M pax"
    },
    {
      "IATA": "I9X",
      "ICAO": "IL96",
      "Wake": "Ilyushin IL96-300 Freighter"
    },
    {
      "IATA": "I9Y",
      "ICAO": "IL96",
      "Wake": "Ilyushin IL96T Freighter"
    },
    {
      "IATA": "IL6",
      "ICAO": "IL62",
      "Wake": "Ilyushin IL62"
    },
    {
      "IATA": "IL7",
      "ICAO": "IL76",
      "Wake": "Ilyushin IL76"
    },
    {
      "IATA": "IL8",
      "ICAO": "IL18",
      "Wake": "Ilyushin IL18"
    },
    {
      "IATA": "IL9",
      "ICAO": "IL96",
      "Wake": "Ilyushin IL96 pax"
    },
    {
      "IATA": "ILW",
      "ICAO": "IL86",
      "Wake": "Ilyushin IL86"
    },
    {
      "IATA": "J31",
      "ICAO": "JS31",
      "Wake": "British Aerospace Jetstream 31"
    },
    {
      "IATA": "J32",
      "ICAO": "JS32",
      "Wake": "British Aerospace Jetstream 32"
    },
    {
      "IATA": "J41",
      "ICAO": "JS41",
      "Wake": "British Aerospace Jetstream 41"
    },
    {
      "IATA": "JST",
      "ICAO": "n/a",
      "Wake": "British Aerospace Jetstream 31 / 32 / 41"
    },
    {
      "IATA": "JU5",
      "ICAO": "JU52",
      "Wake": "Junkers Ju52/3M"
    },
    {
      "IATA": "L10",
      "ICAO": "L101",
      "Wake": "Lockheed L-1011 Tristar pax"
    },
    {
      "IATA": "L11",
      "ICAO": "L101",
      "Wake": "Lockheed L-1011 1 / 50 / 100 / 150 / 200 / 250 Tristar pax"
    },
    {
      "IATA": "L15",
      "ICAO": "L101",
      "Wake": "Lockheed L-1011 500 Tristar pax"
    },
    {
      "IATA": "L1F",
      "ICAO": "L101",
      "Wake": "Lockheed L-1011 Tristar Freighter"
    },
    {
      "IATA": "L49",
      "ICAO": "CONI",
      "Wake": "Lockheed L-1049 Super Constellation"
    },
    {
      "IATA": "L4T",
      "ICAO": "L410",
      "Wake": "LET 410"
    },
    {
      "IATA": "LCH",
      "ICAO": "n/a",
      "Wake": "Launch - Boat"
    },
    {
      "IATA": "LMO",
      "ICAO": "n/a",
      "Wake": "Limousine"
    },
    {
      "IATA": "LOE",
      "ICAO": "L188",
      "Wake": "Lockheed L-188 Electra pax"
    },
    {
      "IATA": "LOF",
      "ICAO": "L188",
      "Wake": "Lockheed L-188 Electra Freighter"
    },
    {
      "IATA": "LOH",
      "ICAO": "C130",
      "Wake": "Lockheed L-182 / 282 / 382 (L-100) Hercules"
    },
    {
      "IATA": "LOM",
      "ICAO": "L188",
      "Wake": "Lockheed L-188 Electra Mixed Configuration"
    },
    {
      "IATA": "LRJ",
      "ICAO": "n/a",
      "Wake": "Gates Learjet"
    },
    {
      "IATA": "M11",
      "ICAO": "MD11",
      "Wake": "McDonnell Douglas MD11 pax"
    },
    {
      "IATA": "M1F",
      "ICAO": "MD11",
      "Wake": "McDonnell Douglas MD11 Freighter"
    },
    {
      "IATA": "M1M",
      "ICAO": "MD11",
      "Wake": "McDonnell Douglas MD11 Mixed Configuration"
    },
    {
      "IATA": "M80",
      "ICAO": "MD80",
      "Wake": "McDonnell Douglas MD80"
    },
    {
      "IATA": "M81",
      "ICAO": "MD81",
      "Wake": "McDonnell Douglas MD81"
    },
    {
      "IATA": "M82",
      "ICAO": "MD82",
      "Wake": "McDonnell Douglas MD82"
    },
    {
      "IATA": "M83",
      "ICAO": "MD83",
      "Wake": "McDonnell Douglas MD83"
    },
    {
      "IATA": "M87",
      "ICAO": "MD87",
      "Wake": "McDonnell Douglas MD87"
    },
    {
      "IATA": "M88",
      "ICAO": "MD88",
      "Wake": "McDonnell Douglas MD88"
    },
    {
      "IATA": "M90",
      "ICAO": "MD90",
      "Wake": "McDonnell Douglas MD90"
    },
    {
      "IATA": "MBH",
      "ICAO": "B105",
      "Wake": "Eurocopter (MBB) Bo.105"
    },
    {
      "IATA": "MD9",
      "ICAO": "EXPL",
      "Wake": "MD Helicopters MD900 Explorer"
    },
    {
      "IATA": "MIH",
      "ICAO": "MI8",
      "Wake": "MIL Mi-8 / Mi-17 / Mi-171 / Mil-172"
    },
    {
      "IATA": "MU2",
      "ICAO": "MU2",
      "Wake": "Mitsubishi Mu-2"
    },
    {
      "IATA": "ND2",
      "ICAO": "N262",
      "Wake": "Aerospatiale (Nord) 262"
    },
    {
      "IATA": "NDC",
      "ICAO": "S601",
      "Wake": "Aerospatiale SN.601 Corvette"
    },
    {
      "IATA": "NDE",
      "ICAO": "n/a",
      "Wake": "Eurocopter (Aerospatiale) AS350 Ecureuil / AS355 Ecureuil 2"
    },
    {
      "IATA": "NDH",
      "ICAO": "S65C",
      "Wake": "Eurocopter (Aerospatiale) SA365C / SA365N Dauphin 2"
    },
    {
      "IATA": "PA1",
      "ICAO": "n/a",
      "Wake": "Piper light aircraft - single piston engine"
    },
    {
      "IATA": "PA2",
      "ICAO": "n/a",
      "Wake": "Piper light aircraft - twin piston engines"
    },
    {
      "IATA": "PAG",
      "ICAO": "n/a",
      "Wake": "Piper light aircraft"
    },
    {
      "IATA": "PAT",
      "ICAO": "n/a",
      "Wake": "Piper light aircraft - twin turboprop engines"
    },
    {
      "IATA": "PL2",
      "ICAO": "PC12",
      "Wake": "Pilatus PC-12"
    },
    {
      "IATA": "PL6",
      "ICAO": "PC6T",
      "Wake": "Pilatus PC-6 Turbo Porter"
    },
    {
      "IATA": "PN6",
      "ICAO": "P68",
      "Wake": "Partenavia P.68"
    },
    {
      "IATA": "RFS",
      "ICAO": "n/a",
      "Wake": "Road Feeder Service - Cargo Truck"
    },
    {
      "IATA": "S20",
      "ICAO": "SB20",
      "Wake": "Saab 2000"
    },
    {
      "IATA": "S58",
      "ICAO": "S58T",
      "Wake": "Sikorsky S-58T"
    },
    {
      "IATA": "S61",
      "ICAO": "S61",
      "Wake": "Sikorsky S-61"
    },
    {
      "IATA": "S76",
      "ICAO": "S76",
      "Wake": "Sikorsky S-76"
    },
    {
      "IATA": "SF3",
      "ICAO": "SF34",
      "Wake": "Saab SF340A/B"
    },
    {
      "IATA": "SH3",
      "ICAO": "SH33",
      "Wake": "Shorts SD.330"
    },
    {
      "IATA": "SH6",
      "ICAO": "SH36",
      "Wake": "Shorts SD.360"
    },
    {
      "IATA": "SHB",
      "ICAO": "BELF",
      "Wake": "Shorts SC-5 Belfast"
    },
    {
      "IATA": "SHS",
      "ICAO": "SC7",
      "Wake": "Shorts SC-7 Skyvan"
    },
    {
      "IATA": "SSC",
      "ICAO": "CONC",
      "Wake": "Aerospatiale/BAC Concorde"
    },
    {
      "IATA": "SWM",
      "ICAO": "n/a",
      "Wake": "Fairchild (Swearingen) SA26 / SA226 / SA227 Metro / Merlin / Expediter"
    },
    {
      "IATA": "T20",
      "ICAO": "T204",
      "Wake": "Tupolev Tu-204 / Tu-214"
    },
    {
      "IATA": "TRN",
      "ICAO": "n/a",
      "Wake": "Train"
    },
    {
      "IATA": "TU3",
      "ICAO": "T134",
      "Wake": "Tupolev Tu134"
    },
    {
      "IATA": "TU5",
      "ICAO": "T154",
      "Wake": "Tupolev Tu154"
    },
    {
      "IATA": "VCV",
      "ICAO": "VISC",
      "Wake": "Vickers Viscount"
    },
    {
      "IATA": "WWP",
      "ICAO": "WW24",
      "Wake": "Israel Aircraft Industries 1124 Westwind"
    },
    {
      "IATA": "YK2",
      "ICAO": "YK42",
      "Wake": "Yakovlev Yak 42"
    },
    {
      "IATA": "YK4",
      "ICAO": "YK40",
      "Wake": "Yakovlev Yak 40"
    },
    {
      "IATA": "YN2",
      "ICAO": "Y12",
      "Wake": "Harbin Yunshuji Y12"
    },
    {
      "IATA": "YN7",
      "ICAO": "AN24",
      "Wake": "Xian Yunshuji Y7"
    },
    {
      "IATA": "YS1",
      "ICAO": "YS11",
      "Wake": "NAMC YS-11"
    }
  ]