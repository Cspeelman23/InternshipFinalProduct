import { TestBed } from '@angular/core/testing';
import { HttpClient, HttpHeaders, HttpHandler } from '@angular/common/http';
import { RefDataService } from './ref-data.service';

describe('RefDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [HttpClient, HttpHandler]
  }));

  it('should be created', () => {
    const service: RefDataService = TestBed.get(RefDataService);
    expect(service).toBeTruthy();
  });
});
