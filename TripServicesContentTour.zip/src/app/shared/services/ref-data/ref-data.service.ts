import { Injectable, OnInit } from '@angular/core';
import { Observable, of } from 'rxjs';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { AIRPORTDATA } from './airport-data.service';
import { EQUIPMENTDATA } from './equipment-data.service';
import { Airport } from '../../models/gds/Airport';
import { Equipment } from '../../models/gds/equipment';
import { CARRIERDATA } from './carrier-data.service';
import { AllCarriers } from '../../models/gds/Carrierlist';
import { CARRIERGROUP } from './mock-carrierGroup';

@Injectable({
  providedIn: 'root'
})
export class RefDataService implements OnInit {

  constructor() {
    this.getAirPortData();
    this.getEquipmentData();
    this.createCarrierCityMap();
    this.createEquipmentMap();
  }

  carrierMap = new Map<string, string>();
  cityMap = new Map<string, string>();
  equipmentMap = new Map<string, string>();
  filteredStates: Observable<any[]>;
  airports: Airport[];
  private carrierMessageValue = new BehaviorSubject<any>([]);
  currentAirline = this.carrierMessageValue.asObservable();

  equipmentList: Equipment[];

  ngOnInit() { }

  getAirPortJsonData(): Observable<Airport[]> {
    return of(AIRPORTDATA);
  }

  getCarrierList(): Observable<AllCarriers[]> {
    return of(CARRIERDATA);
  }

  getAirlinesData(): Observable<any> {
    return of(CARRIERGROUP);
  }

  getEquipmentJsonData(): Observable<Equipment[]> {    
    return of(EQUIPMENTDATA);
  }

  createCarrierCityMap() {
    CARRIERDATA.forEach(e => {
      this.carrierMap.set(e.CarrierCode, e.CarrierName);
    });
    this.airports.forEach(e => {
      this.cityMap.set(e.IATA, e.City);
    });
  }


  createEquipmentMap() {
    EQUIPMENTDATA.forEach(e => {
      this.equipmentMap.set(e.IATA, e.Wake);
    })
  }

  getEquipmentData() {
    this.getEquipmentJsonData()
      .subscribe(data => {
        const filterArray = [];
        data.forEach(e => {
          if (e.IATA !== 'null') {
            e.IATA = e.IATA.toUpperCase();
            filterArray.push(e);
          }
        });
        this.equipmentList = filterArray;
      });
  }

  getAirPortData(): void {
    this.getAirPortJsonData()
      .subscribe(data => {
        const filteredArray = [];
        data.forEach(e => {
          if (e.IATA !== 'null') {
            filteredArray.push(e);
          }
        });
        this.airports = filteredArray;
      });
  }

  filterStates(name: string) {
    return this.airports.filter(state =>
      state.IATA.toLowerCase().indexOf(name.toLowerCase()) === 0 || state.City.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  getAirPortDetails(iataCode): Airport {
    let airport: Airport = null;
    this.airports.forEach(e => {
      if (e.IATA === iataCode) {
        airport = e;
      }
    });
    return airport;
  }

  getEquipmentDetail(iataCode: string): Equipment {
    iataCode = iataCode.toUpperCase();
    let equip: Equipment = null;
    this.equipmentList.forEach(e => {
      if (e.IATA === iataCode) {
        equip = e;
      }
    });
    return equip;
  }

  changeAirline(airline: any[]) {
    const uniqueAirline = (unique) => {
      return unique.filter((element, position, arr) => {
        return arr.indexOf(element) === position;
      });
    };
    const final = uniqueAirline(airline);
    this.carrierMessageValue.next(final);
  }
}
