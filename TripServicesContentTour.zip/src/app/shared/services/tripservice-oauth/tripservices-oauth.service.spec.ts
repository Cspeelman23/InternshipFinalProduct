import { TestBed } from '@angular/core/testing';

import { TripservicesOAuthService } from './tripservices-oauth.service';

describe('TripservicesOAuthService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TripservicesOAuthService = TestBed.get(TripservicesOAuthService);
    expect(service).toBeTruthy();
  });
});
