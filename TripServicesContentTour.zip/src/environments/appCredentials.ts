export const appCredentials = {
    'environment': [
      {
        'env': 'int1',
        'pcc': [
          {
            'pcc': 'OMW',
            'description': 'PriceLine',
            'accessGroup': 'E5FF020D-F109-4899-BE5C-7ED4742816D2',
            'basicAuth': 'Basic VW5pdmVyc2FsIEFQSS9VQVBJNDUwMDE1MjYxNi03NDBEMzFENzozUWUhS3I/ODYk',
// tslint:disable-next-line: max-line-length
            'basicAuthAES': 'U2FsdGVkX1+Rie/yZx8QinpNDJ9x62sPHK6gbADYp0T1MBfEMgjfYl5kRB+NlHNpkMPJP8RcAd3Vc/0zAUo8cBnuZXsOJnpUwVxSl5F8+FOLDRFYPeFWhU3h3ckoJA4d',
            'core': '1P',
            'oauth': '???'
          },
          {
            'pcc': 'XUF',
            'description': 'NoIdea',
            'accessGroup': 'B8BAC77B-DE8D-458F-A1BA-643F29930851',
            'basicAuth': '???',
            'core': '1P',
            'oauth': '???'
          }
        ]
      },
      {
        'env': 'preprod',
        'pcc': [
            {
                'pcc': 'OMW',
                'description': 'PriceLine',
                'accessGroup': 'E5FF020D-F109-4899-BE5C-7ED4742816D2',
                'basicAuth': 'Basic VW5pdmVyc2FsIEFQSS9VQVBJNDUwMDE1MjYxNi03NDBEMzFENzozUWUhS3I/ODYk',
// tslint:disable-next-line: max-line-length
                'basicAuthAES': 'U2FsdGVkX1+Rie/yZx8QinpNDJ9x62sPHK6gbADYp0T1MBfEMgjfYl5kRB+NlHNpkMPJP8RcAd3Vc/0zAUo8cBnuZXsOJnpUwVxSl5F8+FOLDRFYPeFWhU3h3ckoJA4d',
                'core': '1P',
                'oauth': '???'
            },
            {
                'pcc': 'XUF',
                'description': 'NoIdea',
                'accessGroup': 'B8BAC77B-DE8D-458F-A1BA-643F29930851',
                'basicAuth': '???',
                'core': '1P',
                'oauth': '???'
            }
        ]
      }
    ]
  };
