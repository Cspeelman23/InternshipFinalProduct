// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
   firebase: {
    apiKey: 'AIzaSyDmk0frhvBvOXlYFzSB-YN4L0YicOdtMTc',
    authDomain: 'tripservices1-68980.firebaseapp.com',
    databaseURL: 'https://tripservices1-68980.firebaseio.com',
    projectId: 'tripservices1-68980',
    storageBucket: 'tripservices1-68980.appspot.com',
    messagingSenderId: '856601742733'
  },
  googleCloudPlatform: {
     apiKey: 'AIzaSyAJhKVpUEvTqzDRetKnN_ptZiI8fpQ3b0w'
  },
  appDefaults: {
    historyLength: 3
  },
  /* The search defaults
   departureDate default means, in the search O&D the departure date upon load of
   the form defaults to TODAY + 21 days.
   returnDate defaults to TODAY + 24 days and activates ONLY when you click into the field.
  */
   searchDefaults: {
    departureDate: '21',
    returnDate: '24'
  },
  publicRepository: 'https://gitbucket.tvlport.com/DemandAPI/tripServices-content-tour/tree/master',
// tslint:disable-next-line: max-line-length
  tripServicesDocumentation: 'https://support.travelport.com/webhelp/TripServices/#GeneralTopics/TripServicesIntroduction.htm%3FTocPath%3D_____1',
  commonCollateralUrl:
  {
    airIconsVTNG: 'https://vtngdev.azureedge.net/vtng/assets/img/Logos/AirlineIcons',
    airIcons: 'https://goprivate.wspan.com/sharedservices/images/airlineimages',
    hotelIcons: 'https://vtng.azureedge.net/vtng/assets/img/Logos/HotelIcons',
    carIcons: 'https://vtng.azureedge.net/vtng/assets/img/Logos/CarIcons'
  },
  tripservices: {
    authentication: {
      authUrl: 'https://adc-oa-np.apim.travelport.com/oauth/oauth20/token'
    },
    hotelProps: {
      baseUrl: 'https://adc-api-np.travelport.com',
      hotelShopBase: '/hotel/shop/v3/'
    },
    tripservicesGDSProps: {
      baseURL: 'https://zu2-api-np.travelport.com:443',
      // lowfareBase: '/qa/4/LWS_DOMAIN/catalogofferings',
      lowfareBase: '/4/air/search/catalogofferings',
      priceCache: '/4/air/price/offers/buildfromcatalogofferings',
      initiate_workBench : '/4/air/book/sessionreservation/reservationworkbench',
      addOffer: '/4/air/book/offerdomain/reservationworkbench/',
      addTraveler: '/4/air/book/travelers/reservationworkbench/',
      backOffice: '/4/air/book/backoffice-domain/reservationworkbench/',
      primaryContact: '/4/air/book/primarycontactremarks/RES_DOMAIN/reservationworkbench/',
      generalRemarks: '/4/air/book/comments/reservationworkbench/',
      bookRetrive: '/4/air/book/create/RES_DOMAIN/reservationworkbench/',
      addFOP: 'https://ts-airticket-payment-domain-4-qa.zu2-dv-gf.travelport.com/DOMAIN/reservationworkbench/',
      bookHoldCommit: '/4/air/book/reservationdomain/reservations/',
      retrivePNR: 'https://ts-airbook-res-domain-4-qa.zu2-dv-gf.travelport.com:443/RES_DOMAIN/reservations',
      issueTicket: 'https://ts-airticket-receipt-domain-4-5-3-0-qa.zu2-dv-gf.travelport.com/DOMAIN/reservations',
      displayTicket: 'https://ts-airticket-ticket-domain-4-5-2-0-qa.zu2-dv-gf.travelport.com/DOMAIN/tickets',
      voidTicket: 'https://ts-airticket-ticket-domain-4-5-2-0-qa.zu2-dv-gf.travelport.com/DOMAIN/tickets/updatestatus',
      eta: 'https://ts-airticket-receipt-domain-4-5-3-0-qa.zu2-dv-gf.travelport.com'
    },
    tripservicesAirProps: {
      lowfareURI: 'https://zu2-api-np.travelport.com:443/qa/4/LWS_DOMAIN/catalogofferings'
    },
    tripservicesFFSProps: {
      ffsURI: 'https://zu2-api-dv.apim.travelport.com/QA/2/FFS_DOMAIN/farefamilyofferings',
      ffsURI2: 'https://zu2-api-np.travelport.com:443/QA/2/FFS_DOMAIN/farefamilyofferings'
    },
    tsProps: {
      baseURL: 'https://zu2-api.travelport.com:443',
      tsInitiateWFContext: '/2/air/book/session/reservationworkbench',
      lowfareURI: 'https://zu2-api-np.travelport.com:443/qa/337/LWS_DOMAIN/catalogofferings?view=detail',
      tsPriceContext: '/2/air/price/offers/buildfromcatalogofferings',
      tsSellContext: '/2/air/book/offer/reservationworkbench/dummyReservation/offers/buildfromproducts',
      tsTravelerContext: '/2/air/book/traveler/reservationworkbench/dummyReservation/travelers',
      tsPaymentContext: '/2/air/payment/reservationworkbench/dummyReservation/formofpayment',
      tsBookContext: '/2/air/book/reservation/reservations/dummyReservation',
      tsRetrieveContext: '/2/air/book/reservation/reservations/dummyReservation',
      tsCancelContext: '/2/air/receipt/reservations/dummyReservation/receipts?OfferIdentifier=123',
// tslint:disable-next-line: max-line-length
      tsTicketContext: '/2/air/receipt/reservations/dummyReservation/receipts/buildfromlocator?ReservationLocator=dummyReservation&Issuance=TICKET'
    },
    ntacProps: {
      baseURL: 'https://adc-api.adc-dv-apim.travelport.com:443',
      ntacInitiateWFContext: '/interactionacscontextpt/interaction',
      ntacSearchContext: '/catalogofferspt/interactions/dummyInteraction/offers',
      ntacPriceContext: '/catalogpriceofferpt/interactions/dummyInteraction/offers',
      ntacSellContext: '/reservationofferpt/interactions/dummyInteraction/reservations/dummyReservation',
      ntacPaymentContext: '/reservationpaymentpt/interactions/dummyInteraction/reservations/dummyReservation/payments',
      ntacBookContext: '/reservationetofferpt/interactions/dummyInteraction/reservations/dummyReservation',
      ntacRetrieveContext: '/reservationofferpt/interactions/dummyInteraction/reservations/dummyReservation',
      ntacCancelContext: '/reservationetofferpt/interactions/dummyInteraction/reservations/dummyReservation',
      ntacTicketContext: '/reservationetofferpt/interactions/dummyInteraction/reservations/dummyReservation/receipt/builder',
      flxNonProdURL: 'http://ssl-offload:30373/testzone/ACH/FLXWS-STG/xmlts/sandboxdm'
  },
  dashboardDirectProps: {
    corsURL: 'https://cors-anywhere.herokuapp.com',
    interactionBase: 'https://nt-init-interaction', interactionContext: '/INTERACTION_DOMAIN/interaction',
    ntacSearchBase: 'https://nt-airsearch-offers', ntacSearchContext: '/ACS_SHOP_DOMAIN/interactions/dummyInteraction/offers',
    ndcSearchBase: 'https://nt-airsearch-offers-ndc', ndcSearchContext: '/ATOMIC_SHOP/interactions/dummyInteraction/offers',
    ntacPriceBase: 'https://nt-airprice-offers', ntacPriceContext: '/ACS_PRICE_DOMAIN/interactions/dummyInteraction/offers',
    ndcPriceBase: 'https://nt-airprice-offers-ndc', ndcPriceContext: '/ATOMIC_PRICE/interactions/dummyInteraction/offers',
// tslint:disable-next-line: max-line-length
    ntacSellBase: 'https://nt-airbook-offers', ntacSellContext: '/ACS_SELL_DOMAIN/interactions/dummyInteraction/reservations/dummyReservation',
// tslint:disable-next-line: max-line-length
    ndcSellBase: 'https://nt-airbook-offers-ndc', ndcSellContext: '/ATOMIC_SELL_NDC_17_2/interactions/dummyInteraction/reservations/dummyReservation/offer/dummyOffer',
// tslint:disable-next-line: max-line-length
    ntacPreBookRetrieveBase: 'https://nt-airbook-offers', ntacPreBookRetrieveContext: '/ACS_SELL_DOMAIN/interactions/dummyInteraction/reservations/dummyReservation',
// tslint:disable-next-line: max-line-length
    ntacBookBase: 'https://nt-airbook-et', ntacBookContext: '/END_TRANSACT_DOMAIN/interactions/dummyInteraction/reservations/dummyReservation',
// tslint:disable-next-line: max-line-length
    ndcBookBase: 'https://nt-airbook-et-ndc', ndcBookContext: '/ATOMIC_ET/interactions/dummyInteraction/reservations/dummyReservation/offers/dummyOffer'
  }
}

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
};
