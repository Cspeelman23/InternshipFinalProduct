
export const appversion = {
    Version: {
        VersionStringSample: '1.0.0.111',
        VersionMajor: '1',
        VersionMinor: '0',
        VersionPatch: '0',
        VersionBuild:'%'
    }
};

